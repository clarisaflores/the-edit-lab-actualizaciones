#!/usr/bin/env python3
"""The Edit Lab · extensión Carruseles. Solo biblioteca estándar.

Los carruseles se venden aparte. Esta extensión NO viene dentro del programa: se baja cifrada y solo se puede
abrir con una licencia de Carruseles firmada por The Clari Edit para el correo de quien la compró (empieza con
EDCAR-). Una clave de The Edit Lab (EDLAB-) no sirve para Carruseles y una de Carruseles no sirve para el Lab.

Nadie puede prender Carruseles sin su clave: ni la clienta, ni Claude, ni cambiando archivos (el programa vuelve
a poner sus archivos originales y la extensión se vuelve a abrir desde cero con la licencia cada vez).

  python3 carruseles.py estado
  python3 carruseles.py activar <correo> <clave>
"""
import base64, hashlib, hmac, io, json, os, shutil, sys, tarfile, time

import licencia

PREFIJO_FIRMA = b'the-edit-lab-carruseles|'


def _estudio():
    return os.path.abspath(os.environ.get('EDIT_LAB_ESTUDIO') or os.getcwd())


def _archivo():
    return os.path.join(_estudio(), '.the-edit-lab', 'licencia-carruseles.json')


def carpeta_modulo():
    return os.path.join(_estudio(), '.the-edit-lab', 'carruseles')


def _bin():
    return os.path.join(_estudio(), '.the-edit-lab', 'datos', 'carruseles.bin')


def verificar(correo, clave):
    """Datos de la licencia de Carruseles si la clave es válida para ese correo; si no, None."""
    try:
        clave = ''.join((clave or '').split())
        if not clave.upper().startswith('EDCAR'):
            return None
        clave = clave[5:].strip('-')
        cuerpo, _, firma = clave.partition('.')
        datos = licencia._b32d(cuerpo)
        s = int.from_bytes(licencia._b32d(firma), 'big')
        if pow(s, licencia.E, licencia.N) != licencia._num(PREFIJO_FIRMA + datos):
            return None
        x = json.loads(datos.decode())
        if x.get('p') != 'car' or not x.get('k'):
            return None
        if x.get('c'):
            if x['c'].strip().lower() != (correo or '').strip().lower():
                return None
        elif '@' not in (correo or ''):
            return None
        else:
            x['c'] = correo.strip().lower()
        return x
    except Exception:
        return None


def _canceladas():
    try:
        with open(os.path.join(_estudio(), '.the-edit-lab', 'datos', 'licencias-canceladas.json'), encoding='utf-8') as f:
            j = json.load(f)
        car = j.get('carruseles') or {}
        return set(str(n) for n in (car.get('numeros') or [])), set(c.strip().lower() for c in (car.get('correos') or []) + (j.get('correos') or []))
    except Exception:
        return set(), set()


def _lic():
    try:
        g = json.load(open(_archivo(), encoding='utf-8'))
        return verificar(g.get('correo'), g.get('clave'))
    except Exception:
        return None


def estado():
    """Siempre pide su propia licencia de Carruseles (también en modo de pruebas del Lab)."""
    x = _lic()
    if not x:
        return {'ok': False}
    nums, correos = _canceladas()
    if str(x.get('n')) in nums or x['c'] in correos:
        return {'ok': False, 'cancelada': True, 'error': 'Esta licencia de Carruseles fue cancelada. Si crees que es un error, escribe a theclariedit@gmail.com.'}
    base = licencia.estado()
    if not base.get('ok'):
        return {'ok': False, 'error': 'Primero activa tu licencia de The Edit Lab.'}
    return {'ok': True, 'correo': x['c'], 'nombre': x.get('a', ''), 'n': x.get('n'), 'desde': x.get('f'), 'listo': os.path.isfile(os.path.join(carpeta_modulo(), 'ui.js'))}


def activar(correo, clave):
    x = verificar(correo, clave)
    if not x:
        if ''.join((clave or '').split()).upper().startswith('EDLAB'):
            return {'ok': False, 'error': 'Esa es tu clave de The Edit Lab. Para Carruseles necesitas la clave de Carruseles (empieza con EDCAR-).'}
        return {'ok': False, 'error': 'No pude activar Carruseles con esos datos. Revisa que el correo sea el de tu compra y que la clave esté completa (empieza con EDCAR-).'}
    os.makedirs(os.path.dirname(_archivo()), exist_ok=True)
    with open(_archivo(), 'w', encoding='utf-8') as f:
        json.dump({'correo': correo.strip(), 'clave': ''.join(clave.split()), 'activada': time.strftime('%Y-%m-%d')}, f, ensure_ascii=False, indent=1)
    abrir()
    return estado()


# ---------- la extensión cifrada ----------
def _flujo(k, nonce, n):
    out, i = bytearray(), 0
    while len(out) < n:
        out += hashlib.sha256(k + nonce + i.to_bytes(8, 'big')).digest(); i += 1
    return bytes(out[:n])


def descifrar(blob, k):
    if blob[:6] != b'EDCAR1':
        raise ValueError('archivo raro')
    nonce, mac, ct = blob[6:22], blob[22:54], blob[54:]
    if not hmac.compare_digest(hmac.new(k, nonce + ct, hashlib.sha256).digest(), mac):
        raise ValueError('no coincide')
    return bytes(a ^ b for a, b in zip(ct, _flujo(k, nonce, len(ct))))


def guardar_bin(datos):
    os.makedirs(os.path.dirname(_bin()), exist_ok=True)
    with open(_bin() + '.tmp', 'wb') as f:
        f.write(datos)
    os.replace(_bin() + '.tmp', _bin())


def abrir():
    """Abre la extensión desde cero (cada vez que arranca el Lab), solo con licencia válida. Devuelve True si quedó lista."""
    x = _lic()
    dest = carpeta_modulo()
    if not x or not estado().get('ok') or not os.path.isfile(_bin()):
        if not x and os.path.isdir(dest):
            shutil.rmtree(dest, ignore_errors=True)   # sin licencia no se queda nada abierto
        return False
    try:
        tgz = descifrar(open(_bin(), 'rb').read(), bytes.fromhex(x['k']))
        tmp = dest + '.nuevo'
        shutil.rmtree(tmp, ignore_errors=True)
        with tarfile.open(fileobj=io.BytesIO(tgz), mode='r:gz') as t:
            for m in t.getmembers():
                if m.name.startswith(('/', '..')) or '/../' in m.name or not (m.isfile() or m.isdir()):
                    continue
                t.extract(m, tmp)
        shutil.rmtree(dest, ignore_errors=True)
        os.replace(tmp, dest)
        _al_motor(dest)
        return True
    except Exception:
        return False


def _al_motor(dest):
    """Las piezas de diseño van al motor de la compu (el mismo de los videos)."""
    motor = os.path.expanduser('~/.cvs-motor/remotion')
    if not os.path.isdir(motor):
        return
    r = os.path.join(dest, 'remotion')
    if os.path.isdir(os.path.join(r, 'src-carrusel')):
        shutil.rmtree(os.path.join(motor, 'src-carrusel'), ignore_errors=True)
        shutil.copytree(os.path.join(r, 'src-carrusel'), os.path.join(motor, 'src-carrusel'))
    if os.path.isfile(os.path.join(r, 'carrusel.mjs')):
        shutil.copy2(os.path.join(r, 'carrusel.mjs'), os.path.join(motor, 'carrusel.mjs'))


def version_local():
    try:
        return open(os.path.join(carpeta_modulo(), 'VERSION'), encoding='utf-8').read().strip()
    except Exception:
        return ''


if __name__ == '__main__':
    a = sys.argv[1:]
    r = activar(a[1], a[2]) if a[:1] == ['activar'] and len(a) >= 3 else estado()
    print(json.dumps(r, ensure_ascii=False))
    sys.exit(0 if r.get('ok') else 1)
