"""Paso 10: anima subtítulos y efectos con Remotion, une con la mezcla de audio y guarda la versión nueva.

Uso:
  python3 final.py preparar <proyecto> --motor <motor/remotion> --estilo <estilo.json> --fuentes <carpeta Fuentes>
  python3 final.py render   <proyecto> --motor <motor/remotion> [--tiempo 150] [--desde 0 --hasta N]
  python3 final.py unir     <proyecto> --nombre <nombre-del-video>
  python3 final.py fotos    <proyecto> --motor <motor/remotion> --momentos 0.4,3.2,7.9 [--leyendas "hook|lista|cierre"]
- fotos (hoja de momentos): un cuadro REAL ya animado de cada momento (con títulos detrás de su silueta si los hay), numerado,
  con el número, el tiempo y la leyenda escritos abajo → trabajo/momentos/momento_<n>.jpg (360 px de ancho) y momentos.jpg (todos juntos).
- preparar: copia timeline, cues, cara y estilo al motor, el video base y las fuentes.
- render: genera el video en tramos de 450 cuadros (15 s). Es reanudable: córrelo hasta que diga TERMINADO.
  Con --desde/--hasta (segundos) renderiza solo ese pedazo como vista previa en trabajo/prevista.mp4.
- unir: junta los tramos con mezcla.wav y guarda resultado/<nombre>_v<N>.mp4 sin borrar versiones anteriores.
"""
import argparse, os, sys, glob, shutil, time, subprocess, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, load_json, save_json, NPX

ap = argparse.ArgumentParser()
ap.add_argument('accion', choices=['preparar', 'render', 'unir', 'fotos']); ap.add_argument('proyecto')
ap.add_argument('--motor'); ap.add_argument('--estilo'); ap.add_argument('--fuentes'); ap.add_argument('--nombre', default='video'); ap.add_argument('--salida', help='carpeta donde además se guarda una copia (Mis videos)')
ap.add_argument('--momentos', default=''); ap.add_argument('--leyendas', default='');
ap.add_argument('--tiempo', type=float, default=150); ap.add_argument('--desde', type=float); ap.add_argument('--hasta', type=float)
a = ap.parse_args()
P = os.path.abspath(a.proyecto); T = os.path.join(P, 'trabajo'); R = os.path.join(T, 'render'); FPS = 30; CH = 450

def link_or_copy(s, d):
    if os.path.exists(d): os.remove(d)
    try: os.link(s, d)
    except OSError: shutil.copy(s, d)

if a.accion == 'preparar':
    M = a.motor; src = os.path.join(M, 'src'); pub = os.path.join(M, 'public'); os.makedirs(os.path.join(pub, 'fonts'), exist_ok=True)
    # revisión de acomodo ANTES de animar (siempre): nada fuera de la pantalla ni encima de su cara; arregla lo que puede y avisa lo demás
    try:
        _fl = [x for x in (os.path.join(a.fuentes or '', (load_json(a.estilo).get('fuentes') or {}).get('titulos') or '_'),) if os.path.exists(x)]
        rl = subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'revisar_layout.py'), P] + (['--fuente', _fl[0]] if _fl else []),
                            capture_output=True, text=True)
        if (rl.stdout or '').strip(): print(rl.stdout.strip(), flush=True)
    except Exception as ex:
        print(f'AVISO: no pude revisar el acomodo ({ex}); sigo igual', flush=True)
    for f in ('timeline.json', 'cues.json', 'cara.json'):
        shutil.copy(os.path.join(T, f), os.path.join(src, f))
    est = load_json(a.estilo); shutil.copy(a.estilo, os.path.join(src, 'estilo.json'))
    shutil.copy(a.estilo, os.path.join(T, 'estilo_usado.json'))   # para la portada y para exportar después con el mismo estilo
    if a.fuentes: open(os.path.join(T, 'fuentes_usadas.txt'), 'w').write(os.path.abspath(a.fuentes))
    link_or_copy(os.path.join(T, 'base.mp4'), os.path.join(pub, 'base.mp4'))
    for k in ('subtitulos', 'titulos', 'respaldo_subtitulos', 'respaldo_titulos'):
        fn = est['fuentes'].get(k)
        if not fn: continue
        for cand in (os.path.join(a.fuentes, fn), os.path.join(pub, 'fonts', fn)):
            if os.path.exists(cand):
                if os.path.abspath(cand) != os.path.abspath(os.path.join(pub, 'fonts', fn)): shutil.copy(cand, os.path.join(pub, 'fonts', fn))
                break
        else:
            print(f'AVISO: no encontré la fuente {fn}; se usará la de respaldo')
    for img in load_json(os.path.join(T, 'cues.json'))['overlays']:
        if img.get('image'):
            hit = [p for p in (os.path.join(P, img['image']), os.path.join(P, 'crudo', img['image'])) if os.path.exists(p)]
            if hit: shutil.copy(hit[0], os.path.join(pub, os.path.basename(img['image'])))
            else: print(f"AVISO: no encontré la imagen {img['image']} en la carpeta del proyecto")
    # efectos propios de la clienta: EST/efectos-propios/<kind>.tsx → src/propios/ + índice
    EST = os.path.dirname(os.path.abspath(a.estilo)); pd = os.path.join(src, 'propios')
    shutil.rmtree(pd, ignore_errors=True); os.makedirs(pd)
    kinds = []
    for f in sorted(glob.glob(os.path.join(EST, 'efectos-propios', '*.tsx'))):
        k = os.path.splitext(os.path.basename(f))[0]
        if re.fullmatch(r'[a-z][a-z0-9_]*', k): shutil.copy(f, os.path.join(pd, k + '.tsx')); kinds.append(k)
        else: print(f'AVISO: {os.path.basename(f)}: el nombre debe ir en minúsculas, sin espacios ni acentos (ej. brillos.tsx)')
    with open(os.path.join(pd, 'index.ts'), 'w') as fh:
        fh.write(''.join(f"import {k} from './{k}';\n" for k in kinds))
        fh.write('export const PROPIOS: Record<string, any> = {' + ', '.join(kinds) + '};\n')
    if kinds: print('Efectos propios:', ', '.join(kinds))
    # stickers y animaciones de "Mis efectos" que usa este video
    for o in load_json(os.path.join(T, 'cues.json'))['overlays']:
        if o.get('kind') == 'catalogo':      # efectos del catálogo (HyperFrames), ya convertidos en video transparente en trabajo/hf/
            c = os.path.join(T, 'hf', o.get('file', ''))
            if os.path.exists(c): os.makedirs(os.path.join(pub, 'hf'), exist_ok=True); shutil.copy(c, os.path.join(pub, 'hf', o['file']))
            else: print(f"AVISO: falta trabajo/hf/{o.get('file')}: vuelve a convertir ese efecto del catálogo")
            continue
        if o.get('file') and not os.path.exists(os.path.join(pub, 'mis', o['file'])):
            c = os.path.join(EST, '.motor', 'mis', o['file'])
            if os.path.exists(c): os.makedirs(os.path.join(pub, 'mis'), exist_ok=True); shutil.copy(c, os.path.join(pub, 'mis', o['file']))
            else: print(f"AVISO: falta {o['file']}; corre mis_efectos.py")
    # los tramos ya animados se conservan: al renderizar, solo se rehacen los que cambiaron (ver «huella» en render)
    print('Listo para animar.')

elif a.accion in ('render', 'fotos'):
    M = a.motor; t0 = time.time(); os.makedirs(R, exist_ok=True)
    def detras(video, cuadro):   # títulos detrás de su silueta (detras.py); si algo falla, avisa y deja el video como está
        cu = load_json(os.path.join(M, 'src', 'cues.json'))['overlays']
        if not any(o.get('detras') for o in cu): return
        est = load_json(os.path.join(M, 'src', 'estilo.json'))
        fn = est.get('fuentes', {}).get('titulos') or ''
        propia = os.path.join(M, 'public', 'fonts', fn) if fn else ''
        fuente = propia if propia and os.path.exists(propia) else os.path.expanduser('~/.cvs-motor/fuentes/Inter-Bold.ttf')
        try:
            import detras as DET
            if DET.procesar(video, cuadro, cu, fuente, est.get('colores', {}).get('texto', '#FFFFFF')): print('  títulos detrás de la silueta: listos', flush=True)
        except Exception as ex:
            print(f'AVISO: no pude poner los títulos detrás de la silueta ({ex}).', flush=True)
    tl = load_json(os.path.join(M, 'src', 'timeline.json')); N = round(tl['duration_real'] * FPS)
    def render(fa, fb, out):
        for intento in range(3):
            # en su Mac se usan varios núcleos (mucho más rápido); si un intento falla, el siguiente va de uno en uno, como siempre
            nuc = 1
            if intento == 0 and os.environ.get('EDIT_LAB_LOCAL'):
                nuc = int(os.environ.get('EDIT_LAB_NUCLEOS') or max(1, min(8, (os.cpu_count() or 2) - 2)))   # casi todos sus núcleos: exporta mucho más rápido
            p = subprocess.run([NPX, 'remotion', 'render', 'src/index.ts', 'Main', out, f'--frames={fa}-{fb}', f'--concurrency={nuc}',
                                '--codec=h264', '--crf=17', '--muted', '--log=error'], cwd=M, capture_output=True, text=True)
            if p.returncode == 0 and os.path.exists(out): return
            err = (p.stderr or p.stdout)[-800:]
        raise SystemExit('Remotion falló:\n' + err)
    if a.accion == 'fotos':
        from PIL import Image, ImageDraw, ImageFont
        MD = os.path.join(T, 'momentos'); os.makedirs(MD, exist_ok=True)
        ts = [float(x) for x in a.momentos.replace(' ', '').split(',') if x]
        if not ts: raise SystemExit('Pon --momentos 0.4,3.2,… (segundos del video cortado)')
        ley = a.leyendas.split('|') if a.leyendas else []
        fpath = os.path.expanduser('~/.cvs-motor/fuentes/Inter-Bold.ttf')
        try: fnt = ImageFont.truetype(fpath, 22); fch = ImageFont.truetype(fpath, 17)
        except Exception: fnt = fch = ImageFont.load_default()
        hojas = []
        cuadros = [max(0, min(N - 1, int(round(t * FPS)))) for t in ts]
        # rápido: el navegador se abre UNA vez y saca todos los cuadros (antes era un render completo por foto)
        juntos = False
        if os.path.exists(os.path.join(M, 'fotos.mjs')):
            q = subprocess.run(['node', 'fotos.mjs', MD, ','.join(str(c) for c in cuadros)], cwd=M, capture_output=True, text=True)
            juntos = q.returncode == 0 and all(os.path.exists(os.path.join(MD, f'f{c}.png')) for c in cuadros)
        hay_detras = any(o.get('detras') for o in load_json(os.path.join(M, 'src', 'cues.json')).get('overlays', []))
        for n, t in enumerate(ts, 1):
            fa = cuadros[n - 1]; mp4 = os.path.join(MD, f'_m{n}.mp4'); png = os.path.join(MD, f'_m{n}.png')
            if juntos:
                os.replace(os.path.join(MD, f'f{fa}.png'), png) if os.path.exists(os.path.join(MD, f'f{fa}.png')) else shutil.copy(os.path.join(MD, f'f{cuadros[0]}.png'), png)
                if hay_detras:   # títulos detrás de su silueta: se aplican sobre ese cuadro
                    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', png, '-frames:v', '1', '-c:v', 'libx264', '-crf', '14', '-pix_fmt', 'yuv420p', mp4])
                    detras(mp4, fa); run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', mp4, '-frames:v', '1', png])
                else:
                    open(mp4, 'wb').close()
            else:
                render(fa, fa, mp4); detras(mp4, fa)
                run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', mp4, '-frames:v', '1', png])
            im = Image.open(png).convert('RGB').resize((360, 640), Image.LANCZOS)
            hoja = Image.new('RGB', (360, 640 + 74), (255, 255, 255)); hoja.paste(im, (0, 0)); d = ImageDraw.Draw(hoja)
            d.text((12, 648), f'{n}  ·  {int(t // 60)}:{t % 60:04.1f}', fill=(20, 20, 20), font=fnt)
            if n <= len(ley) and ley[n - 1].strip(): d.text((12, 678), ley[n - 1].strip()[:38], fill=(90, 90, 90), font=fch)
            out = os.path.join(MD, f'momento_{n}.jpg'); hoja.save(out, quality=82); hojas.append(hoja)
            os.remove(mp4); os.remove(png); print(f'  momento {n} ({t:.1f} s): listo', flush=True)
        col = min(4, len(hojas)); fil = (len(hojas) + col - 1) // col
        todo = Image.new('RGB', (col * 370 + 10, fil * 724 + 10), (245, 242, 236))
        for i, h in enumerate(hojas): todo.paste(h, (10 + (i % col) * 370, 10 + (i // col) * 724))
        todo.save(os.path.join(MD, 'momentos.jpg'), quality=80)
        print(f'Hoja de momentos: trabajo/momentos/ ({len(hojas)} fotos y momentos.jpg)'); sys.exit(0)
    if a.desde is not None:
        fa = int(a.desde * FPS); fb = min(N - 1, int((a.hasta or a.desde + 5) * FPS))
        out = os.path.join(T, 'prevista_sin_audio.mp4'); render(fa, fb, out); detras(out, fa)
        run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', out, '-ss', f'{fa / FPS:.3f}', '-t', f'{(fb - fa + 1) / FPS:.3f}', '-i', os.path.join(T, 'mezcla.wav'),
             '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', os.path.join(T, 'prevista.mp4')])
        os.remove(out); print('Vista previa: trabajo/prevista.mp4'); sys.exit(0)
    # huella de cada tramo de 15 s: lo que se ve en ese tramo (cortes, palabras, efectos, zooms) + lo que vale para todo
    # (estilo, fuentes, cara, efectos propios, video base). Si una versión nueva solo cambió un título en el 0:20, solo
    # se vuelve a animar el tramo donde está ese título; los demás se reusan tal cual (mucho menos tiempo).
    import hashlib, json as _j
    cu = load_json(os.path.join(M, 'src', 'cues.json'))
    def _h(*xs):
        h = hashlib.sha1()
        for x in xs: h.update((x if isinstance(x, bytes) else _j.dumps(x, sort_keys=True, ensure_ascii=False).encode()))
        return h.hexdigest()
    def _leer(p):
        try: return open(p, 'rb').read()
        except OSError: return b''
    bp = os.path.join(T, 'base.mp4'); bst = os.stat(bp) if os.path.exists(bp) else None
    glob_h = _h(_leer(bp + '.firma') or ([bst.st_size, int(bst.st_mtime)] if bst else 0), _leer(os.path.join(M, 'src', 'estilo.json')),
                _leer(os.path.join(M, 'src', 'cara.json')), sorted(os.listdir(os.path.join(M, 'public', 'fonts'))) if os.path.isdir(os.path.join(M, 'public', 'fonts')) else [],
                [_leer(f) for f in sorted(glob.glob(os.path.join(M, 'src', 'propios', '*.tsx')))], os.environ.get('EDIT_LAB_LICENCIA', ''))
    def huella(fa, fb):
        a0, a1 = fa / FPS - 1.0, (fb + 1) / FPS + 1.0           # con margen: una animación puede asomarse antes o después
        dentro = lambda x0, x1: x0 < a1 and x1 > a0
        return _h(glob_h, fa, fb,
                  [o for o in cu.get('overlays', []) if dentro(o.get('t0', 0), o.get('t1', 1e9))],
                  [z for z in cu.get('zooms', []) if dentro(z.get('t0', 0), z.get('t1', 1e9))],
                  [w for w in tl.get('words', []) if dentro(w.get('s', 0), w.get('e', 0))],
                  [[c.get('t0_real', c.get('t0')), c.get('frames')] for c in tl.get('clips', [])])
    total = -(-N // CH)
    for f in glob.glob(os.path.join(R, 'r*.mp4')):               # tramos de más (el video quedó más corto)
        m_ = re.match(r'r(\d+)\.mp4$', os.path.basename(f))
        if m_ and int(m_.group(1)) >= total: os.remove(f)
    k = 0; reusados = 0
    for fa in range(0, N, CH):
        out = os.path.join(R, f'r{k:03d}.mp4'); k += 1
        hu = huella(fa, min(N - 1, fa + CH - 1))
        if os.path.exists(out) and _leer(out + '.firma').decode(errors='ignore') == hu:
            reusados += 1; continue
        if os.path.exists(out): os.remove(out)
        if time.time() - t0 > a.tiempo:
            print(f'PAUSA: {k - 1} de {-(-N // CH)} tramos listos. Vuelve a correr el mismo comando.'); sys.exit(3)
        render(fa, min(N - 1, fa + CH - 1), out + '.tmp.mp4'); detras(out + '.tmp.mp4', fa); os.replace(out + '.tmp.mp4', out)
        open(out + '.firma', 'w').write(hu)
        print(f'tramo {k}/{-(-N // CH)}', flush=True)
    if reusados: print(f'Reusé {reusados} de {total} tramos que no cambiaron.')
    print('TERMINADO')

else:
    parts = sorted(glob.glob(os.path.join(R, 'r*.mp4')))
    if not parts: raise SystemExit('Primero corre render.')
    lst = os.path.join(R, 'lista.txt')
    with open(lst, 'w') as f:
        for p in parts: f.write(f"file '{os.path.basename(p)}'\n")
    out_dir = os.path.join(P, 'resultado'); os.makedirs(out_dir, exist_ok=True)
    nombre = re.sub(r'[^\w\-]+', '-', a.nombre.strip().lower()).strip('-') or 'video'
    v = 1
    while os.path.exists(os.path.join(out_dir, f'{nombre}_v{v}.mp4')): v += 1
    out = os.path.join(out_dir, f'{nombre}_v{v}.mp4')
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', lst, '-i', os.path.join(T, 'mezcla.wav'),
         '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart'] + (['-metadata', 'comment=' + os.environ['EDIT_LAB_LICENCIA']] if os.environ.get('EDIT_LAB_LICENCIA') else []) + [out])
    if a.salida:
        os.makedirs(a.salida, exist_ok=True); w = 1
        while os.path.exists(os.path.join(a.salida, f'{nombre}_v{w}.mp4')): w += 1
        shutil.copy(out, os.path.join(a.salida, f'{nombre}_v{w}.mp4')); out = os.path.join(a.salida, f'{nombre}_v{w}.mp4')
    print(f'GUARDADO: {out}')
