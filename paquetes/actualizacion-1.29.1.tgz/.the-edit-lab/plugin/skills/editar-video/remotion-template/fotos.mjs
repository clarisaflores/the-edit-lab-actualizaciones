// Hoja de momentos rápida: abre el navegador UNA vez y saca todos los cuadros pedidos (en vez de un render por foto).
// Uso: node fotos.mjs <salida_dir> <cuadro1,cuadro2,...>
import path from 'node:path';
import {bundle} from '@remotion/bundler';
import {selectComposition, renderStill, openBrowser} from '@remotion/renderer';

const [, , salida, lista] = process.argv;
const cuadros = String(lista || '').split(',').filter(Boolean).map(Number);
const entry = path.resolve('src/index.ts');
const serveUrl = await bundle({entryPoint: entry, publicDir: path.resolve('public'), onProgress: () => {}});
const browser = await openBrowser('chrome');
try {
  const composition = await selectComposition({serveUrl, id: 'Main', puppeteerInstance: browser, logLevel: 'error'});
  for (const f of cuadros) {
    const frame = Math.max(0, Math.min(composition.durationInFrames - 1, f));
    await renderStill({composition, serveUrl, frame, output: path.join(salida, `f${f}.png`), imageFormat: 'png',
      puppeteerInstance: browser, logLevel: 'error'});
    console.log('cuadro ' + f + ' listo');
  }
} finally {
  await browser.close({silent: true});
}
