"""Crea 6 efectos de sonido básicos, sintetizados aquí mismo (sin licencias de terceros).

Uso: python3 sonidos_base.py <carpeta Efectos de sonido>
No reemplaza archivos que ya existan: si la clienta pone los suyos con el mismo nombre, se usan los de ella.
  inicio.wav  brillo ascendente para el gancho
  pop.wav     burbuja corta para listas y cajas
  teclas.wav  tecleo de 6 s (se recorta a lo que dure el texto)
  ding.wav    campanita para pasos
  click.wav   clic de ratón para imágenes
  cierre.wav  golpe suave de cierre al final
"""
import os, sys, wave
import numpy as np

SR = 48000
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
rng = np.random.default_rng(7)
t_ = lambda d: np.arange(int(d * SR)) / SR

def env(n, a=0.005, r=0.2):
    t = np.arange(n) / SR; return np.minimum(1, t / a) * np.exp(-t / r)

def inicio():
    t = t_(1.4); y = np.zeros_like(t)
    for k, f in enumerate([1318, 1760, 2093, 2637, 3136, 3520]):
        s = int(k * 0.09 * SR); seg = t[:len(t) - s]
        y[s:] += np.sin(2 * np.pi * f * seg) * env(len(seg), 0.004, 0.35) * 0.35
    sh = rng.standard_normal(len(t)) * np.linspace(0, 1, len(t)) ** 2 * np.exp(-t * 2.2) * 0.05
    return y + np.convolve(sh, np.ones(8) / 8, 'same')

def pop():
    t = t_(0.16); f = 380 + 900 * np.exp(-t * 40)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.002, 0.035)

def teclas():
    y = np.zeros(int(6 * SR)); t = 0.05
    while t < 5.9:
        n = int(0.025 * SR); c = rng.standard_normal(n) * env(n, 0.0005, 0.006)
        c = np.convolve(c, [1, -0.85], 'same') * rng.uniform(0.35, 0.7)
        i = int(t * SR); y[i:i + n] += c[:len(y) - i]; t += rng.uniform(0.06, 0.16)
    return y

def ding():
    t = t_(1.3)
    return sum(np.sin(2 * np.pi * f * t) * g for f, g in [(1568, 1), (3136, 0.35), (4704, 0.12)]) * env(len(t), 0.003, 0.35) * 0.5

def click():
    y = np.zeros(int(0.12 * SR))
    for s, g in [(0, 1), (0.045, 0.6)]:
        n = int(0.012 * SR); c = rng.standard_normal(n) * env(n, 0.0003, 0.002) * g; i = int(s * SR); y[i:i + n] += c
    return np.convolve(y, [1, -0.6], 'same')

def cierre():
    t = t_(0.9); thump = np.sin(2 * np.pi * (60 + 50 * np.exp(-t * 18)) * t) * env(len(t), 0.002, 0.12)
    n = rng.standard_normal(len(t)) * env(len(t), 0.001, 0.03) * 0.4
    return thump + np.convolve(n, np.ones(30) / 30, 'same') * 3

for name, fn in [('inicio', inicio), ('pop', pop), ('teclas', teclas), ('ding', ding), ('click', click), ('cierre', cierre)]:
    p = os.path.join(out, name + '.wav')
    if os.path.exists(p): continue
    y = fn(); y = y / (np.abs(y).max() or 1) * 0.8
    w = wave.open(p, 'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((y * 32767).astype(np.int16).tobytes()); w.close()
    print('creado', name + '.wav')
