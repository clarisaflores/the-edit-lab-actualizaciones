#!/usr/bin/env bash
# Instala el motor de edición. Uso: bash instalar.sh <carpeta_estudio> <paso>
#   paso = revisar | python | recursos | remotion | hyperframes | voz [small|medium] | todo
# Cada paso tarda menos de 3 minutos y se puede repetir sin problema (no reinstala lo que ya está).
# El motor vive en ~/.cvs-motor (rápido); lo que cuesta descargar se guarda también en <estudio>/.motor para la próxima vez.
set -u
EST="${1:?falta la carpeta del estudio}"; PASO="${2:-revisar}"
PLUG="$(cd "$(dirname "$0")/../../.." && pwd)"      # raíz del plugin
M="$HOME/.cvs-motor"; CACHE="$EST/.motor"
mkdir -p "$M/modelos" "$M/fuentes" "$CACHE/modelos" "$CACHE/fuentes"
export PATH="$HOME/.cvs-motor/bin:$HOME/.local/bin:$PATH"   # en Mac (modo local) su Python propio va primero
mkdir -p "$M/scripts" && cp -R "$PLUG/skills/editar-video/scripts/." "$M/scripts/" 2>/dev/null   # siempre la versión del plugin
# Carpetas reales (respeta "carpetas" de estilo.json: la clienta puede apuntarlas a sus propias carpetas)
eval "$(python3 "$PLUG/skills/editar-video/scripts/carpetas.py" "$EST")"
mkdir -p "$EST/Proyectos" "$PARA_EDITAR" "$REFERENCIAS" "$FUENTES" "$SONIDOS" "$MIS_VIDEOS" "$MIS_EFECTOS"

baja() { # baja <url> <destino>  (usa la copia guardada si ya existe)
  local url="$1" dst="$2" c="$CACHE/${2#$M/}"
  [ -s "$dst" ] && return 0
  if [ -s "$c" ]; then cp "$c" "$dst"; return 0; fi
  curl -fsSL --retry 2 -o "$dst.part" "$url" && mv "$dst.part" "$dst" && mkdir -p "$(dirname "$c")" && cp "$dst" "$c"
}

revisar() {
  local ok=1
  for b in ffmpeg node npx python3 curl; do command -v $b >/dev/null || { echo "FALTA: $b"; ok=0; }; done
  python3 -c "import faster_whisper, cv2, numpy" 2>/dev/null && echo "python: listo" || { echo "python: falta (paso python)"; ok=0; }
  [ -s "$EST/estilo.json" ] && echo "estilo: listo" || echo "estilo: falta (crear-mi-estilo)"
  for f in modelos/bd.rnnn modelos/face_detection_yunet_2023mar.onnx fuentes/Inter-Bold.ttf; do [ -s "$M/$f" ] || { echo "recursos: falta $f (paso recursos)"; ok=0; }; done
  [ -d "$M/remotion/node_modules/remotion" ] && echo "remotion: listo" || { echo "remotion: falta (paso remotion)"; ok=0; }
  [ -x "$M/hyperframes/node_modules/.bin/hyperframes" ] && echo "hyperframes: listo" || echo "hyperframes: falta (paso hyperframes; solo para el catálogo de efectos)"
  if [ "$(ls "$SONIDOS" 2>/dev/null | wc -l)" -eq 0 ]; then
    if [ "$SONIDOS_PROPIOS" = 1 ]; then echo "AVISO: tu carpeta de efectos de sonido está vacía (tus Reels irán sin sonidos hasta que pongas algunos)"
    else echo "sonidos: faltan (paso recursos)"; ok=0; fi
  fi
  python3 "$PLUG/skills/editar-video/scripts/carpetas.py" "$EST" --revisar
  python3 -c "import sys; sys.path.insert(0, '$PLUG/skills/editar-video/scripts'); import detras; sys.exit(0 if detras.disponible() else 1)" 2>/dev/null && echo "silueta: lista" || echo "AVISO: sin recorte de silueta (títulos detrás de ti irán delante); corre los pasos python y recursos"
  ffmpeg -hide_banner -filters 2>/dev/null | grep -q arnndn || echo "AVISO: este ffmpeg no tiene arnndn; la limpieza de ruido usará solo afftdn"
  [ $ok = 1 ] && echo "MOTOR LISTO" || echo "MOTOR INCOMPLETO"
}

python_() {
  # En un entorno propio (venv) se instala ahí; si no, en la carpeta del usuario.
  local U="--user"; python3 -c 'import sys; sys.exit(0 if sys.prefix != sys.base_prefix else 1)' && U=""
  python3 -m pip install $U --quiet --disable-pip-version-check --break-system-packages faster-whisper opencv-python-headless numpy pillow 2>&1 | tail -3 \
  || python3 -m pip install $U --quiet faster-whisper opencv-python-headless numpy pillow 2>&1 | tail -3
  # títulos detrás de la silueta (opcional: si no se instala, esos títulos van delante)
  python3 -m pip install $U --quiet --disable-pip-version-check --break-system-packages mediapipe 2>&1 | tail -2 || python3 -m pip install $U --quiet mediapipe 2>&1 | tail -2
}

voz() { # baja solo los modelos de voz que se van a usar (pesan mucho: medium ~1.5 GB, small ~0.5 GB)
  local mods="${*:-medium}"
  python3 - $mods <<'PYEOF'
import sys
from faster_whisper import WhisperModel
for m in sys.argv[1:]:
    WhisperModel(m, device="cpu", compute_type="int8"); print("modelo de voz listo:", m)
PYEOF
}

recursos() {
  baja https://raw.githubusercontent.com/richardpl/arnndn-models/master/bd.rnnn "$M/modelos/bd.rnnn"
  baja https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx "$M/modelos/face_detection_yunet_2023mar.onnx" \
   || baja https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx "$M/modelos/face_detection_yunet_2023mar.onnx"
  baja https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite "$M/modelos/selfie_segmenter.tflite" || echo "AVISO: no se pudo bajar el recorte de silueta; los títulos detrás de ti irán delante"
  G=https://raw.githubusercontent.com/google/fonts/main/ofl
  baja "$G/instrumentserif/InstrumentSerif-Regular.ttf" "$M/fuentes/InstrumentSerif-Regular.ttf"
  baja "$G/inter/Inter%5Bopsz,wght%5D.ttf" "$M/fuentes/Inter-Bold.ttf"
  baja "$G/anton/Anton-Regular.ttf" "$M/fuentes/Anton-Regular.ttf"
  baja "$G/caveat/Caveat%5Bwght%5D.ttf" "$M/fuentes/Caveat-Bold.ttf"
  if [ "$SONIDOS_PROPIOS" = 1 ]; then echo "sonidos: uso los tuyos (no agrego sonidos base a tu carpeta)"; else python3 "$PLUG/skills/preparar-estudio/scripts/sonidos_base.py" "$SONIDOS"; fi
  ls -la "$M/modelos" "$M/fuentes" | grep -v total
}

hyperframes() {
  # Catálogo de efectos: HyperFrames (HeyGen, Apache 2.0), versión fija. Sin telemetría: nada de ella sale de su compu.
  export HYPERFRAMES_TELEMETRY=0 DO_NOT_TRACK=1 HYPERFRAMES_SKIP_SKILLS=1
  mkdir -p "$M/hyperframes" && cd "$M/hyperframes" || return 1
  [ -f package.json ] || echo '{"name":"tel-hyperframes","private":true}' > package.json
  npm install --no-audit --no-fund --loglevel=error hyperframes@0.9.6 2>&1 | tail -3
  ./node_modules/.bin/hyperframes telemetry disable >/dev/null 2>&1
  ./node_modules/.bin/hyperframes browser ensure 2>&1 | tail -1
  ./node_modules/.bin/hyperframes catalog --json > "$M/hyperframes/catalogo.json" 2>/dev/null
}

remotion() {
  mkdir -p "$M/remotion"; chmod -R u+w "$M/remotion" 2>/dev/null
  cp -R "$PLUG/skills/editar-video/remotion-template/." "$M/remotion/"
  cd "$M/remotion" && npm install --no-audit --no-fund --loglevel=error 2>&1 | tail -3
  mkdir -p public/fonts public/emoji && cp "$M"/fuentes/*.ttf public/fonts/ 2>/dev/null
  npx remotion browser ensure 2>&1 | tail -1
  [ -d node_modules/emoji-datasource-google/img/google/64 ] && echo "emojis listos"
}

case "$PASO" in
  revisar) revisar ;;
  python) python_ ;;
  recursos) recursos ;;
  remotion) remotion ;;
  hyperframes) hyperframes ;;
  voz) shift 2; voz "$@" ;;
  todo) python_; voz medium small; recursos; remotion; hyperframes; revisar ;;
  *) echo "paso desconocido: $PASO"; exit 1 ;;
esac
