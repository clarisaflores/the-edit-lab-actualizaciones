# Plantilla de GUIA_DE_ESTILO.md

Usa exactamente estas secciones (títulos en español). Cada regla con "Visto en: Vx, Vy".

1. **Análisis por video**: tabla con gancho (0–3 s), duración, ritmo medido y recurso más destacado.
2. **Esencia**: una frase y 3 a 5 palabras clave.
3. **Paleta**: tabla de hex medidos, dónde salen y su uso.
4. **Tipografías**: lo que se ve, la fuente real si la clienta la confirma, y la alternativa gratuita.
5. **Reglas de subtítulos**: palabras por pantalla, posición fija (x, y en 1080×1920), tamaño en px, color, animación, puntuación.
6. **Ritmo y cortes**: cortes por minuto, plano promedio, silencios máximos, zooms o no, cierre.
7. **Catálogo de textos y gráficos**: tabla de recurso, cómo se ve, en qué videos; y la lista de casualidades.
8. **Encuadre**: plano, posición de la cara (% de x y), fondo, luz, zonas libres para texto.
9. **Sonido**: LUFS, música sí/no, efectos y en qué momentos.
10. **Tono y voz**: palabras por minuto, largo de frase, muletillas, energía.
11. **Estructura base**: bloques con tiempos, fórmulas de gancho y de llamado a la acción.
12. **Lo que NO hago**.
13. **Ejemplo aplicado**: un video de 30 s escena por escena.
14. **Verificación**: qué se midió y qué falta confirmar.
