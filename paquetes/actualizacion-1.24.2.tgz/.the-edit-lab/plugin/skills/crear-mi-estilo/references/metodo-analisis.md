# Método de análisis de referencias

Comandos probados (ffmpeg 4.4+, Python 3.10, OpenCV 4.x/5.x con FaceDetectorYN).

## Copias ligeras
```
ffmpeg -i REF.MP4 -vf "scale=540:960,fps=10" -c:v libx264 -preset ultrafast -crf 23 -an vN.mp4 -vn -ac 1 -ar 16000 aN.wav
```
Si el video viene acostado (cámara girada), agrega `transpose=1` antes de `scale`.

## Transcripción
faster-whisper `medium`, `compute_type='int8'`, `word_timestamps=True`, `language='es'`. En máquinas con menos de 4 GB de RAM, bloques de 100 s o menos; si el proceso muere (137), usa `small`.

## Cortes
1. `ffmpeg -i vN.mp4 -vf "select='gt(scene,0.04)',metadata=print:file=scN.txt" -f null -`
2. Junta los eventos a menos de 0.25 s. Confirma cada uno: la diferencia media entre el cuadro k y k-1 debe ser 2.5 veces o más la de k-1 y k-2. Lo que no pasa es un texto que aparece, no un corte.
3. Reporta cortes por minuto y plano promedio.

## Cara y zooms
YuNet (`face_detection_yunet_2023mar.onnx` de github.com/opencv/opencv_zoo) cada 2 cuadros. El ancho de la cara por segmento entre cortes: un cambio de más de 15 % sostenido es un zoom; de ±10 % es movimiento natural.

## Textos en pantalla
La mediana de la franja de arriba (0–230 px a 540 de ancho) es el fondo limpio. Los cuadros con más de 0.4 % de píxeles que difieren en más de 60 son texto o gráfico. Saca cuadros 4K en el centro de cada aparición y míralos en una hoja de contacto.

## Subtítulos
Recortes de la zona en alta resolución y una secuencia a 10 fps de 2 s: así se ve si van palabra por palabra, si tienen animación y dónde se quedan. Color: la mediana del 0.7 % de píxeles más brillantes del recorte. Posición y tamaño: la caja del texto en píxeles, convertida a 1080×1920.

## Color
k-means (k=8) sobre cuadros limpios de todos los videos para la paleta del fondo; muestreo directo para cada elemento (cajas, texto de cajas, portadas).

## Sonido
- `loudnorm=print_format=summary` para los LUFS.
- `silencedetect=noise=-40dB:d=0.25` para los silencios.
- Nivel entre palabras y planitud espectral para sospechar música. Pregunta siempre si usa música o efectos.
- Final: brillo medio de los últimos 2.5 s para detectar el fundido a negro.
