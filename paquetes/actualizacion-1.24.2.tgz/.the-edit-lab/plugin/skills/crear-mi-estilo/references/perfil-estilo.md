# Perfil de estilo (`estilo.json`)

Vive en la carpeta del estudio, junto a `GUIA_DE_ESTILO.md`. La guía explica el estilo con palabras y medidas; el perfil es lo que lee el motor de edición. Siempre se actualizan los dos juntos.

| Campo | Qué controla | Valores |
|---|---|---|
| `nombre`, `plantilla` | Nombre del estilo y plantilla de origen | texto; `editorial`, `minimal`, `bold`, `scrapbook` o `propio` |
| `colores.subtitulo` | Color de los subtítulos | hex |
| `colores.texto` | Títulos, listas, pasos | hex |
| `colores.caja`, `colores.caja_texto` | Cajas resaltadas | hex |
| `colores.resaltado`, `colores.resaltado_texto` | Palabra resaltada (karaoke) y palomitas del checklist | hex |
| `fuentes.subtitulos`, `fuentes.titulos` | Archivos de la carpeta `Fuentes` de la clienta | nombre de archivo o `null` |
| `fuentes.respaldo_*` | Fuente gratuita incluida cuando no hay propia o faltan letras (acentos, ñ, ¿, ¡) | `InstrumentSerif-Regular.ttf`, `Inter-Bold.ttf`, `Anton-Regular.ttf`, `Caveat-Bold.ttf` |
| `fuentes.ajuste_respaldo` | Tamaño de la fuente de respaldo en % para que sus letras no se vean más chicas | 100 a 150 |
| `subtitulos.modo` | Cómo salen | `palabra` (una a la vez), `frase` (grupo), `karaoke` (grupo con la actual resaltada), `ninguno` |
| `subtitulos.palabras_max` | Palabras por grupo | 1 a 6 |
| `subtitulos.tamano`, `peso` | Tamaño en px (a 1080×1920) y grosor | 36 a 90; 400 a 900 |
| `subtitulos.x`, `y` | Centro FIJO, en fracción del ancho y del alto | 0 a 1 |
| `subtitulos.ancho` | Ancho máximo, en fracción del ancho | 0.2 a 0.9 |
| `subtitulos.sombra`, `mayusculas` | | true / false |
| `subtitulos.sin_puntuacion`, `minusculas` | Quita comas y puntos; todo en minúsculas menos los nombres de `contenido.nombres_exactos` | true / false |
| `titulos.tamano`, `peso`, `zona`, `sombra`, `radio_caja` | Tamaño base de los textos, su franja vertical (`[0.10, 0.28]` = arriba) y las esquinas de las cajas | |
| `efectos.favoritos` | Efectos que se usan primero (ver `editar-video/references/efectos.md`) | lista de nombres |
| `efectos.por_minuto` | Cuántos textos o gráficos por minuto | 2 a 12 |
| `movimiento.acercamientos`, `escala`, `motion_blur`, `fundido_final` | Zooms suaves, cuánto, desenfoque de movimiento, segundos de fundido a negro (0 = sin fundido) | |
| `ritmo.pausa_max`, `duracion_ideal` | Silencio máximo que se deja y duración que suele buscar | segundos; texto |
| `sonidos.*` | Qué archivo de `Efectos de sonido` va en cada momento: `inicio`, `lista`, `escribir`, `paso`, `click`, `cierre` | nombre de archivo o `null` |
| `audio.lufs`, `musica`, `limpiar_ruido` | Volumen final, archivo de música de fondo (o `null`) y limpieza de ruido | -14; archivo/null; true |
| `contenido.despedida` | Frase fija de cierre (si la tiene; se dice, no se inventa) | texto |
| `contenido.llamados_favoritos`, `nombres_exactos`, `palabras_que_no_uso` | Para textos en pantalla y ortografía | listas |
| `carpetas.*` | Opcional. Apunta una carpeta del estudio a una carpeta suya que ya tiene ordenada: `para_editar`, `referencias`, `fuentes`, `efectos_de_sonido`, `mis_efectos`, `mis_videos`. Si falta una, se usa la del estudio | ruta relativa a la carpeta del estudio (`"../Brand Assets/01 LOGO & FONTS"`) o absoluta |
| `grabacion.repite_frases`, `toma_buena`, `camara_acostada` | Cómo graba | true/false; `ultima`/`primera`; `detectar`/true/false |

Si usa `carpetas.efectos_de_sonido`, los nombres en `sonidos.*` son los de SUS archivos (no hace falta renombrarlos) y el estudio no agrega sonidos base ahí.

Reglas: nunca pongas datos de otra persona en un perfil; los colores y medidas salen de sus referencias o de lo que ella elija; si cambia algo en el estudio o en el chat ("subtítulos más chicos siempre"), actualiza el perfil y la guía.
