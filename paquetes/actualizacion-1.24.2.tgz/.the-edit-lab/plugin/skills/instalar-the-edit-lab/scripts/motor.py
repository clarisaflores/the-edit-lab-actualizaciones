"""Empaqueta el motor de edición (las carpetas skills/ y .claude-plugin/ de este plugin) en un JSON
{"v": versión, "archivos": {"ruta": "base64"}} que la página guarda y el editor en segundo plano instala.

Uso: python3 motor.py <raíz del plugin> <salida.json>
"""
import base64, json, os, sys
raiz, salida = sys.argv[1], sys.argv[2]
v = json.load(open(os.path.join(raiz, '.claude-plugin', 'plugin.json')))['version']
archivos = {}
for dp, dn, fn in os.walk(raiz):
    dn[:] = [d for d in dn if d not in ('__pycache__', 'node_modules', '.git', 'instalar-the-edit-lab', 'actualizar-the-edit-lab')]
    for f in fn:
        if f.endswith('.pyc') or f in ('.DS_Store', 'icon.png') or f.endswith('.plugin'): continue
        p = os.path.join(dp, f)
        archivos[os.path.relpath(p, raiz)] = base64.b64encode(open(p, 'rb').read()).decode()
json.dump({'v': v, 'archivos': archivos}, open(salida, 'w'))
print(f'motor {v}: {len(archivos)} archivos → {salida} ({os.path.getsize(salida) // 1024} KB)')
