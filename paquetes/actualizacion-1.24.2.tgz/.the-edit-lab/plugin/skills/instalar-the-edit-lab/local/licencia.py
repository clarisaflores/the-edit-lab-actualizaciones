#!/usr/bin/env python3
"""The Edit Lab · licencia personal. Solo biblioteca estándar.

Cada copia de The Edit Lab se activa con una clave hecha para UNA persona (su correo).
La clave está firmada por The Clari Edit: no se puede inventar ni cambiar de dueña.
La página muestra siempre a nombre de quién está la licencia, y cada Reel que sale
lleva ese número de licencia guardado dentro del MP4.

  python3 licencia.py estado                 {"ok": true, "correo": ..., "n": ...}
  python3 licencia.py activar <correo> <clave>
"""
import base64, hashlib, json, os, sys, time

# Llave PÚBLICA de The Clari Edit (solo sirve para comprobar claves, no para hacerlas).
N = int('f244b2866d4742f8555e79df53380c89eabb2e97e3c5cc3b860f3de3d7739c758cb64fc549c93468318d19062608f733fc5ded7bf9fef842d6e004a1d550409816b416c49d47b0612759075e059af1be230c0450d963e16a37251782ec2b0e4cb8d9f335951c80e8a99343203b00bad993cd9564e6af271e35005968a3550a05b59343263b3586eb43a6c78f326f4d874a6a6805d1d3a5e25d1fdc87a206b9fe2b5a0e1fbf77d6262a3f83716e100f21b51b6a7182b8a212b1ce3c9ceaf08e2fab7f4872b79adc3d9b5d01123f12748612086aa98bb2c46de8aa919640ec90f69c8543a2f591ad961cb025fa7761ea3d2c257b1967632d6c78eb3bec478594cf', 16)
E = 65537


def _b32d(s):
    s = s.strip().upper().replace('-', '')
    return base64.b32decode(s + '=' * (-len(s) % 8))


def _num(h):
    return int.from_bytes(hashlib.sha256(h).digest(), 'big')


def verificar(correo, clave):
    """Devuelve los datos de la licencia si la clave es válida para ese correo; si no, None."""
    try:
        clave = ''.join(clave.split())
        if clave.upper().startswith('EDLAB'):
            clave = clave[5:]
        clave = clave.strip('-')
        cuerpo, _, firma = clave.partition('.')
        datos = _b32d(cuerpo)
        s = int.from_bytes(_b32d(firma), 'big')
        if pow(s, E, N) != _num(b'the-edit-lab|' + datos):
            return None
        x = json.loads(datos.decode())
        if x.get('c'):   # clave hecha para un correo: solo sirve con ese correo
            if x['c'].strip().lower() != (correo or '').strip().lower():
                return None
        elif '@' not in (correo or ''):   # clave de la tienda: se queda a nombre del correo con que se activa
            return None
        else:
            x['c'] = correo.strip().lower()
        return x
    except Exception:
        return None


def _archivo():
    est = os.path.abspath(os.environ.get('EDIT_LAB_ESTUDIO') or os.getcwd())
    return os.path.join(est, '.the-edit-lab', 'licencia.json')


def _sin_licencia():
    """Las licencias se prenden o se apagan desde la versión publicada (`licencias_activas` en plugin.json). Mientras
    están apagadas (pruebas), nadie necesita clave. Ese archivo es parte del programa: si alguien lo cambia, The Edit Lab
    vuelve a poner el original, así que no sirve para saltarse la licencia."""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', '.claude-plugin', 'plugin.json')
        with open(p, encoding='utf-8') as f:
            return not json.load(f).get('licencias_activas', False)
    except Exception:
        return False


def _canceladas():
    """Licencias que The Clari Edit canceló (copias compartidas o revendidas). Se baja sola de su GitHub."""
    try:
        with open(os.path.join(os.path.dirname(_archivo()), 'datos', 'licencias-canceladas.json'), encoding='utf-8') as f:
            j = json.load(f)
        return set(str(n) for n in (j.get('numeros') or [])), set(c.strip().lower() for c in (j.get('correos') or []))
    except Exception:
        return set(), set()


def estado():
    if _sin_licencia():
        return {'ok': True, 'correo': 'modo de pruebas', 'nombre': '', 'n': 'prueba', 'desde': ''}
    try:
        with open(_archivo(), encoding='utf-8') as f:
            g = json.load(f)
        x = verificar(g.get('correo'), g.get('clave'))
        if x:
            nums, correos = _canceladas()
            if str(x.get('n')) in nums or x['c'] in correos:
                return {'ok': False, 'cancelada': True, 'correo': x['c'], 'n': x.get('n'),
                        'error': 'Esta licencia de The Edit Lab fue cancelada. Si crees que es un error, escribe a theclariedit@gmail.com.'}
            return {'ok': True, 'correo': x['c'], 'nombre': x.get('a', ''), 'n': x.get('n'), 'desde': x.get('f')}
    except Exception:
        pass
    return {'ok': False}


def activar(correo, clave):
    x = verificar(correo, clave)
    if not x:
        return {'ok': False, 'error': 'No pude activar con esos datos. Revisa que el correo sea el de tu compra y que la clave esté completa (empieza con EDLAB-).'}
    p = _archivo()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f:
        json.dump({'correo': correo.strip(), 'clave': ''.join(clave.split()), 'activada': time.strftime('%Y-%m-%d')}, f, ensure_ascii=False, indent=1)
    return estado()


if __name__ == '__main__':
    a = sys.argv[1:]
    if a[:1] == ['activar'] and len(a) >= 3:
        r = activar(a[1], a[2])
    else:
        r = estado()
    print(json.dumps(r, ensure_ascii=False))
    sys.exit(0 if r.get('ok') else 1)
