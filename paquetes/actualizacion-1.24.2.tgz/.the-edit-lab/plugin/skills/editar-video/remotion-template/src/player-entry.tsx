// Vista previa del editor de The Edit Lab: el MISMO Main.tsx del video final, dentro de @remotion/player.
// La página pone los datos en window.__TEL y un contenedor en window.__TEL_EL antes de cargar este archivo.
import React from 'react';
import {createRoot} from 'react-dom/client';
import {Player, PlayerRef} from '@remotion/player';
import {Main} from './Main';

const D: any = (window as any).__TEL;
const EL: HTMLElement = (window as any).__TEL_EL;
const FPS = 30;
const dur = Math.max(1, Math.round(((D.tl && (D.tl.duration_real || D.tl.duration)) || 1) * FPS));

const App: React.FC = () => {
  const ref = React.useRef<PlayerRef>(null);
  React.useEffect(() => {
    const p = ref.current; if (!p) return;
    const api: any = (window as any).__TEL_API || {};
    api.player = p; api.dur = dur / FPS;
    if (D.t0) p.seekTo(Math.min(dur - 1, Math.round(D.t0 * FPS)));
    if (D.mute) p.mute();
    if (D.play) p.play();
    if (typeof api.listo === 'function') api.listo(p);
  }, []);
  return <Player ref={ref} component={Main} durationInFrames={dur} fps={FPS} compositionWidth={1080} compositionHeight={1920}
    style={{width: '100%', height: '100%'}} controls={false} numberOfSharedAudioTags={12} clickToPlay={false} spaceKeyToPlayOrPause={false} acknowledgeRemotionLicense />;
};
const root = createRoot(EL);
((window as any).__TEL_API = (window as any).__TEL_API || {}).root = root;
root.render(<App />);
