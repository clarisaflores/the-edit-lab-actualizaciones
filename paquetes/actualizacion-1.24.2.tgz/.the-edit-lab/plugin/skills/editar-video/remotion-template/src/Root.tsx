import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import tl from './timeline.json';
const D = ((tl as any).duration_real ?? (tl as any).duration ?? 5) as number;
export const Root: React.FC = () => (
  <Composition id="Main" component={Main} fps={30} width={1080} height={1920} durationInFrames={Math.max(1, Math.round(D * 30))} />
);
