import React from 'react';
import {AbsoluteFill, OffthreadVideo, Sequence, staticFile, useCurrentFrame, interpolate, Easing, delayRender, continueRender, Img, Html5Video, Html5Audio} from 'remotion';
import {CameraMotionBlur} from '@remotion/motion-blur';
import {measureText} from '@remotion/layout-utils';
import tl from './timeline.json';   // scripts/linea_tiempo.py + scripts/cortar.py: cortes, palabras y duración real
import cues from './cues.json';     // scripts/cues.py: textos, gráficos, acercamientos y sonidos
import face from './cara.json';     // scripts/cara.py: centro y tamaño medio de la cara en el corte base
import E from './estilo.json';      // el perfil de estilo de la clienta (ver references/perfil-estilo.md)
import {PROPIOS} from './propios';  // efectos creados para esta clienta (skill crear-efecto); final.py arma este índice

const FPS = 30, W = 1080, H = 1920;
// Vista previa en el editor de la página (scripts de lab: player-entry.tsx): el mismo dibujo que el video final, pero el video
// sale de tu fuente con tus cortes del momento y suenan tu voz y tus efectos. En el render final VISTA es null.
const VISTA: any = typeof window !== 'undefined' ? (window as any).__TEL : null;
const S: any = E;
const col = S.colores, sub = S.subtitulos, tit = S.titulos, mov = S.movimiento;

// ---------- fuentes ----------
const fontsH = delayRender('fuentes');
const faces: FontFace[] = [];
const addFont = (fam: string, file: string | null | undefined, desc: any = {}) => { if (file) faces.push(new FontFace(fam, `url(${staticFile('fonts/' + file)})`, {weight: '100 900', ...desc})); };
addFont('SubA', S.fuentes.subtitulos);
addFont('SubB', S.fuentes.respaldo_subtitulos, {sizeAdjust: (S.fuentes.ajuste_respaldo || 100) + '%'});
addFont('TitA', S.fuentes.titulos);
addFont('TitB', S.fuentes.respaldo_titulos);
Promise.all(faces.map((f) => f.load().then((ff) => { (document.fonts as any).add(ff); }).catch(() => null)))
  .then(() => continueRender(fontsH));
const SUB_FONT = "'SubA','SubB',Georgia,serif";
const TIT_FONT = "'TitA','TitB','Helvetica Neue',Arial,sans-serif";

// ---------- emojis como imagen (public/emoji/<código>.png) ----------
const isEmo = (c: string) => /\p{Extended_Pictographic}/u.test(c);
const Emo: React.FC<{c: string}> = ({c}) => (
  <Img src={staticFile('emoji/' + c.codePointAt(0)!.toString(16) + '.png')} style={{height: '1em', width: '1em', verticalAlign: '-0.12em', margin: '0 0.06em'}} />
);
const Rich: React.FC<{text: string}> = ({text}) => (
  <>{Array.from(text).filter((c) => c !== '️').map((c, k) => (c === '\n' ? <br key={k} /> : isEmo(c) ? <Emo key={k} c={c} /> : <React.Fragment key={k}>{c}</React.Fragment>))}</>
);

// ---------- acercamientos ----------
const ZC = {x: (face as any).cx ?? W / 2, y: (face as any).cy ?? H * 0.36};
const RAMP = 0.35, BACK = 0.45, Z = mov.escala ?? 1.1;
const zoomAt = (t: number) => {
  let z = 1, ramp = false;
  if (!mov.acercamientos) return {z, ramp};
  for (const q of (cues as any).zooms) {
    if (t >= q.t0 && t < q.t1 + BACK) {
      const up = interpolate(t, [q.t0, q.t0 + RAMP], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
      const down = q.cut ? (t >= q.t1 ? 1 : 0) : interpolate(t, [q.t1, q.t1 + BACK], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
      z = 1 + (Z - 1) * up * (1 - down);
      ramp = t < q.t0 + RAMP || (!q.cut && t >= q.t1 && t < q.t1 + BACK);
    }
  }
  return {z, ramp};
};
const VideoLayer: React.FC = () => {
  const {z} = zoomAt(useCurrentFrame() / FPS);
  if (VISTA && VISTA.segs) {
    let acc = 0;
    return (
      <AbsoluteFill style={{transform: `scale(${z})`, transformOrigin: `${ZC.x}px ${ZC.y}px`}}>
        {(VISTA.segs as any[]).map((s, i) => {
          const v = s.vel || 1, n = Math.max(1, Math.round(((s.h - s.d) / v) * FPS)), from = Math.round(acc * FPS); acc += (s.h - s.d) / v;
          return <Sequence key={i} from={from} durationInFrames={n} layout="none"><SegZoom s={s} n={n}>
            <Html5Video src={staticFile('fuente.mp4')} startFrom={Math.round(s.d * FPS)} playbackRate={v} pauseWhenBuffering style={{width: '100%', height: '100%', objectFit: 'cover'}} /></SegZoom></Sequence>;
        })}
      </AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill style={{transform: `scale(${z})`, transformOrigin: `${ZC.x}px ${ZC.y}px`}}>
      {VISTA ? <Html5Video src={staticFile('base.mp4')} pauseWhenBuffering style={{width: '100%', height: '100%', objectFit: 'cover'}} /> : <OffthreadVideo src={staticFile('base.mp4')} muted />}
    </AbsoluteFill>
  );
};
const SegZoom: React.FC<{s: any; n: number; children: React.ReactNode}> = ({s, n, children}) => {
  const f = useCurrentFrame();
  let k = 1;
  if (s.zoom === 'in' || s.zoom === 'out') { let p = Math.max(0, Math.min(1, f / Math.max(1, n - 1))); p = p * p * (3 - 2 * p); k = s.zoom === 'in' ? 1 + 0.15 * p : 1.15 - 0.15 * p; }
  return <AbsoluteFill style={{transform: `scale(${k})`, transformOrigin: '50% 42%'}}>{children}</AbsoluteFill>;
};
const Sonidos: React.FC = () => {
  if (!VISTA) return null;
  const voz = VISTA.voz ? <Html5Audio src={staticFile(VISTA.voz)} /> : null;
  if (VISTA.sinSfx) return voz;
  return <>{voz}{(((cues as any).sfx || []) as any[]).map((x, i) => x.file ? <Sequence key={i} from={Math.max(0, Math.round(x.t * FPS))} durationInFrames={Math.max(6, Math.round((x.dur || 1.5) * FPS))} layout="none">
    <Html5Audio src={staticFile('sfx/' + x.file)} volume={Math.min(1, Math.pow(10, (x.db || 0) / 20) * 0.7)} /></Sequence> : null)}</>;
};

// ---------- subtítulos: "palabra" (una a la vez), "frase" (grupo) o "karaoke" (grupo con la palabra actual resaltada) ----------
type Wd = {w: string; s: number; e: number; res?: boolean};
const WORDS = (tl as any).words as Wd[];
const GROUPS: Wd[][] = (() => {
  const n = Math.max(1, sub.palabras_max || 1); const g: Wd[][] = []; let cur: Wd[] = [];
  WORDS.forEach((w, i) => { cur.push(w); const nx = WORDS[i + 1]; if (cur.length >= n || /[.?!,]$/.test(w.w) || !nx || nx.s - w.e > 0.35) { g.push(cur); cur = []; } });
  return g;
})();
// Títulos grandes que esconden los subtítulos mientras están en pantalla
const OCULTA = new Set(['titulo', 'gancho', 'palabra', 'cierre']);
const ocultaSubs = (t: number) => ((cues as any).overlays as any[]).some((o) => (OCULTA.has(o.kind) || o.oculta_subs) && t >= o.t0 && t <= o.t1);
// Palabras que se escriben tal cual (marcas, nombres); lo demás en minúsculas si el perfil lo pide
const EXACTAS = new Set(((S.contenido && S.contenido.nombres_exactos) || []).flatMap((n: string) => n.split(/\s+/)).map((x: string) => x.toLowerCase()));
const limpia = (w: string) => {
  let x = w;
  if (sub.sin_puntuacion) x = x.replace(/[.,;:¿?¡!…"“”«»]/g, '');
  if (sub.minusculas) { const lo = x.toLowerCase(); const hit = ((S.contenido && S.contenido.nombres_exactos) || []).flatMap((n: string) => n.split(/\s+/)).find((n: string) => n.toLowerCase() === lo); x = hit || lo; }
  return x;
};
const Caption: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  if (!WORDS.length || t < WORDS[0].s - 0.02 || sub.modo === 'ninguno') return null;
  if (ocultaSubs(t)) return null;
  let gi = 0; for (let i = 0; i < GROUPS.length; i++) { if (GROUPS[i][0].s <= t + 0.02) gi = i; else break; }
  const g = GROUPS[gi]; if (!g) return null;
  const cx = sub.x * W, cy = sub.y * H, maxW = (sub.ancho || 0.8) * W;
  const fmt = (s: string) => (sub.mayusculas ? limpia(s).toUpperCase() : limpia(s));
  let cw = WORDS[0], ci = 0; for (let i = 0; i < WORDS.length; i++) { if (WORDS[i].s <= t + 0.02) { cw = WORDS[i]; ci = i; } else break; }
  if (sub.modo === 'palabra') { const nx = WORDS[ci + 1]; if (t > cw.e + 0.15 && (!nx || nx.s - cw.e > 0.3)) return null; }
  const txt = sub.modo === 'palabra' ? fmt(cw.w) : g.map((w) => fmt(w.w)).join(' ');
  const base = sub.tamano || 48;
  const meas = measureText({text: txt, fontFamily: SUB_FONT, fontSize: base, fontWeight: String(sub.peso || 400)}).width;
  const size = sub.modo === 'palabra' ? Math.max(base * 0.72, Math.min(base, (base * maxW) / Math.max(1, meas))) : base;
  const shadow = sub.sombra ? '0 2px 6px rgba(0,0,0,.55), 0 4px 18px rgba(0,0,0,.35)' : 'none';
  const style: React.CSSProperties = {position: 'absolute', left: cx - maxW / 2, width: maxW, top: cy, transform: 'translateY(-50%)', textAlign: 'center',
    fontFamily: SUB_FONT, fontSize: size, fontWeight: sub.peso || 400, color: col.subtitulo, textShadow: shadow, lineHeight: 1.15, whiteSpace: sub.modo === 'palabra' ? 'nowrap' : 'normal'};
  // barra: un fondo sólido redondeado detrás de las letras (se activa en su perfil); palabras resaltadas: las que ella marcó
  const barra = (sub as any).barra ? {background: (sub as any).barra_color || 'rgba(0,0,0,.55)', padding: '.12em .4em', borderRadius: '.35em', boxDecorationBreak: 'clone' as const, WebkitBoxDecorationBreak: 'clone' as const, textShadow: 'none'} : null;
  const resW = (w: Wd, k: number) => <span key={k} style={w.res ? {color: col.resaltado || col.acento || col.subtitulo} : undefined}>{fmt(w.w)}{sub.modo === 'palabra' ? '' : ' '}</span>;
  if (sub.modo === 'karaoke') {
    return <div style={style}>{g.map((w, i) => { const on = w.s <= t + 0.02 && (i === g.length - 1 || g[i + 1].s > t + 0.02);
      return <span key={i} style={{padding: '0 .12em', borderRadius: '.18em', background: on ? col.resaltado : 'transparent', color: on ? col.resaltado_texto : col.subtitulo, textShadow: on ? 'none' : shadow}}>{fmt(w.w)} </span>; })}</div>;
  }
  const hayRes = WORDS.some((w) => w.res);
  const cuerpo = !hayRes ? txt : (sub.modo === 'palabra' ? resW(cw, 0) : g.map((w, i) => resW(w, i)));
  return <div style={style}>{barra ? <span style={barra}>{cuerpo}</span> : cuerpo}</div>;
};

// ---------- textos y gráficos (catálogo en references/efectos.md) ----------
type O = {kind: string; text?: string; items?: string[]; t0: number; t1: number; x?: number; y?: number; image?: string; n?: number; file?: string; tam?: number; rot?: number; mezcla?: string; [k: string]: any};
const ENTER = 0.28, EXIT = 0.18;
const tShadow = tit.sombra === false ? 'none' : '0 2px 4px rgba(0,0,0,0.45), 0 4px 18px rgba(0,0,0,0.35)';
const TS = tit.tamano || 60;
const TOPY = (tit.zona || [0.10, 0.28]);
const box = (extra: React.CSSProperties = {}): React.CSSProperties => ({background: col.caja, color: col.caja_texto, padding: '4px 16px', borderRadius: tit.radio_caja ?? 0, boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone', textShadow: 'none', ...extra});
const Typed: React.FC<{text: string; n: number; boxed: boolean}> = ({text, n, boxed}) => {
  let i = 0;
  return <>{Array.from(text).filter((c) => c !== '️').map((c, k) => { if (c === '\n') return <br key={k} />; const vis = i++ < n;
    return <span key={k} style={{opacity: vis ? 1 : 0, ...(boxed && vis ? {background: col.caja} : {})}}>{isEmo(c) ? <Emo c={c} /> : c}</span>; })}</>;
};
const Overlay: React.FC<{o: O}> = ({o}) => {
  const t = useCurrentFrame() / FPS;
  if (t < o.t0 || t > o.t1) return null;
  const pIn = interpolate(t, [o.t0, o.t0 + ENTER], [0, 1], {extrapolateRight: 'clamp', easing: Easing.out(Easing.back(1.6))});
  const pOut = interpolate(t, [o.t1 - EXIT, o.t1], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const op = Math.min(1, interpolate(t, [o.t0, o.t0 + ENTER * 0.6], [0, 1], {extrapolateRight: 'clamp'})) * pOut;
  const cx = o.x ?? W / 2, y = o.y ?? TOPY[0] * H + 70;
  const base: React.CSSProperties = {position: 'absolute', left: cx - 470, width: 940, top: y, textAlign: 'center', opacity: op,
    transform: `translateY(calc(-50% + ${(1 - pIn) * 26}px)) scale(${0.9 + 0.1 * pIn})`,
    fontFamily: TIT_FONT, color: col.texto, lineHeight: 1.18, whiteSpace: 'pre-line', letterSpacing: '-0.02em', fontWeight: tit.peso || 800, textShadow: tShadow};
  const typingN = Math.floor((t - o.t0) / 0.035);
  const text = o.text || '';
  if (o.lineas && (o.kind === 'gancho' || o.kind === 'cierre' || o.kind === 'palabra' || o.kind === 'tachado')) {
    if (o.detras && !VISTA) return null;   // se dibuja detrás de su silueta en detras.py (después del render); en la vista previa va delante
    const fin = interpolate(t, [o.t1 - 0.25, o.t1], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
    return <>{(o.lineas as any[]).map((l, i) => {
      const p = interpolate(t, [l.t, l.t + 0.28], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
      if (p <= 0) return null;
      const c1 = 1.70158 * 0.6, c3 = c1 + 1, eb = 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
      const sc = 0.6 + 0.4 * eb, a = Math.min(1, p * 2) * fin;
      const strike = o.kind === 'tachado' && o.tacha != null ? interpolate(t, [o.tacha, o.tacha + 0.2], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)}) : 0;
      return <div key={i} style={{position: 'absolute', left: 0, width: W, top: l.y, textAlign: 'center', transform: `translateY(-50%) scale(${sc})`, transformOrigin: `${W / 2}px 50%`, opacity: a,
        fontFamily: TIT_FONT, fontWeight: 900, fontSize: l.size, color: o.color || col.texto, lineHeight: 1, letterSpacing: '-0.01em', whiteSpace: 'nowrap', textShadow: tShadow}}>
        <span style={{position: 'relative', display: 'inline-block'}}>{l.text}
          {strike > 0 ? <span style={{position: 'absolute', left: -10, top: '52%', height: 9, width: `calc((100% + 20px) * ${strike})`, background: col.caja_texto, borderRadius: 3}} /> : null}</span></div>;
    })}</>;
  }
  const Propio = (PROPIOS as any)[o.kind];
  if (Propio) return <Propio o={o} t={t} kit={{W, H, FPS, col, tit, sub, TS, TIT_FONT, SUB_FONT, Rich, Emo, box, base, pIn, pOut, op, typingN, cx, y}} />;
  switch (o.kind) {
    case 'sticker': {
      const w = o.tam || 360;
      return <div style={{position: 'absolute', left: cx - w / 2, top: y - w / 2, width: w, opacity: op, mixBlendMode: (o.mezcla as any) || 'normal',
        transform: `scale(${0.6 + 0.4 * pIn}) rotate(${(o.rot || 0) * pIn}deg)`}}><Img src={staticFile('mis/' + o.file)} style={{width: '100%', display: 'block'}} /></div>;
    }
    case 'imagen':
      return <div style={{position: 'absolute', left: cx - 125, top: y - 160, width: 250, opacity: op, transform: `translateY(${(1 - pIn) * 40}px) rotate(${10 - 2 * pIn}deg) scale(${0.85 + 0.15 * pIn})`}}>
        <Img src={staticFile(o.image || 'imagen.png')} style={{width: 250, boxShadow: '0 10px 30px rgba(0,0,0,0.35)', borderRadius: 6}} /></div>;
    case 'caja':
      return <div style={{...base, fontSize: TS * 0.77, lineHeight: 1.45}}><span style={box()}><Rich text={text} /></span></div>;
    case 'caja_escribe':
      return <div style={{...base, fontSize: TS * 0.77, lineHeight: 1.45, color: col.caja_texto, textShadow: 'none'}}><Typed text={text} n={typingN} boxed /></div>;
    case 'paso_escribe': {
      const done = typingN >= Array.from(text).length;
      return <div style={{...base, fontSize: TS * 0.8}}><Typed text={text} n={typingN} boxed={false} /><span style={{opacity: done ? 0 : 1}}>|</span></div>;
    }
    case 'checklist': {
      const items = o.items || text.split('\n');
      return <div style={{...base, transform: 'translateY(-50%)', opacity: pOut, textAlign: 'left', left: 140, width: 800, fontSize: TS * 0.7}}>
        {items.map((it, i) => { const ti = o.t0 + i * 0.6; const a = interpolate(t, [ti, ti + 0.3], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}); const ok = t > ti + 0.4;
          return <div key={i} style={{opacity: a, transform: `translateY(${(1 - a) * 20}px)`, display: 'flex', gap: 18, alignItems: 'center', margin: '10px 0'}}>
            <span style={{width: 52, height: 52, borderRadius: 12, display: 'grid', placeItems: 'center', background: ok ? col.resaltado : 'rgba(255,255,255,.25)', color: col.resaltado_texto, fontSize: 34}}>{ok ? '✓' : ''}</span><Rich text={it} /></div>; })}</div>;
    }
    case 'contador': {
      const k = interpolate(t, [o.t0, o.t0 + 1.4], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
      return <div style={{...base}}><div style={{fontSize: TS * 2.2, fontVariantNumeric: 'tabular-nums'}}>{Math.round((o.n || 0) * k).toLocaleString('es-MX')}</div><div style={{fontSize: TS * 0.8}}><Rich text={text} /></div></div>;
    }
    case 'burbujas': {
      const items = o.items || text.split('\n');
      return <>{items.map((it, i) => { const ti = o.t0 + i * 0.35; const k = interpolate(t, [ti, ti + 2.6], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}); if (t < ti) return null;
        return <div key={i} style={{position: 'absolute', left: [80, 420, 160, 480, 260][i % 5], top: H * 0.5 - k * 700, opacity: Math.min(1, k * 8) * (1 - Math.max(0, (k - 0.8) * 5)), background: '#fff', color: '#2b1d17', fontFamily: TIT_FONT, fontWeight: 700, fontSize: 40, padding: '14px 26px', borderRadius: '36px 36px 36px 8px', boxShadow: '0 10px 30px rgba(0,0,0,.3)'}}><Rich text={it} /></div>; })}</>;
    }
    default: {
      const size = ({titulo: TS, paso: TS * 0.96, formula: TS * 0.93, flotante: TS * 0.87, cta: TS * 1.13} as any)[o.kind] ?? TS * 0.8;
      const wide = o.kind === 'flotante' ? {width: 560, left: Math.min(W - 300, Math.max(300, cx)) - 280} : {};
      return <div style={{...base, fontSize: size, ...wide}}><Rich text={text} /></div>;
    }
  }
};
const Animacion: React.FC<{o: O}> = ({o}) => {
  const t = useCurrentFrame() / FPS, d = o.t1 - o.t0;
  const op = Math.min(interpolate(t, [0, 0.15], [0, 1], {extrapolateRight: 'clamp'}), interpolate(t, [d - 0.2, d], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  const w = o.tam || 420, cx = o.x ?? W / 2, cy = o.y ?? (TOPY[0] * H + 140);
  return <div style={{position: 'absolute', left: cx - w / 2, top: cy - w / 2, width: w, opacity: op, mixBlendMode: (o.mezcla as any) || 'normal', transform: `rotate(${o.rot || 0}deg)`}}>
    <OffthreadVideo src={staticFile('mis/' + o.file)} transparent={o.mezcla !== 'screen'} muted style={{width: '100%', display: 'block'}} /></div>;
};
// efecto del catálogo (HyperFrames): ya viene animado y transparente, a pantalla completa
const Catalogo: React.FC<{o: O}> = ({o}) => VISTA
  ? <AbsoluteFill><Html5Video src={staticFile('hf/' + o.file)} muted style={{width: '100%', height: '100%'}} /></AbsoluteFill>
  : <AbsoluteFill><OffthreadVideo src={staticFile('hf/' + o.file)} transparent muted style={{width: '100%', height: '100%'}} /></AbsoluteFill>;
const OverlayMB: React.FC<{o: O}> = ({o}) => {
  const t = useCurrentFrame() / FPS;
  if (t < o.t0 || t > o.t1) return null;
  if (mov.motion_blur !== false && t < o.t0 + ENTER) return <CameraMotionBlur samples={6} shutterAngle={180}><Overlay o={o} /></CameraMotionBlur>;
  return <Overlay o={o} />;
};

export const Main: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const D = (tl as any).duration_real as number;
  const {ramp} = zoomAt(t);
  const fd = mov.fundido_final ?? 0.75;
  const fade = fd > 0 ? interpolate(t, [D - fd, D], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
  // capa = true (scripts/capcut.py): solo los efectos, sobre fondo transparente, para llevarlos a CapCut como su propia capa
  const CAPA = (cues as any).capa === true;
  if (CAPA) return (
    <AbsoluteFill style={{background: 'transparent'}}>
      {(cues as any).overlays.map((o: O, i: number) => o.kind === 'catalogo'
        ? <Sequence key={i} from={Math.round(o.t0 * FPS)} durationInFrames={Math.max(1, Math.round((o.t1 - o.t0) * FPS))}><Catalogo o={o} /></Sequence>
        : o.kind === 'animacion'
        ? <Sequence key={i} from={Math.round(o.t0 * FPS)} durationInFrames={Math.max(1, Math.round((o.t1 - o.t0) * FPS))} layout="none"><Animacion o={o} /></Sequence>
        : <OverlayMB key={i} o={o} />)}
    </AbsoluteFill>
  );
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {ramp && mov.motion_blur !== false ? <CameraMotionBlur samples={6} shutterAngle={180}><VideoLayer /></CameraMotionBlur> : <VideoLayer />}
      <Caption />
      <Sonidos />
      {(cues as any).overlays.map((o: O, i: number) => o.kind === 'catalogo'
        ? <Sequence key={i} from={Math.round(o.t0 * FPS)} durationInFrames={Math.max(1, Math.round((o.t1 - o.t0) * FPS))}><Catalogo o={o} /></Sequence>
        : o.kind === 'animacion'
        ? <Sequence key={i} from={Math.round(o.t0 * FPS)} durationInFrames={Math.max(1, Math.round((o.t1 - o.t0) * FPS))} layout="none"><Animacion o={o} /></Sequence>
        : <OverlayMB key={i} o={o} />)}
      <AbsoluteFill style={{background: '#000', opacity: fade}} />
    </AbsoluteFill>
  );
};
