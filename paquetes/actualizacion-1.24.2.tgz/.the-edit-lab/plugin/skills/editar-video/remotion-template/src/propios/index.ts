// Índice de efectos propios. final.py lo vuelve a escribir con los archivos de EST/efectos-propios/*.tsx.
export const PROPIOS: Record<string, any> = {};
