// Arma la vista previa del editor (un solo archivo .js) con el mismo Main.tsx del video final.
// Uso: node build-player.mjs <carpeta con src armada> <salida.js>
// Los JSON de datos (timeline, cues, cara, estilo) se reemplazan por window.__TEL, así la página manda los datos del momento.
import path from 'node:path';
import {createRequire} from 'node:module';
// esbuild y React se toman del motor (la carpeta desde donde se corre), no de donde vive este archivo
const esbuild = createRequire(path.join(process.cwd(), 'x.js'))('esbuild');
const [, , srcDir, out] = process.argv;
const DATOS = {'timeline.json': 'tl', 'cues.json': 'cues', 'cara.json': 'cara', 'estilo.json': 'estilo'};
const datos = {
  name: 'datos-de-la-pagina',
  setup(b) {
    b.onResolve({filter: /\.json$/}, (a) => { const n = path.basename(a.path); return DATOS[n] ? {path: n, namespace: 'tel'} : undefined; });
    b.onLoad({filter: /.*/, namespace: 'tel'}, (a) => ({contents: `module.exports = window.__TEL.${DATOS[a.path]};`, loader: 'js'}));
  },
};
await esbuild.build({
  entryPoints: [path.join(srcDir, 'player-entry.tsx')], bundle: true, format: 'iife', minify: true, outfile: out,
  plugins: [datos], jsx: 'automatic', loader: {'.tsx': 'tsx', '.ts': 'ts'}, define: {'process.env.NODE_ENV': '"production"'},
  nodePaths: [path.join(process.cwd(), 'node_modules')], logLevel: 'error',
});
console.log('LISTO ' + out);
