"""Funciones compartidas del motor de edición de The Edit Lab."""
import json, os, subprocess, wave, unicodedata
import numpy as np

HOP = 0.01  # 10 ms por cuadro de envolvente


NPX = 'npx.cmd' if os.name == 'nt' else 'npx'   # en Windows npx es npx.cmd


def ruta_filtro(p):
    """Ruta segura dentro de un filtro de ffmpeg (Windows: C:\\x → C\\:/x)."""
    return str(p).replace('\\', '/').replace(':', '\\:')


def run(cmd, **kw):
    """Corre un comando y falla con un mensaje claro."""
    r = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', **kw)
    if r.returncode != 0:
        raise SystemExit(f"Falló: {' '.join(map(str, cmd))[:200]}\n{r.stderr[-1500:]}")
    return r.stdout


def ffprobe(path):
    out = run(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', path])
    return json.loads(out)


def load_json(p, default=None):
    try:
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        if default is not None:
            return default
        raise


def save_json(p, data):
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def load_wav(p):
    w = wave.open(p)
    x = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
    if w.getnchannels() > 1:
        x = x.reshape(-1, w.getnchannels()).mean(1)
    return x, w.getframerate()


def save_wav(p, x, sr):
    o = wave.open(p, 'wb'); o.setnchannels(1); o.setsampwidth(2); o.setframerate(sr)
    o.writeframes((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes()); o.close()


def envelope(x, sr):
    n = int(sr * HOP); m = len(x) // n
    return 20 * np.log10(np.sqrt((x[:m * n].reshape(m, n) ** 2).mean(1)) + 1e-9)


def nfc(s):
    return unicodedata.normalize('NFC', s)


def estudio_de(trabajo):
    """La carpeta del estudio: la que tiene estilo.json o GUIA_DE_ESTILO.md, subiendo desde trabajo/."""
    d = os.path.abspath(trabajo)
    for _ in range(5):
        if os.path.exists(os.path.join(d, 'estilo.json')) or os.path.exists(os.path.join(d, 'GUIA_DE_ESTILO.md')):
            return d
        d = os.path.dirname(d)
    return None


# Carpetas del estudio (sin dependencias: también la usa el instalador)
from carpetas import CARPETAS, carpeta, carpeta_propia  # noqa: E402,F401
