"""Rescata las palabras que la transcripción se comió cuando repites ("misma, misma cámara").

Uso: python3 repeticiones.py <carpeta_trabajo> [--modelo medium] [--todo]
Whisper, al transcribir un bloque largo, junta o se salta las repeticiones y los arranques en falso: la palabra repetida
no aparece en el texto y entonces nadie la corta. Aquí se vuelve a transcribir, SOLO y con un poco de contexto, cada pedazo
sospechoso (voz lenta para las palabras que trae, o una palabra demasiado larga). Si la segunda lectura trae las mismas
palabras MÁS alguna que repite a una vecina (la del propio pedazo, o la última del pedazo anterior), se adopta.
Las palabras rescatadas llevan "rep": true. Después hay que correr afinar_palabras.py (pedazos.py ya lo hace).
"""
import argparse, os, sys, re, unicodedata
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_wav, load_json, save_json, nfc

ap = argparse.ArgumentParser()
ap.add_argument('trabajo'); ap.add_argument('--modelo', default='medium'); ap.add_argument('--todo', action='store_true')
ap.add_argument('--idioma', default='es'); ap.add_argument('--pad', type=float, default=0.25)
ap.add_argument('--modelo2', default='small', help='modelo de la segunda lectura (escucha cada pedazo por separado)')
ap.add_argument('--solo-sospechosos', action='store_true')
a = ap.parse_args()
ruta = os.path.join(a.trabajo, 'pedazos.json')
data = load_json(ruta, default={'pedazos': []}); P = data['pedazos']
if not P or any('texto' not in p for p in P): print('Faltan pedazos por transcribir; salto.'); sys.exit(0)


def norm(t):
    t = unicodedata.normalize('NFD', t.lower()); t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ]', '', t)


def silabas(t):
    return max(1, len(re.findall(r'[aeiouáéíóúü]+', t.lower())))


def sospechoso(p):
    ws = p.get('palabras') or []
    if not ws: return False
    dur = p['off'] - p['on']
    sil = sum(silabas(w['w']) for w in ws)
    return dur / sil > 0.21 or any((w['e'] - w['s']) > 0.75 for w in ws)


# Se escucha TODO otra vez, pedazo por pedazo: al transcribir de corrido, la transcripción se traga los reinicios
# («yo ya no paso, yo ya no paso tres horas…» queda como una sola frase) y entonces nadie los corta.
cand = [p for p in P if p.get('palabras') and (a.todo or not a.solo_sospechosos or sospechoso(p))]
if not cand: print('Sin pedazos sospechosos.'); sys.exit(0)
from faster_whisper import WhisperModel
import numpy as np
model = WhisperModel(a.modelo2 or a.modelo, device='cpu', compute_type='int8', cpu_threads=(min(8, max(4, (os.cpu_count() or 4) - 2)) if os.environ.get('EDIT_LAB_LOCAL') else min(4, os.cpu_count() or 2)))
audios = {}; rescatadas = 0; tocados = 0
for p in cand:
    arch = p['archivo']
    if arch not in audios: audios[arch] = load_wav(os.path.join(a.trabajo, f"a{arch}.wav"))
    x, sr = audios[arch]
    s0 = max(0, p['on'] - a.pad); s1 = min(len(x) / sr, p['off'] + a.pad)
    try:
        segs, _ = model.transcribe(x[int(s0 * sr):int(s1 * sr)], language=a.idioma, beam_size=5, word_timestamps=True,
                                   condition_on_previous_text=False, vad_filter=False)
        nw = [{'w': nfc(w.word.strip()), 's': round(w.start + s0, 3), 'e': round(w.end + s0, 3)} for sg in segs for w in sg.words if w.word.strip()]
    except Exception as ex:
        print('pedazo', p['id'], 'sin segunda lectura:', ex); continue
    # solo las palabras cuyo centro cae dentro del pedazo (el contexto de los lados no es de este pedazo)
    nw = [w for w in nw if p['on'] - 0.08 <= (w['s'] + w['e']) / 2 <= p['off'] + 0.08]
    ow = p['palabras']
    if len(nw) <= len(ow): continue
    # ¿la segunda lectura trae lo mismo MÁS repeticiones? Se aceptan pocos cambios de palabra (otra forma de
    # escuchar «CapCut»); en esos casos se deja la palabra de la primera lectura, con los tiempos de la segunda.
    from difflib import SequenceMatcher
    on_ = [norm(w['w']) for w in ow]; nn_ = [norm(w['w']) for w in nw]
    ops = SequenceMatcher(None, on_, nn_, autojunk=False).get_opcodes()
    cambios = sum(i2 - i1 for t_, i1, i2, j1, j2 in ops if t_ == 'replace')
    if any(t_ == 'delete' for t_, *_ in ops) or cambios > max(1, len(ow) // 4): continue
    if any(t_ == 'replace' and (i2 - i1) != (j2 - j1) for t_, i1, i2, j1, j2 in ops): continue
    extras = [k for t_, i1, i2, j1, j2 in ops if t_ == 'insert' for k in range(j1, j2)]
    if not extras: continue
    texto_viejo = {}
    for t_, i1, i2, j1, j2 in ops:
        if t_ == 'replace':
            for d in range(i2 - i1): texto_viejo[j1 + d] = ow[i1 + d]['w']
    ok = True
    for t_, i1, i2, j1, j2 in ops:   # cada tramo de más tiene que ser casi todo repetición de lo que dijo cerca
        if t_ != 'insert': continue
        rep = sum(1 for k in range(j1, j2) if nn_[k] and nn_[k] in (nn_[max(0, k - 15):j1] + nn_[j2:k + 16]))
        if rep < max(1, round(0.6 * (j2 - j1))): ok = False; break
    if not ok: continue
    nuevas = []
    for k, w in enumerate(nw):
        w = dict(w)
        if k in texto_viejo: w['w'] = texto_viejo[k]
        if k in extras: w['rep'] = True; rescatadas += 1
        nuevas.append(w)
    print(f"pedazo {p['id']} ({p['on']:.2f}-{p['off']:.2f}): «{p['texto']}» -> «{' '.join(w['w'] for w in nuevas)}»")
    p['palabras'] = nuevas; p['texto'] = ' '.join(w['w'] for w in nuevas); tocados += 1
save_json(ruta, data)
with open(os.path.join(a.trabajo, 'pedazos.txt'), 'w', encoding='utf-8') as f:
    for p in P: f.write(f"#{p['id']:<4} [{p['archivo']}] {p['on']:8.2f}-{p['off']:8.2f}  {p.get('texto', '…pendiente')}\n")
print(f"{len(cand)} pedazos revisados, {tocados} corregidos, {rescatadas} palabras rescatadas.")
