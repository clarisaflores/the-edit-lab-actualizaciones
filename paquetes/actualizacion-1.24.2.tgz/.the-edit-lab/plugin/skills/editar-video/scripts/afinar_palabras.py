"""Afina el inicio y el final de cada palabra con el SONIDO real (no con el cálculo de la transcripción).

Uso: python3 afinar_palabras.py <carpeta_trabajo>
La transcripción dice dónde cree que empieza y termina cada palabra, pero se equivoca por 50-200 ms: un corte hecho
con esos tiempos se come la primera letra o deja la cola de la palabra anterior. Aquí cada límite se mueve al punto
donde de verdad empieza o termina la voz (o, si dos palabras van pegadas, al valle más bajo entre ellas).
Lee trabajo/pedazos.json y los audios a<n>.wav (mejor a<n>_dn.wav si existe); escribe de vuelta las palabras con
s/e afinados y guarda los originales en s0/e0. Se puede correr varias veces: parte siempre de s0/e0.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_wav, envelope, load_json, save_json, HOP
import numpy as np

MARGEN_INI_ATRAS = 0.15   # un inicio puede adelantarse (hacia antes) hasta esto
MARGEN_INI_ADELANTE = 0.60  # Whisper suele poner el inicio DENTRO del silencio previo: puede atrasarse hasta esto
MARGEN_FIN_ATRAS, MARGEN_FIN_ADELANTE = 0.60, 0.18
MIN_PALABRA = 0.06


def umbral(e):
    piso, techo = np.percentile(e, 10), np.percentile(e, 95)
    return piso + max(8.0, 0.30 * (techo - piso)), piso, techo


def suave(e, n=3):
    return np.convolve(e, np.ones(n) / n, mode='same') if len(e) > n else e


def idx(t):
    return max(0, int(round(t / HOP)))


def hay_voz(e, thr, i, n=3):
    return i >= 0 and i + n <= len(e) and bool((e[i:i + n] > thr).all())


def valle(e, lo, hi):
    i0, i1 = idx(lo), max(idx(lo) + 1, idx(hi))
    seg = suave(e[i0:i1])
    return (i0 + int(np.argmin(seg))) * HOP


def afinar(palabras, e):
    """palabras: [{'s','e',...}] de UN archivo en orden de tiempo. Devuelve cuántas se movieron."""
    thr, piso, techo = umbral(e)
    prev_fin = 0.0
    movidas = 0
    for k, w in enumerate(palabras):
        s0, e0 = w.get('s0', w['s']), w.get('e0', w['e'])
        sig = palabras[k + 1] if k + 1 < len(palabras) else None
        sig_s = sig.get('s0', sig['s']) if sig else 1e9
        # --- inicio ---
        lo, hi = max(prev_fin, s0 - MARGEN_INI_ATRAS), min(e0 - MIN_PALABRA, s0 + MARGEN_INI_ADELANTE)
        s1 = s0
        if hi > lo:
            if hay_voz(e, thr, idx(s0)):          # ya hay voz en el inicio dicho: busca el arranque real hacia atrás
                i = idx(s0)
                while i - 1 >= idx(lo) and hay_voz(e, thr, i - 1):
                    i -= 1
                if i <= idx(lo):                     # la voz no se detiene: van pegadas, cortamos en el valle
                    v = valle(e, max(prev_fin, s0 - 0.08), min(hi, s0 + 0.08))
                    if e[idx(v)] < thr - 3:
                        s1 = v
                else:
                    s1 = i * HOP
            else:                                    # el inicio dicho cae en silencio: el arranque real viene después
                for i in range(idx(s0), idx(hi) + 1):
                    if hay_voz(e, thr, i):
                        s1 = i * HOP; break
        s1 = min(max(s1, prev_fin), e0 - MIN_PALABRA)
        # --- final ---
        lo2, hi2 = max(s1 + MIN_PALABRA, e0 - MARGEN_FIN_ATRAS), min(sig_s - 0.0, e0 + MARGEN_FIN_ADELANTE)
        e1 = e0
        if hi2 > lo2:
            if hay_voz(e, thr, idx(hi2) - 3):     # la voz sigue pegada a la siguiente: cortamos en el valle
                v = valle(e, max(lo2, e0 - 0.08), hi2)
                if e[idx(v)] < thr - 3:
                    e1 = v
            else:
                for i in range(idx(hi2), idx(lo2) - 1, -1):
                    if hay_voz(e, thr, i - 2):
                        e1 = (i + 1) * HOP; break
        e1 = max(e1, s1 + MIN_PALABRA)
        if abs(s1 - s0) > 0.005 or abs(e1 - e0) > 0.005:
            movidas += 1
        w['s0'], w['e0'] = round(s0, 3), round(e0, 3)
        w['s'], w['e'] = round(s1, 3), round(e1, 3)
        prev_fin = e1
    return movidas


if __name__ == '__main__':
    T = sys.argv[1]
    ruta = os.path.join(T, 'pedazos.json')
    data = load_json(ruta)
    por_archivo = {}
    for p in data['pedazos']:
        for w in p.get('palabras', []):
            por_archivo.setdefault(p['archivo'], []).append(w)
    total = movidas = 0
    for f, ws in por_archivo.items():
        for cand in (f'a{f}_dn.wav', f'a{f}.wav'):
            ruta_a = os.path.join(T, cand)
            if os.path.exists(ruta_a):
                break
        else:
            print(f'No encontré el audio del archivo {f}; lo dejo como estaba.'); continue
        x, sr = load_wav(ruta_a)
        e = envelope(x, sr)
        ws.sort(key=lambda w: w.get('s0', w['s']))
        movidas += afinar(ws, e); total += len(ws)
    save_json(ruta, data)
    print(f'Afiné {movidas} de {total} palabras con el sonido real.')
