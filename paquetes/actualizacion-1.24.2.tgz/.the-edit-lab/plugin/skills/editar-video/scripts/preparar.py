"""Paso 1: revisa el material crudo de un proyecto y prepara el audio para analizarlo.

Uso: python3 preparar.py <carpeta_proyecto> --rnnn <bd.rnnn> [--girar auto|si|no]
Crea <proyecto>/trabajo/ con:
  fuentes.json   lista de archivos (orden alfabético = orden del video), duración, tamaño y si hay que girar
  a<N>.wav       audio mono 16 kHz de cada archivo
  a<N>_dn.wav    el mismo audio sin ruido (arnndn), para encontrar la voz real y los silencios
"""
import argparse, os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, ffprobe, save_json, ruta_filtro

ap = argparse.ArgumentParser()
ap.add_argument('proyecto'); ap.add_argument('--rnnn', required=True); ap.add_argument('--girar', default='auto')
a = ap.parse_args()
crudo = os.path.join(a.proyecto, 'crudo'); trabajo = os.path.join(a.proyecto, 'trabajo')
os.makedirs(trabajo, exist_ok=True)
files = sorted(f for f in os.listdir(crudo) if f.lower().endswith(('.mp4', '.mov', '.m4v')) and not f.startswith('.'))
if not files:
    raise SystemExit('No hay videos en ' + crudo)


def needs_turn(path, w, h):
    """Video horizontal grabado con el teléfono o la cámara girada: prueba si la cara aparece al girarlo."""
    if a.girar in ('si', 'no'):
        return a.girar == 'si'
    if h >= w:
        return False
    try:
        import cv2
        model = os.path.join(os.path.dirname(a.rnnn), 'face_detection_yunet_2023mar.onnx')
        if not os.path.exists(model):
            return True  # sin detector: asumimos que un Reel se graba vertical
        frame = os.path.join(trabajo, '_giro.jpg')
        run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', '5', '-i', path, '-frames:v', '1', '-vf', 'scale=640:-1', frame])
        img = cv2.imread(frame)
        def faces(im):
            det = cv2.FaceDetectorYN.create(model, '', (im.shape[1], im.shape[0]), 0.7)
            _, f = det.detect(im); return 0 if f is None else len(f)
        plain, turned = faces(img), faces(cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE))
        os.remove(frame)
        return turned > plain
    except Exception:
        return True


out = []
for i, f in enumerate(files, 1):
    p = os.path.join(crudo, f); info = ffprobe(p)
    v = next(s for s in info['streams'] if s['codec_type'] == 'video')
    dur = float(info['format']['duration'])
    rot = 0
    for sd in v.get('side_data_list', []) or []:
        if 'rotation' in sd: rot = int(float(sd['rotation']))
    rot = rot or int(float(v.get('tags', {}).get('rotate', 0) or 0))
    if abs(rot) % 180 == 90:  # el teléfono guarda el giro como dato; ffmpeg ya lo aplica solo
        v['width'], v['height'] = v['height'], v['width']
    turn = needs_turn(p, v['width'], v['height'])
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', p, '-vn', '-ac', '1', '-ar', '16000', os.path.join(trabajo, f'a{i}.wav')])
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', p, '-vn', '-af', f"aresample=48000,highpass=f=80,arnndn=m='{ruta_filtro(a.rnnn)}',aresample=16000", '-ac', '1', os.path.join(trabajo, f'a{i}_dn.wav')])
    fr = v.get('r_frame_rate', '30/1').split('/')
    out.append({'n': i, 'archivo': f, 'duracion': round(dur, 2), 'ancho': v['width'], 'alto': v['height'], 'fps': round(float(fr[0]) / float(fr[1] or 1), 2), 'girar': turn})
    print(f'{i}. {f}: {dur/60:.1f} min, {v["width"]}x{v["height"]}{" (se gira a vertical)" if turn else ""}')
save_json(os.path.join(trabajo, 'fuentes.json'), out)
