"""Paso 4: arma la línea de tiempo con las tomas elegidas.

Uso: python3 linea_tiempo.py <carpeta_trabajo> [--pausa 0.25]
Lee tomas.json (lo escribes tú después de leer pedazos.txt):
{
  "escenas": [
    {"escena": "1 Gancho", "pedazos": [12, 13]},
    {"escena": "2 Problema", "pedazos": [{"pedazo": 15, "desde_palabra": 3}, 16, {"pedazo": 17, "hasta_palabra": 8}]}
  ],
  "correcciones": {"palabra mal escrita": "palabra correcta"}
}
- Cada pedazo es un número de pedazos.txt. Pon solo la toma buena de cada frase (normalmente la última).
- desde_palabra / hasta_palabra (contando desde 0, inclusive) recortan un pedazo por dentro,
  para quitar un arranque en falso o una muletilla dentro del mismo pedazo.
- correcciones arregla palabras que la transcripción escribió mal (ortografía y nombres exactos).
Crea timeline.json con los cortes y las palabras ya en el tiempo del video final.
"""
import argparse, os, sys, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_wav, envelope, load_json, save_json, nfc, HOP
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('trabajo'); ap.add_argument('--pausa', type=float, default=0.25)
ap.add_argument('--suave', type=float, default=-38, help='dB: hasta dónde se considera voz al buscar el inicio y el final de cada toma')
a = ap.parse_args()
T = a.trabajo
ped = {p['id']: p for p in load_json(os.path.join(T, 'pedazos.json'))['pedazos']}
tomas = load_json(os.path.join(T, 'tomas.json'))
fix = {nfc(k): nfc(v) for k, v in tomas.get('correcciones', {}).items()}
E = {}
def env(f):
    if f not in E:
        x, sr = load_wav(os.path.join(T, f'a{f}_dn.wav')); E[f] = envelope(x, sr)
    return E[f]
def db(f, t):
    e = env(f); i = min(len(e) - 1, max(0, int(t / HOP))); return e[i]
def dip(f, lo, hi):
    """El punto más silencioso entre lo y hi (para cortar entre dos palabras sin comerse ninguna)."""
    e = env(f); i0, i1 = max(0, int(lo / HOP)), max(int(lo / HOP) + 1, int(hi / HOP))
    seg = np.convolve(e[i0:i1], np.ones(3) / 3, mode='same') if i1 - i0 > 3 else e[i0:i1]
    return (i0 + int(np.argmin(seg))) * HOP

def vecinos(p):
    mismos = [q for q in ped.values() if q['archivo'] == p['archivo'] and q['id'] != p['id']]
    antes = [q['off'] for q in mismos if q['off'] <= p['on'] + 0.01]
    despues = [q['on'] for q in mismos if q['on'] >= p['off'] - 0.01]
    lo = (max(antes) + p['on']) / 2 if antes else 0          # nunca más atrás de la mitad del silencio anterior
    hi = (min(despues) + p['off']) / 2 if despues else 1e9   # ni más adelante de la mitad del siguiente
    return lo, hi

clips = []
for sc in tomas['escenas']:
    for item in sc['pedazos']:
        it = item if isinstance(item, dict) else {'pedazo': item}
        p = ped[it['pedazo']]; f = p['archivo']; ws = p.get('palabras', []); lo, hi = vecinos(p)
        d0 = it.get('desde_palabra', 0); d1 = it.get('hasta_palabra', len(ws) - 1)
        use = ws[d0:d1 + 1] if ws else []
        # inicio: si recortamos por dentro, cortamos en el silencio entre palabras; si no, buscamos el arranque suave de la voz
        if d0 > 0 and ws:
            s = dip(f, max(ws[d0 - 1]['e'], ws[d0]['s'] - 0.30), ws[d0]['s'] + 0.03)   # cerca de la palabra: no mete ruidos del silencio
        else:
            s = min(p['on'], use[0]['s']) if use else p['on']
            k = s
            while k > max(0, s - 0.25) and db(f, k - HOP) > a.suave: k -= HOP
            s = max(lo, k - 0.04)
        if ws and d1 < len(ws) - 1:
            e = dip(f, ws[d1]['e'] - 0.03, min(ws[d1 + 1]['s'], ws[d1]['e'] + 0.30))
        else:
            e = max(p['off'], use[-1]['e']) if use else p['off']
            k = e
            while k < e + 0.30 and db(f, k) > a.suave: k += HOP
            e = min(hi, k + 0.06)
        # pausas internas largas: se recortan dejando una respiración corta
        i0, i1 = int(s / HOP), int(e / HOP); q = env(f)[i0:i1] < a.suave
        pts = [s]; k = 0
        while k < len(q):
            if q[k]:
                j = k
                while j < len(q) and q[j]: j += 1
                if (j - k) * HOP >= a.pausa and k > 0 and j < len(q):
                    pts += [(i0 + k) * HOP + 0.06, (i0 + j) * HOP - 0.06]
                k = j
            else:
                k += 1
        pts.append(e)
        for x, y in zip(pts[::2], pts[1::2]):
            if y - x >= 0.12:
                clips.append({'escena': sc['escena'], 'archivo': f, 'in': round(x, 3), 'out': round(y, 3), '_w': use})

# evita que dos tomas seguidas del mismo archivo se pisen
for c, n in zip(clips, clips[1:]):
    if c['archivo'] == n['archivo'] and n['in'] < c['out'] <= n['out'] and n['in'] > c['in']:
        m = dip(c['archivo'], n['in'], c['out']) if c['out'] - n['in'] > 0.02 else n['in']
        c['out'] = n['in'] = round(m, 3)

t = 0; words = []; seen = set()
for c in clips:
    c['t0'] = round(t, 3)
    for w in c.pop('_w'):
        ov = min(w['e'], c['out']) - max(w['s'], c['in'])
        key = (c['archivo'], w['s'])
        if ov > 0.04 and key not in seen:
            seen.add(key)
            words.append({'w': w['w'], 's': round(c['t0'] + max(w['s'], c['in']) - c['in'], 3),
                          'e': round(c['t0'] + min(w['e'], c['out']) - c['in'], 3), 'escena': c['escena'],
                          'ss': round(w['s'], 3), 'ee': round(w['e'], 3)})   # ss/ee: tiempos de la palabra en el video original (los usa cortar.py al afinar bordes)
    t += c['out'] - c['in']

# ortografía: correcciones, quitar vacíos y mayúscula al inicio de cada oración y escena
out = []
for w in words:
    x = nfc(w['w'].strip()).replace('…', '...')
    x = re.sub(r'^\.\.\.|\.\.\.$', '', x).strip()  # los "..." de la transcripción no van en subtítulos
    core = x.strip('.,;:¿?¡!"«»')
    if x in fix: x = fix[x]
    elif core and core in fix: x = x.replace(core, fix[core], 1)
    if x: w['w'] = x; out.append(w)
prev = None
for w in out:
    if (prev is None or prev['w'][-1:] in '.?!' or prev['escena'] != w['escena']) and w['w'][:1].islower():
        w['w'] = w['w'][0].upper() + w['w'][1:]
    prev = w
save_json(os.path.join(T, 'timeline.json'), {'clips': clips, 'words': out, 'duration': round(t, 3)})
print(f'{len(clips)} cortes, {t:.1f} s, {len(out)} palabras')
for sc in dict.fromkeys(w['escena'] for w in out):
    print(f"[{sc}] " + ' '.join(w['w'] for w in out if w['escena'] == sc))
