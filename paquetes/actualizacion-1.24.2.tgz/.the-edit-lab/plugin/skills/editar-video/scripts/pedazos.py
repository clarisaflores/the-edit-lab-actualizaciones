"""Paso 2: parte cada audio en pedazos de voz (frases separadas por silencios) y los transcribe.

Así se ven las repeticiones y los arranques en falso, y cada pedazo trae su inicio y su final reales
(medidos en el audio sin ruido). La transcripción se hace por bloques de varios pedazos seguidos (hasta ~25 s),
con contexto, y luego cada palabra se reparte a su pedazo por tiempo: transcribir pedazos sueltos muy cortos
hace que el modelo invente palabras ("¡Gracias por ver!") y se coma otras.

Uso: python3 pedazos.py <carpeta_trabajo> [--modelo medium|small] [--umbral -26] [--hueco 0.12] [--tiempo 140]
Crea pedazos.json (todos los pedazos con palabras y tiempos) y pedazos.txt (para leerlo y elegir tomas).
Si el proceso se detiene por memoria, vuelve a correrlo: retoma donde se quedó.
"""
import argparse, os, sys, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_wav, envelope, load_json, save_json, nfc, HOP

ap = argparse.ArgumentParser()
ap.add_argument('trabajo'); ap.add_argument('--modelo', default='medium'); ap.add_argument('--umbral', type=float, default=None, help='dB de voz; si no se da, se calcula del propio audio (voz fuerte − 16 dB)')
ap.add_argument('--hueco', type=float, default=0.35); ap.add_argument('--idioma', default='es'); ap.add_argument('--max', type=int, default=0)
ap.add_argument('--tiempo', type=float, default=140, help='segundos máximos por corrida; luego guarda y sale para retomar')
a = ap.parse_args()
fuentes = load_json(os.path.join(a.trabajo, 'fuentes.json'))
outp = os.path.join(a.trabajo, 'pedazos.json')
data = load_json(outp, default={'pedazos': []})

# 1. pedazos por energía (una sola vez)
if not data['pedazos']:
    for f in fuentes:
        x, sr = load_wav(os.path.join(a.trabajo, f"a{f['n']}_dn.wav")); E = envelope(x, sr)
        import numpy as np
        umbral = a.umbral if a.umbral is not None else float(min(-26, max(-40, np.percentile(E, 90) - 16)))
        print(f"Audio {f['n']}: voz a partir de {umbral:.0f} dB")
        on = E > umbral; segs = []; start = None; last = None
        for i, v in enumerate(on):
            t = i * HOP
            if v:
                if start is None: start = t
                elif t - last > a.hueco: segs.append([start, last + HOP]); start = t
                last = t
        if start is not None: segs.append([start, last + HOP])
        for s, e in segs:
            if e - s >= 0.10:
                data['pedazos'].append({'id': len(data['pedazos']) + 1, 'archivo': f['n'], 'on': round(s, 2), 'off': round(e, 2)})
    save_json(outp, data)

# 2. transcripción por bloques con contexto (retoma)
from faster_whisper import WhisperModel
model = WhisperModel(a.modelo, device='cpu', compute_type='int8', cpu_threads=(min(8, max(4, (os.cpu_count() or 4) - 2)) if os.environ.get('EDIT_LAB_LOCAL') else min(4, os.cpu_count() or 2)))
audios = {}
done = 0; t0 = time.time()
peds = data['pedazos']; i = 0
while i < len(peds):
    if 'texto' in peds[i]: i += 1; continue
    # bloque: pedazos seguidos del mismo archivo, sin texto, hasta ~25 s
    blq = [peds[i]]; j = i + 1
    while j < len(peds) and 'texto' not in peds[j] and peds[j]['archivo'] == blq[0]['archivo'] and peds[j]['off'] - blq[0]['on'] <= 25:
        blq.append(peds[j]); j += 1
    arch = blq[0]['archivo']
    if arch not in audios: audios[arch] = load_wav(os.path.join(a.trabajo, f"a{arch}.wav"))
    x, sr = audios[arch]
    s0 = max(0, blq[0]['on'] - 0.25); s1 = blq[-1]['off'] + 0.25
    segs, _ = model.transcribe(x[int(s0 * sr):int(s1 * sr)], language=a.idioma, beam_size=5, word_timestamps=True,
                               condition_on_previous_text=False, vad_filter=False)
    ws = [{'w': nfc(w.word.strip()), 's': round(w.start + s0, 3), 'e': round(w.end + s0, 3)} for sg in segs for w in sg.words if w.word.strip()]
    for k, w in enumerate(ws):   # palabras sin duración (el modelo a veces las pega): les damos un mínimo para no perderlas
        if w['e'] - w['s'] < 0.08:
            w['s'] = round(max(ws[k - 1]['e'] if k else s0, w['e'] - 0.12), 3)
    for p in blq: p['palabras'] = []
    for w in ws:   # cada palabra a su pedazo (por su centro; si cae en un silencio, al más cercano)
        c = (w['s'] + w['e']) / 2
        dueno = min(blq, key=lambda p: 0 if p['on'] - 0.05 <= c <= p['off'] + 0.05 else min(abs(c - p['on']), abs(c - p['off'])))
        dueno['palabras'].append(w)
    for p in blq: p['texto'] = ' '.join(w['w'] for w in p['palabras'])
    done += len(blq); i = j
    save_json(outp, data)
    if (a.max and done >= a.max) or time.time() - t0 > a.tiempo: break
save_json(outp, data)

with open(os.path.join(a.trabajo, 'pedazos.txt'), 'w', encoding='utf-8') as f:
    for p in data['pedazos']:
        f.write(f"#{p['id']:<4} [{p['archivo']}] {p['on']:8.2f}-{p['off']:8.2f}  {p.get('texto', '…pendiente')}\n")
pend = sum(1 for p in data['pedazos'] if 'texto' not in p)
if pend:
    print(f"PAUSA: {len(data['pedazos'])} pedazos, faltan {pend}. Vuelve a correr el mismo comando para seguir."); sys.exit(3)
print(f"{len(data['pedazos'])} pedazos transcritos. Lee pedazos.txt para elegir las tomas.")

# 2b. rescatar las palabras que la transcripción se comió al repetir ("misma, misma cámara")
try:
    import subprocess
    subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'repeticiones.py'), a.trabajo, '--modelo', a.modelo, '--idioma', a.idioma], check=False)
except Exception as ex:
    print('No pude revisar las repeticiones:', ex)

# 3. afinar inicio/final de cada palabra con el sonido real (los tiempos de la transcripción fallan 50-200 ms)
try:
    import subprocess
    subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'afinar_palabras.py'), a.trabajo], check=False)
except Exception as ex:
    print('No pude afinar las palabras (sigo con los tiempos de la transcripción):', ex)
