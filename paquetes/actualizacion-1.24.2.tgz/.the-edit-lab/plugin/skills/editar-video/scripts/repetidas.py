"""La última toma gana: encuentra los intentos fallidos y las frases repetidas en la transcripción y los marca para cortar.

Uso: python3 repetidas.py <palabras.json> [--salida resultado.json]
  palabras.json: lista [{t, s, e}, ...] (las palabras del reel, en orden).
Escribe (o imprime) {"cortar": [{"i": índice, "motivo": "..."}], "version": 1}

Reglas (siempre las mismas, sin adivinar):
1. Reinicio: si lo que dijo justo antes vuelve a empezar igual («yo ya no paso, yo ya no paso tres horas de, yo ya no
   paso tres horas editando»), cada intento anterior se corta y se queda el último. Cuenta como igual aunque la nueva
   empiece con una palabra de más («ya no, yo ya no…») o cambie la última palabra («tres horas de» → «tres horas editando»).
2. Frase repetida: si una frase entera se vuelve a decir casi igual poco después (hasta 30 s), se queda la ÚLTIMA.
3. Palabra cortada: una palabra que quedó a medias («subti…») y se corrige enseguida se corta.
Nunca corta repeticiones cortas que son su manera de hablar («no, no, no», «tus colores, tus tipografías»).
Solo Python. No gasta uso de Claude.
"""
import argparse, json, re, sys, unicodedata
from difflib import SequenceMatcher

MAX_INTENTO = 14        # palabras máximas de un intento fallido
MAX_SEG = 9.0           # segundos máximos entre el inicio del intento y el reinicio
MIN_IGUAL = 2           # palabras que deben coincidir al menos
PARECIDO = 0.75         # qué tanto del intento se repite al reiniciar
FRASE_SEG = 30.0        # ventana para frases repetidas completas
FRASE_PARECIDO = 0.72


def n(t):
    t = unicodedata.normalize('NFD', (t or '').lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ]', '', t)


def cortada(t):
    return bool(re.search(r'(\.\.\.|…|-)\s*$', t or '')) and not re.search(r'[.?!]["»)]*\s*$', (t or '').rstrip('.…'))


def igual_inicio(a, b):
    """Cuántas palabras del intento a se repiten, en orden, al comienzo de b. El reinicio empieza con la misma
    palabra (o b trae una palabra de más al principio: «ya no, yo ya no…»)."""
    mejor = 0
    for off in (0, 1):
        bb = b[off:off + len(a)]
        if not bb or bb[:2] != a[:2]: continue
        m = SequenceMatcher(None, a, bb, autojunk=False)
        mejor = max(mejor, sum(bl.size for bl in m.get_matching_blocks()))
    return mejor


def frases(W):
    """Parte en frases por puntuación o pausas de más de 0.6 s."""
    out, cur = [], []
    for i, w in enumerate(W):
        if cur and (w['s'] - W[cur[-1]]['e'] > 0.6):
            out.append(cur); cur = []
        cur.append(i)
        if re.search(r'[.?!]["»)]*$', w['t'] or ''):
            out.append(cur); cur = []
    if cur: out.append(cur)
    return out


def analizar(W):
    N = [n(w['t']) for w in W]
    cortar = {}
    # 1. reinicios: en cada posición j, ¿lo de justo antes era un intento que vuelve a empezar aquí?
    for j in range(1, len(W)):
        if not N[j]: continue
        mejor = None
        for L in range(1, MAX_INTENTO + 1):
            i = j - L
            if i < 0 or W[j]['s'] - W[i]['s'] > MAX_SEG: break
            if i in cortar: break
            a = [x for x in N[i:j] if x]
            if not a: continue
            k = igual_inicio(a, [x for x in N[j:j + L + 2] if x])
            if len(a) >= MIN_IGUAL and k >= MIN_IGUAL and k / len(a) >= PARECIDO and len(set(a)) > 1:
                mejor = i                     # el intento más largo que sigue cumpliendo
        if mejor is not None:
            fin = j
            # si la toma nueva empieza en la palabra siguiente y esta palabra cierra el intento («tres horas de, | yo ya…»)
            a_ = [x for x in N[mejor:j] if x]
            b_ = [x for x in N[j:j + len(a_) + 2] if x]
            if b_[:2] != a_[:2] and b_[1:3] == a_[:2]:
                pausa = (W[j + 1]['s'] - W[j]['e']) if j + 1 < len(W) else 0
                if pausa > 0.15 or re.search(r'[,.…]$', W[j]['t'] or ''):
                    fin = j + 1
            for q in range(mejor, fin): cortar[q] = 'toma repetida (se queda la última)'
    # 3. una palabra que quedó a medias («con mi subti… con mis instrucciones»): se corta desde donde vuelve a empezar
    for i, w in enumerate(W[:-1]):
        t = w['t'] or ''
        if i in cortar or not (re.search(r'(\.\.\.|…)\s*$', t) or t.endswith('-')): continue
        sig = N[i + 1:i + 4]
        ini = None
        for b in range(i - 1, max(-1, i - 5), -1):
            if b in cortar: break
            if N[b] and N[b] in sig: ini = b
        if ini is not None:
            for q in range(ini, i + 1): cortar[q] = 'frase que se quedó a medias'
        elif N[i][:3] and any(x.startswith(N[i][:3]) for x in sig):
            cortar[i] = 'palabra cortada'
    # 4. la misma palabra dos veces seguidas («la misma misma cámara»): se queda la segunda
    for i in range(len(W) - 1):
        if i in cortar or len(N[i]) < 4 or N[i] in ('muchas', 'mucho', 'nunca', 'siempre', 'bueno'): continue
        if N[i] == N[i + 1] and W[i + 1]['s'] - W[i]['e'] < 0.6:
            cortar[i] = 'palabra repetida'
    # 2. frases completas repetidas: se queda la última
    F = frases(W)
    for a in range(len(F)):
        fa = [N[k] for k in F[a] if k not in cortar and N[k]]
        if len(fa) < 3: continue
        for b in range(a + 1, len(F)):
            if W[F[b][0]]['s'] - W[F[a][-1]]['e'] > FRASE_SEG: break
            fb = [N[k] for k in F[b] if k not in cortar and N[k]]
            if len(fb) < 3: continue
            r = SequenceMatcher(None, fa, fb, autojunk=False).ratio()
            contenida = sum(bl.size for bl in SequenceMatcher(None, fa, fb, autojunk=False).get_matching_blocks()) / len(fa)
            if r >= FRASE_PARECIDO or (contenida >= 0.85 and len(fb) >= len(fa)):
                for k in F[a]: cortar.setdefault(k, 'frase repetida (se queda la última)')
                break
    return [{'i': i, 'motivo': m} for i, m in sorted(cortar.items())]


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('palabras'); ap.add_argument('--salida')
    a = ap.parse_args()
    W = json.load(open(a.palabras, encoding='utf-8'))
    W = [{'t': w.get('t', w.get('w', '')), 's': float(w['s']), 'e': float(w['e'])} for w in W]
    r = {'cortar': analizar(W), 'version': 1}
    s = json.dumps(r, ensure_ascii=False)
    if a.salida: open(a.salida, 'w', encoding='utf-8').write(s)
    else: print(s)


if __name__ == '__main__':
    main()
