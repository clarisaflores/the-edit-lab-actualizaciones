"""Paso 6: mide dónde está la cara en el video base, para que ningún texto la tape y los acercamientos vayan hacia ella.

Uso: python3 cara.py <carpeta_trabajo> --modelo <face_detection_yunet_2023mar.onnx> [--cada 3]
Crea cara.json: {"cx", "cy" (centro de la cara), "top" (parte de arriba de la cabeza), "bottom", "vista": n}
en píxeles de 1080x1920. Si no encuentra cara, usa el centro de la pantalla y avisa.
"""
import argparse, os, sys, glob, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, save_json, load_json
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('trabajo'); ap.add_argument('--modelo', required=True); ap.add_argument('--cada', type=float, default=1)
a = ap.parse_args()
d = os.path.join(a.trabajo, '_caras'); shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
run(['ffmpeg', '-nostdin', '-v', 'error', '-i', os.path.join(a.trabajo, 'base.mp4'), '-vf', f'fps=1/{a.cada},scale=540:960', os.path.join(d, 'f%04d.jpg')])
import cv2
det = cv2.FaceDetectorYN.create(a.modelo, '', (540, 960), 0.6)
B = []; B_t = []
for p in sorted(glob.glob(os.path.join(d, '*.jpg'))):
    img = cv2.imread(p); _, f = det.detect(img)
    if f is not None and len(f):
        x, y, w, h = max(f, key=lambda r: r[2] * r[3])[:4]
        B.append([(x + w / 2) * 2, (y + h / 2) * 2, (y - 0.35 * h) * 2, (y + h * 1.1) * 2, (x - 0.15 * w) * 2, (x + w * 1.15) * 2, len(B_t)])
    B_t.append(1)
shutil.rmtree(d, ignore_errors=True)
if B:
    B = np.array(B, dtype=float)
    # dónde está su cabeza NORMALMENTE (la lectura de en medio), no hasta dónde llegó una vez
    top, bot = float(np.median(B[:, 2])) - 20, float(np.median(B[:, 3])) + 20
    izq, der = float(np.median(B[:, 4])), float(np.median(B[:, 5]))
    out = {'cx': round(float(np.median(B[:, 0]))), 'cy': round(float(np.median(B[:, 1]))), 'top': round(top), 'bottom': round(bot),
           'izq': round(izq), 'der': round(der), 'vista': len(B),
           # cada momento medido (segundo del video base): para revisar un texto contra donde está ella EN ESE momento
           'tramos': [[round(float(r[6]) * a.cada, 2), round(float(r[0])), round(float(r[2])), round(float(r[3])), round(float(r[4])), round(float(r[5]))] for r in B]}
    ARR, ABA = 270, 1620      # franjas seguras de Instagram: arriba y abajo solo fondo
    out['zonas'] = {'arriba': [ARR, max(ARR, round(top) - 30)], 'abajo': [min(ABA, round(bot) + 30), ABA],
                    'izquierda': [60, max(60, round(izq) - 30)], 'derecha': [min(1020, round(der) + 30), 1020]}
    print(f"Su cabeza está normalmente entre y={out['top']} y y={out['bottom']} (x {out['izq']}–{out['der']}). Zonas libres: {out['zonas']}.")
else:
    out = {'cx': 540, 'cy': 700, 'top': 420, 'bottom': 1100, 'vista': 0}
    print('AVISO: no encontré una cara; revisa una foto del video antes de colocar textos.')
save_json(os.path.join(a.trabajo, 'cara.json'), out)
