"""Paso 5: corta las tomas, las pone en vertical 1080x1920 a 30 fps y las une en un solo video base.

Uso: python3 cortar.py <carpeta_proyecto> [--acerca 1.0] [--tiempo 150]
- Cada corte se ajusta a cuadros exactos y su audio se rellena a la misma duración (así la voz nunca se desfasa).
- Es reanudable: si se acaba el tiempo (--tiempo, en segundos) se detiene limpio; vuelve a correrlo y sigue.
Crea trabajo/base.mp4 (video sin sonido), trabajo/voz.wav (voz 48 kHz) y actualiza timeline.json
con t0_real y duration_real (los tiempos exactos que usan los subtítulos y los efectos).
"""
import argparse, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, load_json, save_json

FPS, W, H = 30, 1080, 1920
ap = argparse.ArgumentParser()
ap.add_argument('proyecto'); ap.add_argument('--acerca', type=float, default=1.0, help='1.0 = encuadre original; 1.08 = un poco más cerca')
ap.add_argument('--tiempo', type=float, default=150)
a = ap.parse_args()
T0 = time.time()
T = os.path.join(a.proyecto, 'trabajo'); C = os.path.join(T, 'cortes'); os.makedirs(C, exist_ok=True)
tl = load_json(os.path.join(T, 'timeline.json'))
src = {f['n']: f for f in load_json(os.path.join(T, 'fuentes.json'))}

def vf_for(f):
    w, h = (f['alto'], f['ancho']) if f['girar'] else (f['ancho'], f['alto'])
    k = max(W / w, H / h) * a.acerca
    sw, sh = int(round(w * k / 2) * 2), int(round(h * k / 2) * 2)
    pre = 'transpose=1,' if f['girar'] else ''
    return f"{pre}fps={FPS},scale={sw}:{sh}:flags=lanczos,crop={W}:{H}:{(sw - W) // 2}:{(sh - H) // 2},setsar=1,format=yuv420p"

# 0. bordes exactos: cada inicio y final de corte se mueve al arranque / apagado REAL de la voz (con un colchón mínimo).
#    Se come menos voz (no se «pierde» el arranque suave de una palabra ni su final) y no queda silencio pegado.
#    Solo se mueve si el borde está cerca de un borde de voz; un corte a mitad de palabra o entre voz pegada se respeta.
def afinar_bordes(tl):
    import numpy as np
    import bordes as B
    from comun import load_wav
    envs = {}
    def env(n):
        if n not in envs:
            for cand in (f'a{n}_dn.wav', f'a{n}.wav'):
                if os.path.exists(os.path.join(T, cand)):
                    x, sr = load_wav(os.path.join(T, cand)); envs[n] = B.env_fino(x, sr); break
            else:
                envs[n] = None
        return envs[n]
    prev = None
    for k, c in enumerate(tl['clips']):
        c['in0'], c['out0'] = c['in'], c['out']
        e = env(c['archivo'])
        if c.get('fijo'):
            e = None        # orillas que ella puso a mano en el editor: se respetan exactas, no se afinan
        if e is not None:
            ws = [w for w in tl.get('words', []) if 'ss' in w and c['t0'] - 1e-6 <= w['s'] < c['t0'] + (c['out0'] - c['in0']) + 1e-6]
            sig = tl['clips'][k + 1] if k + 1 < len(tl['clips']) else None
            tope_i = prev['out'] if prev and prev['archivo'] == c['archivo'] and prev['out'] <= c['in'] + 1e-6 else None
            tope_f = sig['in'] if sig and sig['archivo'] == c['archivo'] and sig['in'] >= c['out'] - 1e-6 else None
            a = B.refinar_inicio(e, c['in'], tope=tope_i)
            b = B.refinar_fin(e, c['out'], tope=tope_f)
            if ws:   # nunca se recorta una palabra que se dijo: el inicio no pasa del arranque de la primera, el final no queda antes de la última
                a = min(a, max(c['in'], min(w['ss'] for w in ws[:1]) - 0.02))
                b = max(b, min(c['out'], ws[-1]['ee'] + 0.0)) if b < c['out'] else b
            if tope_i is not None: a = max(a, tope_i)
            if tope_f is not None: b = min(b, tope_f)
            if b - a >= 0.12:
                c['in'], c['out'] = round(a, 3), round(b, 3)
        prev = c
    tl['bordes'] = True


if not tl.get('bordes'):
    afinar_bordes(tl)
    save_json(os.path.join(T, 'timeline.json'), tl)

# 1. cortes (reanudable y con memoria): cada corte se guarda con una huella de lo que contiene (archivo, entrada, cuadros,
#    encuadre). En una versión nueva solo se vuelven a cortar los tramos que cambiaron; los demás se reusan tal cual.
import hashlib, math, json
# filtro de color que ella eligió para su video (en sus ajustes); va pegado en la imagen del corte
FILTROS = {
    'cinematografico': ",eq=contrast=1.08:saturation=0.9,colorbalance=rs=-0.03:bs=0.04:rh=0.04:bh=-0.03",
    'calido': ",colorbalance=rs=0.05:gs=0.01:bs=-0.05:rm=0.03:bm=-0.03,eq=saturation=1.05",
    'frio': ",colorbalance=rs=-0.04:bs=0.06:rm=-0.02:bm=0.03",
    'pelicula': ",eq=contrast=0.95:saturation=0.85:gamma=1.03,noise=alls=6:allf=t",
    'byn': ",hue=s=0,eq=contrast=1.05",
}
FILTRO = FILTROS.get((tl.get('filtro') or '').lower(), '')
def vel(c):
    r = c.get('rampa')
    if r:                                # rampa: un solo movimiento fluido de una velocidad a otra; dura lo que da su promedio
        de, a_ = float(r.get('de') or 1), float(r.get('a') or 1)
        return de if abs(a_ - de) < 1e-6 else (a_ - de) / math.log(a_ / de)
    return float(c.get('vel') or 1)      # una parte puede ir más rápida (1.25×, 1.5×, 2×): dura (out-in)/vel en el Reel
def pts_vel(c):
    """setpts de la imagen: constante con vel, o la curva exacta de la rampa (la velocidad cambia parejo de 'de' a 'a')."""
    r = c.get('rampa'); v_ = vel(c)
    if r:
        de, a_ = float(r.get('de') or 1), float(r.get('a') or 1); D = max(0.05, c['out'] - c['in'])
        if abs(a_ - de) > 1e-6:
            K = D / (a_ - de)
            return f"setpts='({K:.6f}*log(({de}+({a_ - de:.6f})*(PTS-STARTPTS)*TB/{D:.6f})/{de}))/TB',"
    return f"setpts=(PTS-STARTPTS)/{v_}," if v_ != 1 else ''
def cuadros(c):
    dd = (c['out'] - c['in']) / vel(c); nn = max(1, round(dd * FPS))
    if nn / FPS < dd - 0.004: nn += 1    # nunca se recorta el final de la voz por redondear a cuadros
    return nn
def zoom_vf(c, n):
    z = c.get('zoom')
    if z not in ('in', 'out'): return ''
    p = f"(on/{max(1, n - 1)})"; s_ = f"({p}*{p}*(3-2*{p}))"          # entra y sale suave
    zz = f"1+0.15*{s_}" if z == 'in' else f"1.15-0.15*{s_}"
    return f",zoompan=z='{zz}':x='iw/2-(iw/zoom/2)':y='ih*0.42-(ih/zoom*0.42)':d=1:s={W}x{H}:fps={FPS}"
def nombre_corte(c):
    h = hashlib.sha1(f"{c['archivo']}|{c['in']:.3f}|{c['frames']}|{a.acerca}|{FPS}x{W}x{H}|{vel(c)}|{c.get('zoom') or ''}|{json.dumps(c.get('rampa'), sort_keys=True)}|{FILTRO}".encode()).hexdigest()[:10]
    return f'c_{h}.mp4'
for c in tl['clips']:
    c['frames'] = cuadros(c)
t_real = 0
for i, c in enumerate(tl['clips']):
    n = cuadros(c)
    d = n / FPS
    c['frames'] = n; c['t0_real'] = round(t_real, 4); t_real += d
    out = os.path.join(C, nombre_corte(c))
    if os.path.exists(out):
        continue
    if time.time() - T0 > a.tiempo:
        save_json(os.path.join(T, 'timeline.json'), tl)
        print(f'PAUSA: van {i} de {len(tl["clips"])} cortes. Vuelve a correr el mismo comando para seguir.'); sys.exit(3)
    f = src[c['archivo']]; path = os.path.join(a.proyecto, 'crudo', f['archivo'])
    af = f"aresample=48000,afade=t=in:d=0.008,apad,atrim=0:{d:.4f},afade=t=out:st={max(0, d - 0.012):.4f}:d=0.012"
    tmp = out + '.tmp.mp4'
    v_ = vel(c)
    vf = pts_vel(c) + vf_for(f) + zoom_vf(c, n) + FILTRO
    if v_ != 1: af = f"atempo={v_}," + af
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', f"{c['in']:.3f}", '-i', path, '-t', f'{d * v_ + 0.5:.3f}',
         '-vf', vf, '-frames:v', str(n), '-af', af, '-ac', '1',
         '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '16', '-g', '15', '-bf', '0', '-threads', '2',
         '-c:a', 'pcm_s16le', '-f', 'mov', tmp])
    os.replace(tmp, out)
tl['duration_real'] = round(t_real, 4)

# 2. une todo con un reencodeo limpio (si no, Remotion puede fallar con "No frame found")
base = os.path.join(T, 'base.mp4'); voz = os.path.join(T, 'voz.wav')
lst = os.path.join(T, 'cortes.txt')
with open(lst, 'w') as fh:
    for c in tl['clips']: fh.write(f"file 'cortes/{nombre_corte(c)}'\n")
firma = hashlib.sha1(open(lst).read().encode()).hexdigest()
firma_ruta = base + '.firma'
if os.path.exists(base) and (not os.path.exists(firma_ruta) or open(firma_ruta).read().strip() != firma):
    os.remove(base)          # los cortes cambiaron: el video base se arma otra vez (si no cambiaron, se reusa sin tocar)
if not os.path.exists(base):
    if time.time() - T0 > a.tiempo * 0.5:
        save_json(os.path.join(T, 'timeline.json'), tl); print('PAUSA: cortes listos; vuelve a correrlo para unirlos.'); sys.exit(3)
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', lst, '-an', '-dn', '-vf', 'setpts=N/30/TB',
         '-r', '30', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-g', '15', '-bf', '0', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', base + '.tmp.mp4'])
    os.replace(base + '.tmp.mp4', base)
    open(firma_ruta, 'w').write(firma)
# 2b. la voz: en cada unión el sonido del corte que sale sigue XF segundos más allá de su imagen (lo que venía en el
#     original) y se funde con el que entra, a potencia constante (cuarto de seno). Así no hay «clic» ni el cuarto se
#     queda en silencio entre cortes. Solo el principio y el final del video se desvanecen a silencio. La duración no cambia.
XF = 0.006      # un ciclo completo de una voz grave: no se corta ningún ciclo a medias
EDGE = 0.006
def armar_voz():
    import numpy as np, subprocess, wave
    SR = 48000; nx = int(round(XF * SR)); ne = int(round(EDGE * SR)); N = len(tl['clips'])
    total = sum(c['frames'] for c in tl['clips']) * SR // FPS
    crudo = []
    for i, c in enumerate(tl['clips']):      # cada pedazo se lee UNA vez, con 30 ms de más para poder fundir más largo
        n = c['frames'] * SR // FPS; quiero = n + int(0.031 * SR); v_ = vel(c)
        path = os.path.join(a.proyecto, 'crudo', src[c['archivo']]['archivo'])
        r = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-ss', f"{c['in']:.4f}", '-i', path, '-t', f'{quiero / SR * v_ + 0.05:.4f}',
                            '-vn', '-ac', '1', '-ar', str(SR)] + (['-af', f'atempo={v_}'] if v_ != 1 else []) + ['-f', 's16le', '-'], capture_output=True)
        x = np.frombuffer(r.stdout, dtype='<i2').astype(np.float32) / 32768.0
        if len(x) < quiero: x = np.concatenate([x, np.zeros(quiero - len(x), dtype=np.float32)])
        crudo.append((n, x[:quiero]))

    def mezclar(fundidos):
        mix = np.zeros(total + int(0.031 * SR), dtype=np.float32); pos = 0; uniones = []
        for i, (n, x0) in enumerate(crudo):
            ki = fundidos[i] if i > 0 else 0          # fundido de la unión que ENTRA a este pedazo
            ko = fundidos[i + 1] if i < N - 1 else 0  # y de la que sale
            x = x0[:n + ko].copy()
            if i == 0: x[:ne] *= np.linspace(0, 1, ne, dtype=np.float32)
            elif ki: x[:min(ki, n)] *= np.sin(np.linspace(0, np.pi / 2, min(ki, n), dtype=np.float32))
            if i < N - 1:
                if ko: x[n:n + ko] *= np.cos(np.linspace(0, np.pi / 2, ko, dtype=np.float32))
                uniones.append(pos + n)
            else: x[n - ne:n] *= np.linspace(1, 0, ne, dtype=np.float32)
            mix[pos:pos + len(x)] += x; pos += n
        return np.clip(mix[:total], -1, 1), uniones

    def malas(y, uniones):
        """Escucha cada unión: un clic (salto brusco) o un hueco (la voz se cae justo en el corte)."""
        d = np.abs(np.diff(y, prepend=y[:1])); out = []
        ms = lambda t: int(t * SR / 1000)
        for j, u in enumerate(uniones):
            if u < ms(45) or u > len(y) - ms(45): continue
            pico = d[u - ms(1.5):u + ms(1.5)].max()
            base = np.median(d[u - ms(30):u + ms(30)]) + 1e-5
            rms = lambda a0, a1: float(np.sqrt(np.mean(y[u + ms(a0):u + ms(a1)] ** 2)) + 1e-6)
            cen, izq, der = rms(-10, 10), rms(-40, -15), rms(15, 40)
            hueco = min(izq, der) > 0.01 and 20 * np.log10(cen / min(izq, der)) < -9
            if pico / base > 12 or hueco: out.append(j + 1)
        return out

    f = [max(int(round(0.003 * SR)), int(round(float(c.get('xfade', XF)) * SR))) for c in tl['clips']]
    y, U = mezclar(f); antes = malas(y, U)
    if antes:      # esas uniones se funden más largo (30 ms) y se vuelven a escuchar; se queda la versión que suene mejor
        f2 = f[:]
        for j in antes: f2[j] = int(0.030 * SR)
        y2, U2 = mezclar(f2); despues = malas(y2, U2)
        mejor = [j for j in antes if j not in despues]
        f3 = f[:]
        for j in mejor: f3[j] = f2[j]
        if mejor:
            y, U = mezclar(f3)
        for j in mejor: tl['clips'][j]['xfade'] = 0.030
        print(f'Uniones: escuché {len(U)}; {len(antes)} sonaban con clic o hueco, {len(mejor)} quedaron limpias con un fundido más largo.')
    else:
        print(f'Uniones: escuché {len(U)}, todas limpias.')
    with wave.open(voz, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((y * 32767).astype('<i2').tobytes())
try:
    armar_voz()
except Exception as ex:     # si algo falla, la unión de siempre (con un desvanecido corto en cada corte)
    print('Aviso: uniones con fundido no disponibles (' + str(ex)[:80] + '); uso la unión simple.')
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', lst, '-vn', '-ac', '1', '-ar', '48000', '-c:a', 'pcm_s16le', voz])

# 3. palabras al tiempo exacto de cuadros
for w in tl['words']:
    c = None
    for cc in tl['clips']:      # el corte dueño de la palabra: el último que ya había empezado cuando ella arranca
        if cc['t0'] <= w['s'] + 1e-3:
            c = cc
    if c and w['s'] >= c['t0'] + (c.get('out0', c['out']) - c.get('in0', c['in'])) + 1e-3:
        c = None            # cayó en un hueco entre cortes
    if c:
        if 'ss' in w:     # tiempos del video original: se vuelven a poner sobre el corte ya afinado
            ini = c['t0_real'] + max(0.0, w['ss'] - c['in']) / vel(c)
            fin = c['t0_real'] + max(0.0, min(w['ee'], c['out']) - c['in']) / vel(c)
        else:
            ini = c['t0_real'] + (w['s'] - c['t0']) / vel(c); fin = c['t0_real'] + (w['e'] - c['t0']) / vel(c)
        w['s'] = round(ini, 3); w['e'] = round(max(ini, min(fin, c['t0_real'] + c['frames'] / FPS)), 3)
for c in tl['clips']:
    c['t0'] = c['t0_real']
save_json(os.path.join(T, 'timeline.json'), tl)
print(f"Listo: {len(tl['clips'])} cortes, {tl['duration_real']:.2f} s → trabajo/base.mp4 y trabajo/voz.wav")
