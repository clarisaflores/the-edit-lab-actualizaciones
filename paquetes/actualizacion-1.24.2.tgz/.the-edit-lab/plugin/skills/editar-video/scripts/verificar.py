"""Paso 11: revisión final antes de entregar.

Uso: python3 verificar.py <video_final.mp4> <carpeta_trabajo> [--modelo small] [--sin_oir]
1. Fotos: saca una foto a la mitad de cada efecto y una cada 10 s en trabajo/revision/ (míralas: cara libre, texto legible, ortografía).
2. Repeticiones: busca frases repetidas seguidas en los subtítulos (señal de que quedó una toma doble).
3. Oído: vuelve a transcribir el video final y lo compara con los subtítulos (palabras cortadas o que no se oyen).
4. Técnica: duración, 1080x1920, 30 fps, nivel de audio.
"""
import argparse, os, sys, json, re, shutil, subprocess, unicodedata
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, load_json, ffprobe

ap = argparse.ArgumentParser()
ap.add_argument('video'); ap.add_argument('trabajo'); ap.add_argument('--modelo', default='small'); ap.add_argument('--sin_oir', action='store_true')
a = ap.parse_args()
T = a.trabajo; tl = load_json(os.path.join(T, 'timeline.json')); cues = load_json(os.path.join(T, 'cues.json'), default={'overlays': []})
D = tl.get('duration_real', tl['duration']); rev = os.path.join(T, 'revision'); shutil.rmtree(rev, ignore_errors=True); os.makedirs(rev)
ok = True

# 1. fotos
marcas = [((o['t0'] + o['t1']) / 2, f"efecto_{i:02d}_{o['kind']}") for i, o in enumerate(cues['overlays'])]
marcas += [(t, f'cada10_{int(t):03d}s') for t in range(2, int(D), 10)]
for t, name in marcas:
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', a.video, '-frames:v', '1', '-vf', 'scale=540:-2', os.path.join(rev, name + '.jpg')])
print(f'1. {len(marcas)} fotos en trabajo/revision/ — revísalas una por una.')

# 2. repeticiones en el texto
def norm(s):
    s = unicodedata.normalize('NFD', s.lower()); return re.sub(r'[^a-z0-9ñ]', '', ''.join(c for c in s if unicodedata.category(c) != 'Mn'))
ws = [norm(w['w']) for w in tl['words']]
rep = []
for n in (4, 3):
    for i in range(len(ws) - 2 * n + 1):
        win = ws[i:i + n]
        for j in range(i + n, min(len(ws) - n + 1, i + n + 12)):
            if ws[j:j + n] == win and len(''.join(win)) > 8:
                rep.append((tl['words'][i]['s'], ' '.join(w['w'] for w in tl['words'][i:i + n]), tl['words'][j]['s']))
seen = set(); rep = [r for r in rep if not (round(r[0]) in seen or seen.add(round(r[0])))]
if rep:
    ok = False; print('2. POSIBLES REPETICIONES (revisa si es a propósito):')
    for s, txt, s2 in rep: print(f'   {s:6.1f} s y {s2:6.1f} s: "{txt}"')
else:
    print('2. Sin frases repetidas.')

# 3. oído
if not a.sin_oir:
    wav = os.path.join(T, '_final16.wav'); run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', a.video, '-vn', '-ac', '1', '-ar', '16000', wav])
    from faster_whisper import WhisperModel
    m = WhisperModel(a.modelo, device='cpu', compute_type='int8')
    segs, _ = m.transcribe(wav, language='es', beam_size=3, condition_on_previous_text=False, vad_filter=False)
    heard = [norm(x) for s in segs for x in s.text.split()]; os.remove(wav)
    import difflib
    sm = difflib.SequenceMatcher(None, ws, heard, autojunk=False)
    falta = [(tl['words'][i1]['s'], ' '.join(w['w'] for w in tl['words'][i1:i2])) for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag in ('delete', 'replace') and i2 - i1 >= 2]
    print(f'3. Coincidencia entre lo que se oye y los subtítulos: {sm.ratio() * 100:.0f}%')
    for s, txt in falta[:15]: print(f'   revisar {s:6.1f} s: "{txt}"')
    if sm.ratio() < 0.85: ok = False

# 4. técnica
info = ffprobe(a.video); v = next(s for s in info['streams'] if s['codec_type'] == 'video')
p = subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-i', a.video, '-af', 'loudnorm=print_format=json', '-vn', '-f', 'null', '-'], capture_output=True, text=True)
lu = json.loads(p.stderr[p.stderr.rindex('{'):p.stderr.rindex('}') + 1])
print(f"4. {float(info['format']['duration']):.1f} s · {v['width']}x{v['height']} · {v['r_frame_rate']} fps · {lu['input_i']} LUFS · pico {lu['input_tp']} dB")
if (v['width'], v['height']) != (1080, 1920): ok = False
print('RESULTADO: todo bien' if ok else 'RESULTADO: hay puntos por revisar')
