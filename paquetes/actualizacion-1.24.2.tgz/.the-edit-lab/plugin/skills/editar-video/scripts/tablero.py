"""Mesa de Efectos: una página donde la clienta toca una palabra del guion, elige un efecto, escribe el texto
y copia la lista de cambios para pegarla en el chat.

Uso: python3 tablero.py <carpeta_proyecto> [--video <mp4 editado>] [--titulo "Tema del video"]
Crea <proyecto>/mesa/index.html y <proyecto>/mesa/video.mp4 (copia ligera 540x960 del último video editado).
- Con la herramienta Artifact: publica index.html con video.mp4 como archivo de apoyo (files: {"video.mp4": ...}).
- Sin ella: la clienta abre 'Abrir mesa de efectos.html' con doble clic (funciona sin internet, con fuentes de respaldo).
"""
import argparse, os, sys, glob, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, load_json

ap = argparse.ArgumentParser()
ap.add_argument('proyecto'); ap.add_argument('--video'); ap.add_argument('--titulo'); ap.add_argument('--estudio')
a = ap.parse_args()
P = os.path.abspath(a.proyecto); T = os.path.join(P, 'trabajo'); out = os.path.join(P, 'mesa'); os.makedirs(out, exist_ok=True)
vid = a.video or max(glob.glob(os.path.join(P, 'resultado', '*.mp4')), key=os.path.getmtime, default=None)
if not vid: raise SystemExit('No hay video editado en resultado/. Edita el video primero.')
tl = load_json(os.path.join(T, 'timeline.json')); cues = load_json(os.path.join(T, 'cues.json'), default={'overlays': [], 'zooms': []})
run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', vid, '-vf', 'scale=540:960', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '28',
     '-c:a', 'aac', '-b:a', '96k', '-movflags', '+faststart', os.path.join(out, 'video.mp4')])
ef = [{'kind': o['kind'], 'text': o.get('text') or ' · '.join(o.get('items') or []) or o.get('image', '') or os.path.splitext(o.get('file', ''))[0].replace('-', ' '), 't0': o['t0'], 't1': o['t1']} for o in cues['overlays']]
ef += [{'kind': 'acercamiento', 'text': '', 't0': z['t0'], 't1': z['t1']} for z in cues.get('zooms', [])]
EST = a.estudio or os.path.dirname(os.path.dirname(P))
extra = []
for p in load_json(os.path.join(EST, 'estilo.json'), default={}).get('efectos_propios', []):
    extra.append({'key': p['kind'], 'nombre': p.get('nombre', p['kind']), 'desc': p.get('descripcion', 'Efecto creado para ti'), 'texto': p.get('lleva_texto', True), 'pos': False})
for m in load_json(os.path.join(EST, 'mis-efectos.json'), default={'efectos': []})['efectos']:
    d = {'sticker': 'Tu sticker o imagen', 'animacion': f"Tu animación ({m.get('duracion', '?')} s)", 'sonido': 'Tu sonido (solo se escucha)'}[m['tipo']]
    extra.append({'key': 'mis:' + m['id'], 'nombre': m['nombre'], 'desc': d, 'texto': False, 'pos': m['tipo'] != 'sonido'})
datos = {'proyecto': os.path.basename(P), 'titulo': a.titulo or os.path.basename(P).replace('-', ' ').capitalize(), 'video': 'video.mp4',
         'duracion': tl.get('duration_real', tl['duration']),
         'words': [{'w': w['w'], 's': w['s'], 'e': w['e'], 'escena': w.get('escena', '')} for w in tl['words']], 'efectos': sorted(ef, key=lambda e: e['t0']), 'extra': extra}
tpl = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tablero_plantilla.html'), encoding='utf-8').read()
i, j = tpl.index('/*DATOS*/'), tpl.index('/*FIN*/') + len('/*FIN*/')
js = json.dumps(datos, ensure_ascii=False).replace('</', '<\\/')
page = tpl[:i] + js + tpl[j:]
open(os.path.join(out, 'index.html'), 'w', encoding='utf-8').write(page)   # para publicar como Artifact
head = '<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
open(os.path.join(out, 'Abrir mesa de efectos.html'), 'w', encoding='utf-8').write(head + page)   # para abrir con doble clic
print(f"Mesa lista: {out}/index.html (+ video.mp4, {os.path.getsize(os.path.join(out, 'video.mp4')) / 1e6:.1f} MB)")
