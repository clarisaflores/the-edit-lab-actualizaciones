"""Lee la carpeta "Mis efectos" de la clienta (o la que indique "carpetas" en estilo.json) y deja cada archivo listo para usarse en sus videos.

Uso: python3 mis_efectos.py <carpeta_estudio> --publico <motor/remotion/public>
- Imágenes y stickers (.png .jpg .jpeg .webp): se usan tal cual (PNG con fondo transparente = sticker).
- GIF y videos (.gif .mov .mp4 .webm): se convierten a animación con transparencia.
    · fondo verde → se quita el verde
    · fondo negro (brillos, destellos, luces) → se mezcla en modo "screen" (lo negro desaparece)
    · ya transparente (.mov ProRes 4444, .webm con alfa, .gif) → se respeta
- Sonidos (.mp3 .wav .m4a .aac): quedan disponibles por su nombre.
Crea <estudio>/mis-efectos.json (el catálogo que ven la Mesa de Efectos y el editor) y guarda las conversiones
en <estudio>/.motor/mis para no repetirlas. Nunca modifica los archivos originales.
"""
import argparse, os, sys, re, shutil, unicodedata, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, ffprobe, load_json, save_json, carpeta

ap = argparse.ArgumentParser()
ap.add_argument('estudio'); ap.add_argument('--publico', required=True)
a = ap.parse_args()
EST = os.path.abspath(a.estudio); SRC = carpeta(EST, 'mis_efectos'); CACHE = os.path.join(EST, '.motor', 'mis')
PUB = os.path.join(a.publico, 'mis')
for d in (SRC, CACHE, PUB): os.makedirs(d, exist_ok=True)
prev = {e['origen']: e for e in load_json(os.path.join(EST, 'mis-efectos.json'), default={'efectos': []})['efectos']}

def slug(s):
    s = unicodedata.normalize('NFD', s.lower()); s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9]+', '-', s).strip('-') or 'efecto'

def tipo_fondo(path):
    import numpy as np, subprocess
    p = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-i', path, '-frames:v', '1', '-vf', 'scale=64:64,format=rgba', '-f', 'rawvideo', '-'], capture_output=True)
    px = np.frombuffer(p.stdout, np.uint8)
    if px.size < 64 * 64 * 4: return 'otro'
    px = px.reshape(64, 64, 4).astype(int)
    c = np.concatenate([px[:6, :6].reshape(-1, 4), px[:6, -6:].reshape(-1, 4), px[-6:, :6].reshape(-1, 4), px[-6:, -6:].reshape(-1, 4)])
    if (c[:, 3] < 40).mean() > 0.6: return 'transparente'
    r, g, b = c[:, 0], c[:, 1], c[:, 2]
    if ((g > 120) & (g > r + 50) & (g > b + 50)).mean() > 0.6: return 'verde'
    if ((r < 30) & (g < 30) & (b < 30)).mean() > 0.6: return 'negro'
    return 'otro'

cat = []; avisos = []
for f in sorted(os.listdir(SRC)):
    if f.startswith('.'): continue
    path = os.path.join(SRC, f); base, ext = os.path.splitext(f); ext = ext.lower()
    if os.path.isdir(path): continue
    nombre = re.sub(r'[_\-]+', ' ', base).strip(); nombre = nombre[:1].upper() + nombre[1:]; sid = slug(base)
    mtime = os.path.getmtime(path)
    old = prev.get(f)
    if old and old.get('_mtime') == mtime and (old['tipo'] == 'sonido' or os.path.exists(os.path.join(CACHE, old['archivo']))):
        e = old
    elif ext in ('.png', '.jpg', '.jpeg', '.webp'):
        out = sid + ('.png' if ext == '.png' else ext)
        shutil.copy(path, os.path.join(CACHE, out))
        info = ffprobe(path); v = info['streams'][0]
        e = {'id': sid, 'nombre': nombre, 'tipo': 'sticker', 'archivo': out, 'ancho': v.get('width'), 'alto': v.get('height')}
    elif ext in ('.gif', '.mov', '.mp4', '.webm', '.m4v'):
        fb = tipo_fondo(path); out = sid + '.webm'; mezcla = None
        vf = 'fps=30,scale=720:-2:flags=lanczos'
        if fb == 'verde': vf += ',colorkey=0x00FF00:0.30:0.12,format=yuva420p'
        elif fb == 'negro': mezcla = 'screen'; vf += ',format=yuv420p'
        else: vf += ',format=yuva420p'
        dec = ['-c:v', 'libvpx-vp9'] if ext == '.webm' else []   # decodificador que conserva la transparencia de los .webm
        run(['ffmpeg', '-nostdin', '-v', 'error', '-y', *dec, '-i', path, '-an', '-vf', vf, '-c:v', 'libvpx-vp9', '-pix_fmt', 'yuva420p' if mezcla is None else 'yuv420p',
             '-auto-alt-ref', '0', '-b:v', '0', '-crf', '30', '-deadline', 'good', '-cpu-used', '4', os.path.join(CACHE, out)])
        info = ffprobe(os.path.join(CACHE, out))
        e = {'id': sid, 'nombre': nombre, 'tipo': 'animacion', 'archivo': out, 'duracion': round(float(info['format']['duration']), 2), 'fondo': fb}
        if mezcla: e['mezcla'] = mezcla
        if fb == 'otro': avisos.append(f'"{f}" no tiene fondo verde, negro ni transparente: se verá como un recuadro. Si no es lo que quieres, pásalo con fondo verde.')
    elif ext in ('.mp3', '.wav', '.m4a', '.aac'):
        e = {'id': sid, 'nombre': nombre, 'tipo': 'sonido', 'archivo': f}
    else:
        avisos.append(f'"{f}" no es imagen, video ni sonido; lo ignoro.'); continue
    e['origen'] = f; e['_mtime'] = mtime
    if e['tipo'] != 'sonido': shutil.copy(os.path.join(CACHE, e['archivo']), os.path.join(PUB, e['archivo']))
    cat.append(e)

save_json(os.path.join(EST, 'mis-efectos.json'), {'efectos': cat})
for e in cat:
    extra = f" · {e['duracion']} s" if 'duracion' in e else ''
    extra += ' · sin fondo negro (se mezcla)' if e.get('mezcla') else (' · se quitó el verde' if e.get('fondo') == 'verde' else '')
    print(f"{e['tipo']:9s} {e['id']:24s} {e['nombre']}{extra}")
if not cat: print('La carpeta "Mis efectos" está vacía.')
for x in avisos: print('AVISO:', x)
