"""Bordes exactos de la voz: dónde EMPIEZA y dónde TERMINA de verdad una frase o una palabra, medido en el sonido.

Un corte que cae unos milisegundos tarde se come el arranque suave de la palabra (la p, la t, la f…) y parece que no la dijiste;
uno que cae temprano o tarde deja silencio pegado. Aquí se mide con una envolvente fina (5 ms) y se deja un colchón mínimo:
PRE antes del arranque y POST después de que la voz se apaga, para que la frase quede pegada, pero sin recortar nada.
"""
import numpy as np

HOP_F = 0.005       # 5 ms por cuadro
VENT_F = 0.010      # ventana de 10 ms
PRE = 0.042         # colchón antes del arranque de la voz (42 ms: cubre el ataque con aire de la palabra más medio cuadro)
POST = 0.060        # colchón después de que la voz se apaga (60 ms: la cola de la última letra más medio cuadro)
RETROCESO_INI = 0.030   # la subida de un arranque suave dura menos que esto; más allá es respiración o ruido, no voz
RETROCESO_FIN = 0.140   # la cola de una última vocal o «s» puede durar más


def env_fino(x, sr):
    n, h = int(sr * VENT_F), int(sr * HOP_F)
    m = max(0, (len(x) - n) // h)
    if m == 0:
        return np.zeros(1)
    c = np.concatenate([[0.0], np.cumsum(x.astype(np.float64) ** 2)])
    a = np.arange(m) * h
    rms = np.sqrt((c[a + n] - c[a]) / n)
    return 20 * np.log10(rms + 1e-9)


def niveles(e):
    piso, techo = np.percentile(e, 10), np.percentile(e, 95)
    rango = max(10.0, techo - piso)
    return piso, piso + max(7.0, 0.22 * rango), piso + max(4.5, 0.07 * rango)   # piso, umbral de voz, umbral bajo


def _i(t):
    return int(round(t / HOP_F))


def inicio_real(e, t, ventana=(0.30, 0.35), tope=None):
    """Tiempo (s) donde de verdad arranca la voz cerca de t. `tope` = no ir más atrás de esto (fin de la voz anterior)."""
    piso, hi, lo = niveles(e)
    i0, i1 = max(0, _i(t - ventana[0])), min(len(e) - 3, _i(t + ventana[1]))
    t_min = _i(tope) if tope is not None else 0

    def voz(i):
        return 0 <= i and i + 3 <= len(e) and bool((e[i:i + 3] > hi).all())
    i = _i(t)
    if voz(i):                       # ya hay voz en t: retrocede hasta el principio de esa racha
        while i - 1 >= i0 and voz(i - 1):
            i -= 1
        pegada = i <= i0 and voz(i0)
    else:                            # t cae en silencio: el arranque está adelante
        j = i
        while j <= i1 and not voz(j):
            j += 1
        if j > i1:
            return t
        i, pegada = j, False
    if pegada:                       # la voz viene pegada de antes: se corta en el valle más hondo
        a, b = max(t_min, i0), min(i + 4, i1)
        v = a + int(np.argmin(np.convolve(e[a:b + 1], np.ones(3) / 3, mode='same')))
        return v * HOP_F
    k = i
    lim = max(t_min, i - int(RETROCESO_INI / HOP_F))
    while k - 1 >= lim and e[k - 1] > lo:     # arranque suave: baja mientras siga sobre el ruido
        k -= 1
    return k * HOP_F


def fin_real(e, t, ventana=(0.35, 0.30), tope=None):
    """Tiempo (s) donde la voz de verdad se apaga cerca de t. `tope` = no pasar de esto (inicio de la voz siguiente)."""
    piso, hi, lo = niveles(e)
    i0, i1 = max(3, _i(t - ventana[0])), min(len(e) - 1, _i(t + ventana[1]))
    t_max = _i(tope) if tope is not None else len(e)

    def voz(i):
        return i - 2 >= 0 and i < len(e) and bool((e[i - 2:i + 1] > hi).all())
    i = min(_i(t), len(e) - 1)
    if voz(i):
        while i + 1 <= i1 and voz(i + 1):
            i += 1
        pegada = i >= i1 and voz(i1)
    else:
        j = i
        while j >= i0 and not voz(j):
            j -= 1
        if j < i0:
            return t
        i, pegada = j, False
    if pegada:
        a, b = max(i - 4, i0), min(t_max, i1)
        if b <= a:
            return i * HOP_F
        v = a + int(np.argmin(np.convolve(e[a:b + 1], np.ones(3) / 3, mode='same')))
        return (v + 2) * HOP_F
    k = i
    lim = min(t_max, i + int(RETROCESO_FIN / HOP_F), len(e) - 1)
    while k + 1 <= lim and e[k + 1] > lo:
        k += 1
    return (k + 2) * HOP_F      # +2: la ventana de 10 ms termina 2 cuadros después de su inicio


# ---------------------------------------------------------------------------------------------------------------
# Refinar un corte ya decidido (sea automático o arrastrado por ella): solo se mueve cuando el borde está CERCA de un
# borde de voz; si cae a la mitad de una palabra o entre voz pegada, se respeta tal cual (ella pudo haberlo querido así).

def _hay_voz(e, hi, i):
    return 0 <= i and i + 3 <= len(e) and bool((e[i:i + 3] > hi).all())


def refinar_inicio(e, t, tope=None, ya_dentro=0.050, adelante=0.35):
    """Mueve un inicio de corte a (arranque real − PRE). Devuelve el nuevo tiempo (o t si no hay nada que mejorar)."""
    piso, hi, lo = niveles(e)
    i = _i(t)
    if _hay_voz(e, hi, i):
        j = i
        tope_i = _i(tope) if tope is not None else 0
        lim = max(tope_i, i - int(ya_dentro / HOP_F) - int(RETROCESO_INI / HOP_F))
        while j - 1 >= lim and _hay_voz(e, hi, j - 1):
            j -= 1
        if j <= tope_i or _hay_voz(e, hi, j - 1):   # la racha de voz sigue más atrás de lo normal: voz pegada, no tocar
            return t
        if (i - j) * HOP_F > ya_dentro:       # el corte cae bien adentro de la palabra: ella lo quiso así
            return t
        k = j
        low_lim = max(tope_i, j - int(RETROCESO_INI / HOP_F))
        while k - 1 >= low_lim and e[k - 1] > lo:
            k -= 1
        if k - 1 < tope_i + 0:
            k = max(k, tope_i)
        return max(0.0, k * HOP_F - PRE)
    j = i
    lim = min(len(e) - 3, i + int(adelante / HOP_F))
    while j <= lim and not _hay_voz(e, hi, j):
        j += 1
    if j > lim:
        return t
    k = j
    while k - 1 > i and e[k - 1] > lo and (j - k) * HOP_F < RETROCESO_INI:
        k -= 1
    return max(t, k * HOP_F - PRE)        # solo se quita silencio de adelante: nunca se retrocede desde un silencio


def refinar_fin(e, t, tope=None, ya_dentro=0.090, atras=0.35):
    """Mueve un final de corte a (voz apagada + POST)."""
    piso, hi, lo = niveles(e)
    i = min(_i(t), len(e) - 1)

    def voz(k):
        return k - 2 >= 0 and k < len(e) and bool((e[k - 2:k + 1] > hi).all())
    if voz(i):
        j = i
        tope_i = _i(tope) if tope is not None else len(e)
        lim = min(tope_i, len(e) - 2, i + int(ya_dentro / HOP_F) + int(RETROCESO_FIN / HOP_F))
        while j + 1 <= lim and voz(j + 1):
            j += 1
        if j >= tope_i or voz(j + 1):             # la voz sigue más adelante de lo normal: voz pegada, no tocar
            return t
        if (j - i) * HOP_F > ya_dentro:
            return t
        k = j
        high_lim = min(tope_i, j + int(RETROCESO_FIN / HOP_F), len(e) - 2)
        while k + 1 <= high_lim and e[k + 1] > lo:
            k += 1
        return (k + 2) * HOP_F + POST
    j = i
    lim = max(3, i - int(atras / HOP_F))
    while j >= lim and not voz(j):
        j -= 1
    if j < lim:
        return t
    k = j
    while k + 1 < i and e[k + 1] > lo and (k - j) * HOP_F < RETROCESO_FIN:
        k += 1
    return min(t, (k + 2) * HOP_F + POST)   # solo se quita silencio de atrás: nunca se avanza desde un silencio
