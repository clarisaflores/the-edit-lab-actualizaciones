"""Carpetas del estudio. Cada clienta puede apuntar cualquiera a una carpeta suya con "carpetas" en estilo.json
(ruta relativa a la carpeta del estudio, p. ej. "../Brand Assets/01 LOGO & FONTS", o absoluta). Si no, se usan los nombres de siempre.

Uso en la terminal:  eval "$(python3 carpetas.py <carpeta_estudio>)"
  Define PARA_EDITAR, REFERENCIAS, FUENTES, SONIDOS, MIS_EFECTOS, MIS_VIDEOS y SONIDOS_PROPIOS (1 = la carpeta de sonidos es de ella).
Con --revisar: muestra cada carpeta, si es suya o del estudio y si existe.
Sin dependencias (solo la biblioteca estándar) para que el instalador la pueda usar desde el primer paso.
"""
import json, os, sys, shlex

CARPETAS = {
    'para_editar': 'Para editar',
    'referencias': 'Referencias',
    'fuentes': 'Fuentes',
    'efectos_de_sonido': 'Efectos de sonido',
    'mis_efectos': 'Mis efectos',
    'mis_videos': 'Mis videos',
}
VAR = {'para_editar': 'PARA_EDITAR', 'referencias': 'REFERENCIAS', 'fuentes': 'FUENTES',
       'efectos_de_sonido': 'SONIDOS', 'mis_efectos': 'MIS_EFECTOS', 'mis_videos': 'MIS_VIDEOS'}


def _perfil(est):
    try:
        with open(os.path.join(est, 'estilo.json'), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


# Estructura de The Edit Lab en la computadora (Reels + Brand Assets 01–09): si existe, es la de siempre.
LAB = {
    'para_editar': 'Reels',
    'referencias': 'Brand Assets/05 EDITING REFERENCES',
    'fuentes': 'Brand Assets/01 LOGO & FONTS',
    'efectos_de_sonido': 'Brand Assets/07 SOUNDS EFFECTS',
    'mis_efectos': 'Brand Assets/04 STICKERS & GRAPHICS',
    'mis_videos': '.the-edit-lab/Mis videos',
}


def _base(est, clave):
    if os.path.isdir(os.path.join(est, 'Brand Assets')) and os.path.isdir(os.path.join(est, 'Reels')):
        return LAB[clave]
    return CARPETAS[clave]


def carpeta(est, clave):
    """Ruta real de una carpeta del estudio."""
    est = os.path.abspath(est)
    v = (_perfil(est).get('carpetas') or {}).get(clave) or _base(est, clave)
    v = os.path.expanduser(v)
    return os.path.normpath(v if os.path.isabs(v) else os.path.join(est, v))


def carpeta_propia(est, clave):
    """True si apunta a una carpeta suya (el motor nunca escribe ni genera archivos ahí)."""
    return carpeta(est, clave) != os.path.normpath(os.path.join(os.path.abspath(est), CARPETAS[clave]))


if __name__ == '__main__':
    est = sys.argv[1]
    if '--revisar' in sys.argv:
        for k, nombre in CARPETAS.items():
            p = carpeta(est, k)
            print(f"{nombre}: {'tuya' if carpeta_propia(est, k) else 'del estudio'} → {p} ({'ok' if os.path.isdir(p) else 'NO EXISTE'})")
    else:
        for k, var in VAR.items():
            print(f'{var}={shlex.quote(carpeta(est, k))}')
        print(f"SONIDOS_PROPIOS={1 if carpeta_propia(est, 'efectos_de_sonido') else 0}")
