# Cómo funciona el motor (y por qué)

Cada paso trae lo que sale mal si se hace de la forma obvia. Los scripts ya lo resuelven; esto sirve para decidir bien y para arreglar casos raros.

## 1. Orientación (`preparar.py`)
- Los teléfonos guardan el giro como dato y ffmpeg lo aplica solo. Pero algunas cámaras graban acostado sin ese dato: el script prueba si la cara aparece al girar el cuadro. Si se equivoca, fuerza `--girar si|no`.
- Hace dos audios por archivo: el original (para transcribir) y uno sin ruido con `arnndn` (para medir dónde está la voz de verdad).

## 2. Pedazos y repeticiones (`pedazos.py`)
- Una transcripción normal junta "si tienes… si tienes… si tienes una cuenta" en una sola frase y esconde las repeticiones. Por eso el audio limpio se parte en pedazos de voz (umbral −26 dB, huecos de 0.12 s) y cada pedazo se transcribe solo.
- Sin `initial_prompt` (en pedazos cortos el modelo lo repite como si se hubiera dicho) y sin filtro VAD (se come frases enteras).
- Ruidos de casa, niños, mascotas o la calle salen como pedazos con textos raros ("¡Ah!", "Gracias", palabras en inglés): no son tomas.
- Memoria: el modelo `medium` usa unos 3 GB. Con menos RAM, `--modelo small`.

## 3. Elegir tomas (`tomas.json` → `linea_tiempo.py`)
- La persona repite cada frase hasta que le sale; normalmente la buena es la ÚLTIMA completa.
- Arranques en falso dentro de un mismo pedazo: recórtalos con `desde_palabra`.
- Bordes: los tiempos de las palabras de la transcripción empiezan tarde. El script busca el arranque suave real de la voz (−38 dB en el audio limpio) sin pasar de la mitad del silencio con el pedazo vecino, así no se come el inicio de las palabras ni mete el final de la toma repetida.
- Pausas internas de `--pausa` segundos o más se recortan dejando 0.06 s a cada lado.
- Subtítulos: quita los "..." de la transcripción y pone mayúscula al inicio de cada oración y escena. Revisa el texto impreso: es exactamente lo que saldrá en pantalla. Para una palabra compuesta mal escrita que no se arregla con `correcciones`, edita `timeline.json → words` a mano.

## 4. Corte (`cortar.py`)
- Vertical 1080×1920 a 30 fps, escalado para cubrir sin deformar (`--acerca` acerca un poco el encuadre).
- Cada corte se ajusta a cuadros exactos y su audio se rellena a esa misma duración: si no, la voz se adelanta y los subtítulos se descuadran.
- La unión se re-codifica limpia (`setpts`, GOP 15, sin B-frames, sin pista de datos). Si no, Remotion falla con "No frame found at position".

## 5. Cara (`cara.py`)
- Mide el centro de la cara y dónde empieza la cabeza. Todo texto va arriba de `top − 40` px (o en la zona que diga su estilo, siempre sin tocar la cara). Los acercamientos se centran en la cara.

## 6. Efectos (`plan.json` → `cues.py`)
- Ver `efectos.md`. Se anclan a la palabra (sin importar acentos o mayúsculas); `vez` elige la 2.ª o 3.ª vez que la dice.
- Uno o dos textos a la vez como máximo. Si dos coinciden, el script los apila en la franja de títulos.
- Los emojis se dibujan como imagen (PNG del paquete `emoji-datasource-google`): la fuente de emojis no siempre aparece en el render. Si un símbolo no tiene imagen, cámbialo.

## 7. Audio (`audio.py`)
- Voz: filtro de graves, `arnndn` + `afftdn` y una compuerta guiada por las palabras (entre palabras baja a 6 %, con rampas de 30 ms). Así se van los ruidos de casa sin tocar la voz. Si un ruido suena ENCIMA de la voz, solo se puede bajar, no quitar: dilo.
- Efectos de sonido con pico a −9 dBFS antes de nivelar: se oyen claro y debajo de la voz. `--sfx_db` sube o baja todos.
- Música solo si ella la pide y el archivo es suyo o libre de derechos (`--musica`), unos 20 dB debajo de la voz.
- Nivel final −14 LUFS en dos pasadas y limitador.

## 8. Animación y render (`final.py`)
- Subtítulos en posición FIJA del perfil; en modo `palabra` se achican solo si una palabra no cabe en el ancho.
- Si su fuente no trae acentos o ñ (fuentes demo), la de respaldo los dibuja; `ajuste_respaldo` iguala su tamaño (p. ej. 130–140 %).
- Entrada de textos en 0.28 s con desenfoque de movimiento solo durante la entrada; máquina de escribir a 0.035 s por letra; fundido final según el perfil.
- Render por tramos de 15 s con `--concurrency=1` (poca RAM) y reintento automático. Siempre haz primero la vista previa de 5 s del gancho.

## 9. Guardar
- Nombre corto del tema en minúsculas con guiones: `tema_v1.mp4`. La versión siguiente nunca reemplaza a la anterior.
- En carpetas conectadas a veces no se puede borrar ni mover: copia, no muevas; y no borres nada de ella.
