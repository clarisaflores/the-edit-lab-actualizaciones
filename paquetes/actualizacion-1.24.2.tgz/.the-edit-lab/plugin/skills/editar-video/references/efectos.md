# Catálogo de efectos

Cada efecto es un `kind` de `plan.json` (ver `pipeline.md`, paso 8). Se anclan a una palabra de la transcripción para que salgan justo cuando se dice. Los sonidos se toman del perfil (`estilo.json → sonidos`).

| kind | Nombre para la clienta | Cuándo usarlo | Campos | Sonido |
|---|---|---|---|---|
| `gancho` | Gancho editorial | El hook elegido, 2–3 renglones en MAYÚSCULAS (el último corto y grande), desde t 0, ~2.3 s; con `"detras": true` el último renglón queda detrás de su cabeza | `text` con `\n`, `detras` | inicio + pop por renglón |
| `palabra` | Palabra protagonista | La idea clave en una palabra grande, con acercamiento; detrás de su cabeza por defecto | `text`, `detras` | lista |
| `tachado` | Palabra tachada | Algo que se quita o se descarta: aparece y una línea la tacha al terminar de decirla (`tacha_en` para otra palabra); hasta 2 a la vez | `text`, `tacha_en` | click al tachar |
| `cierre` | Título de cierre | Sus últimas palabras arriba, delante; `aparece`: una palabra por renglón | `text` con `\n`, `aparece` | ninguno |
| `titulo` | Título del gancho | Desde el cuadro 0, 3 a 5 s, para que se entienda sin audio | `text` (puede llevar `\n` y emojis) | inicio |
| `flotante` | Lista flotante | Al nombrar 2 a 4 cosas seguidas; una entrada por palabra, en posiciones distintas | `text`, `x`, `y` | lista |
| `paso` | Paso numerado | Cada punto de una enseñanza ("1. …") | `text` | paso |
| `paso_escribe` | Paso que se escribe | Preguntas o pasos que conviene leer completos | `text` | escribir |
| `caja` | Caja resaltada | Pregunta, ejemplo o frase clave (con 💬 si es un comentario) | `text` | lista |
| `caja_escribe` | Caja que se escribe | Ejemplo o frase larga que se escribe letra por letra | `text` | escribir |
| `formula` | Fórmula | "A = B" o una comparación corta; dos entradas una tras otra | `text` | paso |
| `checklist` | Checklist | Pasos que se van palomeando | `items` | paso |
| `contador` | Contador de meta | Metas o avances, SOLO con datos reales que diga la clienta | `n`, `text` (etiqueta) | paso |
| `burbujas` | Lluvia de comentarios | Cuando habla de lo que le preguntan o comentan | `items` | lista |
| `imagen` | Imagen que entra | Portada de su producto o una captura que ella dé (carpeta del proyecto) | `image` | click |
| `cta` | Llamado a la acción | "💬 Comenta PALABRA", "Guarda este video"; solo lo que ella grabó o eligió | `text` | lista |
| `sticker` | Sticker de Mis efectos | Imagen o PNG suyo que entra con un pop | `efecto` (id), `posicion`, `tam`, `rot` | lista |
| `animacion` | Animación de Mis efectos | Su animación con fondo verde, negro o transparente | `efecto` (id), `posicion`, `tam` | ninguno |
| `sonido` | Sonido de Mis efectos | Solo suena, no se ve nada | `efecto` (id) | el suyo |
| *(su kind)* | Efecto propio | Los creados con **crear-efecto** (`estilo.json → efectos_propios`) | `text` y los que tenga | el de su ficha |

Los cuatro primeros miden solos el tamaño de cada renglón con su fuente de títulos, no se salen de la pantalla, esconden los subtítulos mientras están (menos `tachado`) y entran con un pop. Lo que va detrás de su silueta lo pinta `detras.py` después del render (lo llama `final.py` solo); si en esa compu no hay recorte de silueta, va delante, arriba de la cabeza, y `cues.py` lo avisa.

Además:
- **Acercamiento** (`zooms` en `plan.json`): 1.00 → `movimiento.escala` en 0.35 s, con desenfoque de movimiento, en frases clave; regresa en el siguiente corte o a los 3 s. Solo si `movimiento.acercamientos` es true o ella pidió más movimiento.
- **Fundido final**: automático según `movimiento.fundido_final`, con el sonido `cierre`.
- **Subtítulos**: no son efecto del plan; salen del perfil (`palabra`, `frase` o `karaoke`).

Reglas de colocación:
- Todo texto va en la franja `titulos.zona` (arriba por defecto) y nunca encima de la cara: mide la parte de arriba de la cabeza con `cara.py` y deja margen.
- Uno o dos elementos a la vez como máximo; cada uno dura entre 1 y 5 s (un paso unos 4 s; un título hasta 5 s).
- `efectos.por_minuto` del perfil marca el ritmo; prefiere sus `efectos.favoritos`.
- Ortografía perfecta; nombres propios y marcas tal como están en `contenido.nombres_exactos`.
- Nada de datos, cifras, precios o regalos inventados.
