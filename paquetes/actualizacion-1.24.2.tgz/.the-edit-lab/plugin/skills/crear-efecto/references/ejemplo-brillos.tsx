// Efecto propio de ejemplo: "brillos". Un texto que entra con brillitos de 4 puntas que parpadean alrededor.
// Se guarda como EST/efectos-propios/brillos.tsx; el nombre del archivo es el "kind" que se usa en plan.json.
import React from 'react';
import {interpolate, Easing, random} from 'remotion';

type Props = {o: any; t: number; kit: any};

const Estrella: React.FC<{x: number; y: number; s: number; color: string; a: number}> = ({x, y, s, color, a}) => (
  <svg width={s} height={s} viewBox="-10 -10 20 20" style={{position: 'absolute', left: x - s / 2, top: y - s / 2, opacity: a, transform: `scale(${0.4 + 0.6 * a}) rotate(${a * 45}deg)`}}>
    <path d="M0 -10 C1 -2 2 -1 10 0 C2 1 1 2 0 10 C-1 2 -2 1 -10 0 C-2 -1 -1 -2 0 -10Z" fill={color} />
  </svg>
);

const Brillos: React.FC<Props> = ({o, t, kit}) => {
  const {W, col, TS, TIT_FONT, Rich, base, pIn, op} = kit;
  const color = o.color || col.resaltado || '#FFF6C1';
  const n = o.cantidad || 10;
  const cx = o.x ?? W / 2, cy = kit.y;
  const ancho = 520, alto = 150;
  return (
    <>
      <div style={{...base, fontSize: (o.tamano || TS) * 1.0}}><Rich text={o.text || ''} /></div>
      {Array.from({length: n}).map((_, i) => {
        const ang = random(`a${i}`) * Math.PI * 2;
        const x = cx + Math.cos(ang) * ancho * (0.55 + 0.25 * random(`r${i}`));
        const y = cy + Math.sin(ang) * alto * (0.6 + 0.4 * random(`q${i}`));
        const fase = random(`f${i}`) * 1.2;                       // cada brillo parpadea a su ritmo
        const ciclo = ((t - o.t0 + fase) % 1.2) / 1.2;
        const a = Math.sin(ciclo * Math.PI) * op * interpolate(pIn, [0, 1], [0, 1], {easing: Easing.out(Easing.quad)});
        return <Estrella key={i} x={x} y={y} s={22 + 26 * random(`s${i}`)} color={color} a={a} />;
      })}
    </>
  );
};
export default Brillos;
