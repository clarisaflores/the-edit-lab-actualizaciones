# Contrato de un efecto propio

Archivo: `EST/efectos-propios/<kind>.tsx`. `final.py preparar` lo copia a `src/propios/` del motor y arma el índice; `Main.tsx` lo dibuja cuando `cues.json` trae un efecto con ese `kind`, solo entre `o.t0` y `o.t1`.

```tsx
import React from 'react';
import {interpolate, Easing, random, spring, Img, staticFile} from 'remotion'; // lo que necesites
const MiEfecto: React.FC<{o: any; t: number; kit: any}> = ({o, t, kit}) => { ... };
export default MiEfecto;   // obligatorio: export default
```

## Qué recibe
- `o`: el efecto de `cues.json`: `kind`, `text`, `t0`, `t1`, `x`, `y`, `tam`, `items` y cualquier campo extra que pusiste en `plan.json` (por ejemplo `color`, `cantidad`).
- `t`: segundo actual del video (absoluto). Tiempo dentro del efecto: `t - o.t0`; duración: `o.t1 - o.t0`.
- `kit`:
  - `W`, `H`, `FPS`: 1080, 1920, 30.
  - `col`: colores del perfil (`subtitulo`, `texto`, `caja`, `caja_texto`, `resaltado`, `resaltado_texto`). `tit`, `sub`: secciones del perfil.
  - `TS`: tamaño base de títulos. `TIT_FONT`, `SUB_FONT`: familias ya cargadas.
  - `Rich`: componente que dibuja texto con emojis y saltos de línea: `<Rich text={o.text} />`.
  - `box(extra)`: estilo de caja del perfil. `base`: estilo del texto de títulos ya posicionado (centro en `x`, `y`) con entrada y salida.
  - `pIn` (0→1 en la entrada, 0.28 s, con rebote), `pOut` (1→0 en la salida), `op` (opacidad combinada), `typingN` (letras visibles a 0.035 s por letra).
  - `cx`, `y`: centro donde va el efecto (ya acomodado en la franja de títulos o en su `posicion`).

## Reglas
- Todo con `position: 'absolute'` dentro del cuadro de 1080×1920. Nada sobre la cara (el script avisa si un `posicion` la tapa; para efectos con texto, la franja de títulos ya está libre).
- Deterministas: nada de `Math.random()` ni `Date`; usa `random('semilla')` de Remotion. Todo depende de `t`.
- Sin imágenes ni fuentes de internet: solo SVG/CSS dibujados en el código, o archivos de `public/` (por ejemplo sus stickers en `mis/<archivo>`).
- Sin `useState`/`useEffect` para animar; calcula con `interpolate` y `spring`.
- Entrada y salida suaves (usa `pIn`/`op`) para que combine con los demás efectos.
- Ligero: menos de ~60 elementos a la vez; el render es en una máquina modesta.
- Si falla el render, el mensaje trae el archivo y la línea; corrige y vuelve a probar con una vista previa corta.
