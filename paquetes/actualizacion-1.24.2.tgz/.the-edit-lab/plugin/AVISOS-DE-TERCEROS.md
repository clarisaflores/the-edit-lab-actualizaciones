# Avisos de terceros · The Edit Lab

The Edit Lab usa estos componentes de otras personas, cada uno con su propia licencia:

### HyperFrames
- Fuente: https://github.com/heygen-com/hyperframes
- Copyright 2026 HeyGen, Inc.
- Licencia: Apache License 2.0 (copia en `licencias/HYPERFRAMES-LICENSE-APACHE-2.0.txt`).
- The Edit Lab instala la herramienta HyperFrames 0.9.6 en la compu de cada clienta y usa su catálogo público de efectos. El «Catálogo de efectos» de la página muestra sus nombres (traducidos al español), sus descripciones y las vistas previas que HyperFrames publica. Los efectos se adaptan a las fuentes, colores y palabras de cada clienta.

### Remotion
- Fuente: https://www.remotion.dev · licencia propia de Remotion (gratis para personas y equipos pequeños; las empresas más grandes necesitan su licencia de empresa: https://www.remotion.dev/license).
