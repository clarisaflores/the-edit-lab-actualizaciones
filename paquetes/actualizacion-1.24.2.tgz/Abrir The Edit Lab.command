#!/bin/bash
# The Edit Lab · abre tu página en tu Mac (doble clic). Deja esta ventana abierta mientras editas.
cd "$(dirname "$0")" || exit 1
EST="$(pwd)"
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
export PATH="$HOME/.cvs-motor/bin:$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH" PYTHONUTF8=1
LAB="$EST/.the-edit-lab/plugin/skills/instalar-the-edit-lab/local/lab.py"
if [ ! -x "$HOME/.cvs-motor/bin/python3" ]; then
  echo "Primero instala The Edit Lab: doble clic en «Instalar The Edit Lab.command»."
  read -r -p "Toca Enter para cerrar…" _; exit 1
fi
# ¿Ya está abierta? Solo cuenta si quien responde es The Edit Lab (otras apps también usan localhost).
# Si lo abierto es una versión anterior a la que tienes instalada, se reinicia para que cargue la nueva.
VER="$(grep -o '"version": *"[^"]*"' "$EST/.the-edit-lab/plugin/.claude-plugin/plugin.json" 2>/dev/null | grep -o '[0-9][0-9.]*' | head -1)"
for p in 4791 4792 4793 4794 4795 4796 4797 4798 4799 4800; do
  Q="$(curl -s -m 1 "http://localhost:$p/api/quien")"
  if echo "$Q" | grep -q '"the-edit-lab"'; then
    if [ -n "$VER" ] && echo "$Q" | grep -q "\"version\": *\"$VER\""; then open "http://localhost:$p"; exit 0; fi
    echo "Había una versión anterior abierta; la reinicio para que cargue la nueva…"
    kill $(lsof -ti "tcp:$p" 2>/dev/null) 2>/dev/null; sleep 2
  fi
done
EDIT_LAB_ESTUDIO="$EST" exec python3 "$LAB" servir
