/* ---------- Editor visual tipo CapCut (The Edit Lab) ---------- */
S.ed=null;
var ED_DURA={gancho:2.4,palabra:1.0,tachado:2.5,cierre:3.0,titulo:4.5,flotante:5,paso:4,paso_escribe:6,caja:4.5,caja_escribe:6,formula:5,checklist:5,contador:3.5,burbujas:3.5,imagen:6,cta:5,sticker:1.2,curvo:1.5,composicion:2,sonido:0.4};
var ED_NOMBRE={gancho:'Hook',palabra:'Palabra',tachado:'Tachado',cierre:'Cierre',titulo:'Título',flotante:'Flotante',paso:'Paso',paso_escribe:'Paso que se escribe',caja:'Caja',caja_escribe:'Caja que se escribe',formula:'Fórmula',checklist:'Checklist',contador:'Contador',burbujas:'Burbujas',imagen:'Imagen',cta:'Llamado',sticker:'Sticker',curvo:'Texto curvo',composicion:'Composición',sonido:'Sonido',zoom:'Acercamiento',editorial:'Escena animada',clic_tarjeta:'Tarjeta con clic',estrellas:'Estrellas',escribe:'Texto que se escribe',linea_tiempo:'Línea de tiempo animada',finder:'Ventana de archivos',pildoras_clic:'Opciones con clic',cierre_alto:'Cierre grande',gancho_alto:'Hook grande',animacion:'Animación'};
function edNom(k){if(ED_NOMBRE[k])return ED_NOMBRE[k];var t=String(k||'efecto').replace(/_/g,' ');return t.charAt(0).toUpperCase()+t.slice(1);}
function edTextos(o){var out=[];function rec(v,d){if(d>3||v==null)return;if(typeof v==='string'){if(v.trim()&&v.length<140&&!/^(#|\/|http|[a-z_]+\.(png|mp4|mov|gif))/i.test(v))out.push(v);}else if(Array.isArray(v))v.forEach(function(z){rec(z,d+1);});else if(typeof v==='object'){['text','texto','titulo','label','etiqueta','palabra','items','elementos','pasos','opciones'].forEach(function(k){if(k in v)rec(v[k],d+1);});}}rec(o,0);return out;}
var ED_POS={'arriba':[540,330],'arriba izquierda':[230,330],'arriba derecha':[850,330],'izquierda':[170,760],'derecha':[910,760],'abajo':[540,1560],'abajo izquierda':[230,1560],'abajo derecha':[850,1560],'centro':[540,960],'pantalla completa':[540,960]};
var FR=1/30;
function edNorm(s){return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9ñ%]+/g,' ').trim();}
function edClone(x){return JSON.parse(JSON.stringify(x));}
function edPlanOf(r){var p={};try{p=typeof r.planStoryboard==='string'?JSON.parse(r.planStoryboard||'{}'):(r.planStoryboard||{});}catch(e){p={};}p.efectos=p.efectos||[];p.acercamientos=p.acercamientos||[];return p;}
/* cada parte puede ir más rápida (vel) y con zoom: su duración en el Reel es (h-d)/vel */
function edRampaProm(de,a){return Math.abs(a-de)<1e-6?de:(a-de)/Math.log(a/de);}
var ED_RAMPAS=[['2-1','Rápido, frenando a normal'],['1-2','Normal, acelerando']];
function edVelZoomHTML(s){var v=edV1(s),z=s.zoom||'',rk=s.rampa?(s.rampa.de+'-'+s.rampa.a):'';
  return '<div class="ed-f"><span>Velocidad</span>'+[1,1.25,1.5,2].map(function(x){return '<button type="button" class="ed-b'+(!rk&&v===x?' ed-on':'')+'" data-e="vel" data-v="'+x+'">'+(x===1?'Normal':x+'×')+'</button>';}).join('')+'</div>'+
  '<div class="ed-f"><span>Rampa</span>'+ED_RAMPAS.map(function(x){return '<button type="button" class="ed-b'+(rk===x[0]?' ed-on':'')+'" data-e="vel" data-r="'+x[0]+'" title="Un solo movimiento fluido entre dos velocidades. Su sonido va a la velocidad promedio: luce mejor en partes donde no hablas.">'+x[1]+'</button>';}).join('')+'</div>'+
  '<div class="ed-f"><span>Zoom</span>'+[['','Sin zoom'],['in','Acercar'],['out','Alejar']].map(function(x){return '<button type="button" class="ed-b'+(z===x[0]?' ed-on':'')+'" data-e="pzoom" data-v="'+x[0]+'">'+x[1]+'</button>';}).join('')+'</div>';}
function edV1(s){return (s&&+s.vel)||1;}
function edL(s){return Math.max(0,s.h-s.d)/edV1(s);}
function edTotal(){return S.ed.segs.reduce(function(a,s){return a+edL(s);},0);}
/* tiempo del video original → tiempo del Reel (y al revés) */
function edOut(src){var acc=0,sg=S.ed.segs;for(var i=0;i<sg.length;i++){var s=sg[i];if(src>=s.d-0.001&&src<=s.h+0.001)return acc+(src-s.d)/edV1(s);acc+=edL(s);}return null;}
function edSrc(t){var acc=0,sg=S.ed.segs;for(var i=0;i<sg.length;i++){var s=sg[i],d=edL(s);if(t<acc+d||i===sg.length-1)return {i:i,src:s.d+Math.max(0,Math.min(d,t-acc))*edV1(s)};acc+=d;}return {i:0,src:sg.length?sg[0].d:0};}
function edWords(){var r=curReel(),sg=S.ed.segs;return (r&&r.palabras||[]).map(function(w){if(w.s==null)return null;var we=w.e||w.s+0.2,m=(w.s+we)/2,acc=0;
  for(var i=0;i<sg.length;i++){var q=sg[i];if(m>=q.d-0.001&&m<=q.h+0.001){var a=Math.max(w.s,q.d),b=Math.min(we,q.h);if(b-a<0.05)b=a+0.05;return {t:w.t,s:acc+(a-q.d)/edV1(q),e:acc+(b-q.d)/edV1(q),n:edNorm(w.t)};}acc+=edL(q);}return null;}).filter(Boolean).sort(function(a,b){return a.s-b.s;});}
function edBusca(W,txt,vez,despues){var q=edNorm(txt).split(' ')[0];if(!q)return null;var n=0;for(var i=0;i<W.length;i++){if(despues!=null&&W[i].s<despues)continue;if(W[i].n===q||W[i].n.indexOf(q)===0){n++;if(n>=(vez||1))return W[i];}}return null;}
function edResolver(e,W,k){var t0=null,t1=null;
  if(e.t!=null)t0=+e.t;else if(e.en){var w=edBusca(W,e.en,e.vez||1);if(w)t0=w.s;}
  if(t0==null)return null;
  if(e.hasta){var w2=edBusca(W,e.hasta,1,t0+0.1);t1=w2?w2.s-0.1:t0+(e.dura||ED_DURA[k]||2);}else t1=t0+(e.dura||ED_DURA[k]||2);
  return {t0:Math.max(0,t0),t1:Math.max(t0+0.1,t1)};}
function edCortesBase(r){if(r.segmentosEditados&&r.segmentosEditados.length)return edClone(r.segmentosEditados);if(canTrimWords(r))return wordSegs(r);return (r.segmentos||[]).filter(function(s){return s.srcDesde!=null;}).map(function(s){return {d:s.srcDesde,h:s.srcHasta,texto:s.texto||''};});}
function edInit(r){
  var modo=S.edModo||'efectos';
  if(S.ed&&S.ed.reel===r.id&&S.ed.modo===modo)return S.ed;
  var b=modo==='efectos'?r.editorBorrador:null;
  var segs=modo==='cortes'?edCortesBase(r):edClone(b&&b.segs||r.segmentosEditados||[]);
  var plan=modo==='cortes'?{efectos:[],acercamientos:[]}:(b&&b.plan?edClone(b.plan):edPlanOf(r));
  S.ed={reel:r.id,modo:modo,segs:segs,plan:plan,items:[],sel:null,t:0,playing:false,zoom:1,hist:[],fut:[],mounted:false,dirty:!!b,now:-1};
  edArmar();return S.ed;
}
/* ---- modo cortes: editar con la transcripción, como en CapCut ---- */
function edTodas(){var r=curReel();return (r&&r.palabras||[]);}
function edPerdida(w){var e=w.e||w.s,dur=Math.max(0.02,e-w.s),keep=0;S.ed.segs.forEach(function(s){keep+=Math.max(0,Math.min(e,s.h)-Math.max(w.s,s.d));});return Math.max(0,dur-keep);}
function edViva(w){if(!w||w.s==null)return false;var dur=Math.max(0.02,(w.e||w.s)-w.s),lost=edPerdida(w);return dur-lost>=Math.min(0.05,dur*0.5);}
function edMedias(w){if(!edViva(w))return false;return edPerdida(w)>0.04;}
function edOrdenar(){var sg=S.ed.segs;sg.sort(function(a,b){return a.d-b.d;});var out=[];sg.forEach(function(s){var l=out[out.length-1];if(l&&s.d<=l.h+0.04&&(l.vel||1)===(s.vel||1)&&(l.zoom||'')===(s.zoom||'')&&!l.rampa&&!s.rampa){l.h=Math.max(l.h,s.h);if(s.fijo)l.fijo=true;}else{if(l&&s.d<l.h)s.d=l.h;if(s.h>s.d)out.push(s);}});S.ed.segs=out.filter(function(s){return s.h-s.d>0.08;});}
function edPalabra(i){var W=edTodas(),w=W[i];if(!w||w.s==null)return;var E=S.ed;edPush();
  var prev=null,next=null;for(var k=i-1;k>=0;k--)if(W[k].s!=null){prev=W[k];break;}for(var k2=i+1;k2<W.length;k2++)if(W[k2].s!=null){next=W[k2];break;}
  var we=w.e||w.s+0.2;
  if(edViva(w)){var a=Math.max(prev?(prev.e||prev.s):0,w.s-0.03),b=Math.min(next?next.s:1e9,we+0.03);var out=[];
    if((prev&&edViva(prev)&&w.s-(prev.e||prev.s)<0.06)||(next&&edViva(next)&&next.s-we<0.06))toast('Esa palabra va pegada a la de junto: puede sonar un poquito cortada. ⌘Z la regresa.');
    E.segs.forEach(function(s){if(s.h<=a||s.d>=b){out.push(s);return;}if(s.d<a)out.push({d:s.d,h:a,texto:''});if(s.h>b)out.push({d:b,h:s.h,texto:''});});E.segs=out;}
  else{E.segs.push({d:Math.max(prev?(prev.e||prev.s):0,w.s-0.042),h:Math.min(next?next.s:1e9,we+0.06),texto:''});edOrdenar();}
  edOrdenar();E.sel=null;edArmar();edDraw();edGuardarBorrador();}
function edReiniciar(){var r=curReel(),E=S.ed;if(!r||!E)return;edPush();var W=r.palabras||[];var c=W.map(function(x){return !!x.auto;});var guard=r.cortes;r.cortes=c;E.segs=canTrimWords(r)?wordSegs(r):edCortesBase(Object.assign({},r,{segmentosEditados:null}));r.cortes=guard;E.sel=null;edArmar();edDraw();edGuardarBorrador();toast('Volví a los cortes que propuso Claude');}
function edListoCortes(){var r=curReel(),E=S.ed;if(!r||!E)return;edPause();clearTimeout(E.bT);var c=edTodas().map(function(w){return w.s==null?false:!edViva(w);});
  var pw={segmentosEditados:E.segs,cortes:c,notasPartes:edNotasSync()};if(r.estado==='Revisar cortes'){Object.assign(pw,{cancelado:false,listo:true,listoEn:Date.now(),corteAprobado:true,look:cfg('look','editorial'),estado:'En cola',progreso:'',paso:null,porcentaje:null,resultadoId:null,resultadoPartes:null});S.trim=null;edSalir();updReel(r,pw);fire(r,'editar');toast('Listo: Claude agrega todo sobre tus cortes exactos');return;}
  S.trim=null;edSalir();updReel(r,pw);toast('Tus cortes quedaron guardados');}
function edArmar(){var E=S.ed,W=edWords(),it=[],sin=0;
  if(E.modo==='cortes'){var T=edTodas();E.segs.forEach(function(s){s.texto=T.filter(function(w){return w.s!=null&&(w.s+(w.e||w.s))/2>=s.d&&(w.s+(w.e||w.s))/2<=s.h;}).map(function(w){return w.t;}).join(' ');});}
  E.plan.efectos.forEach(function(e,i){if(!e)return;var k=e.kind||'titulo';var rt=e._t0!=null?{t0:e._t0,t1:e._t1}:edResolver(e,W,k);if(!rt){rt={t0:sin*0.5,t1:sin*0.5+1};sin++;}
    if(!e)return;it.push({id:'e'+i,src:'e',i:i,k:k,t0:rt.t0,t1:rt.t1,mano:e._t0!=null,track:k==='sonido'?'snd':'fx',sinUbicar:!edResolver(e,W,k)&&e._t0==null});});
  E.plan.acercamientos.forEach(function(z,i){if(!z)return;var rt=z._t0!=null?{t0:z._t0,t1:z._t1}:edResolver(z,W,'zoom');if(!rt)return;if(z.dura==null&&z._t1==null)rt.t1=rt.t0+1.2;it.push({id:'z'+i,src:'z',i:i,k:'zoom',t0:rt.t0,t1:rt.t1,mano:z._t0!=null,track:'zoom'});});
  E.items=it;E.words=W;}
function edItemObj(x){return x.src==='e'?S.ed.plan.efectos[x.i]:S.ed.plan.acercamientos[x.i];}
function edSnap(){var E=S.ed;return JSON.stringify({segs:E.segs,plan:edPlanConTiempos()});}
function edPush(){var E=S.ed;E.hist.push(edSnap());if(E.hist.length>80)E.hist.shift();E.fut=[];}
function edRestore(snap){var o=JSON.parse(snap);S.ed.segs=o.segs;S.ed.plan=o.plan;S.ed.sel=null;edArmar();edDraw();edGuardarBorrador();}
function edUndo(){var E=S.ed;if(!E.hist.length)return;E.fut.push(edSnap());edRestore(E.hist.pop());}
function edRedo(){var E=S.ed;if(!E.fut.length)return;E.hist.push(edSnap());edRestore(E.fut.pop());}
/* lo que se movió a mano queda con su segundo exacto (_t0/_t1) */
function edPlanConTiempos(){var E=S.ed,p=edClone(E.plan);E.items.forEach(function(x){var o=x.src==='e'?p.efectos[x.i]:p.acercamientos[x.i];if(o&&x.mano){o._t0=+x.t0.toFixed(3);o._t1=+x.t1.toFixed(3);}});return p;}
function edPlanFinal(){var p=edPlanConTiempos();
  function fija(o){if(o._t0==null)return o;o.t=o._t0;o.dura=+(o._t1-o._t0).toFixed(3);delete o._t0;delete o._t1;delete o.en;delete o.hasta;delete o.vez;delete o.escena;return o;}
  p.efectos=p.efectos.filter(Boolean).map(fija);p.acercamientos=p.acercamientos.filter(Boolean).map(fija);return p;}
function edGuardarBorrador(){var r=curReel(),E=S.ed;if(!r||!E)return;if(E.modo!=='cortes'&&E.plJs){clearTimeout(E.plT);E.plT=setTimeout(edPlActualizar,450);}E.dirty=true;clearTimeout(E.bT);
  if(E.modo==='cortes'){E.bT=setTimeout(function(){var c=edTodas().map(function(w){return w.s==null?false:!edViva(w);});var pw={segmentosEditados:E.segs,cortes:c,listo:false,notasPartes:edNotasSync()};if(r.estado==='Revisar cortes')pw.cambiosDesdeCorte=true;Object.assign(r,pw);var ref=reelRef(r);if(ref)ref.update(Object.assign({actualizado:Date.now()},pw)).catch(function(){});var s=$('edSaved');if(s)s.textContent='Cortes guardados';},600);return;}
  E.bT=setTimeout(function(){var ref=reelRef(r);var b={segs:E.segs,plan:edPlanConTiempos(),en:Date.now()};r.editorBorrador=b;var np=edNotasSync();r.notasPartes=np;if(ref)ref.update({editorBorrador:b,notasPartes:np}).catch(function(){});var s=$('edSaved');if(s)s.textContent='Borrador guardado';},700);}
function edFmt(t){t=Math.max(0,t);var m=Math.floor(t/60),s=t-m*60;return m+':'+(s<10?'0':'')+s.toFixed(1);}
function edZoomMax(){var E=S.ed;return Math.max(1,400/(edPPS()/E.zoom));}
function edZoomA(nz,cx){var E=S.ed,sc=$('edScroll');if(!E||!sc)return;var zm=edZoomMax(),zs=$('edZoom');if(zs&&+zs.max!==Math.round(zm))zs.max=Math.round(zm);nz=Math.max(1,Math.min(zm,nz));if(Math.abs(nz-E.zoom)<0.001)return;var P0=edPPS(),r=sc.getBoundingClientRect(),off=cx==null?sc.clientWidth/2:cx-r.left;var tc=(sc.scrollLeft+off)/P0;E.zoom=nz;var z=$('edZoom');if(z)z.value=nz;edZoomLigero();sc.scrollLeft=Math.max(0,tc*edPPS()-off);
  clearTimeout(E._zT);E._zT=setTimeout(function(){var sl=sc.scrollLeft;edDrawTracks();sc.scrollLeft=sl;},160);}
/* mientras haces zoom solo se mueven y estiran los bloques (rápido); al soltar se redibuja todo con detalle */
function edZoomLigero(){var E=S.ed,box=$('edTracks');if(!E||!box)return;var P=edPPS(),tot=edTotal(),Pd=E._Pd||P,k=P/Pd;box.style.width=Math.ceil(tot*P+120)+'px';
  var acc=0,vd=box.querySelectorAll('.ed-vd');E.segs.forEach(function(sg,i){var el=vd[i];if(el){el.style.left=(acc*P)+'px';el.style.width=Math.max(6,edL(sg)*P)+'px';var st=el.firstElementChild;if(st&&st.classList.contains('ed-strip'))st.style.cssText='right:auto;width:'+Math.max(6,edL(sg)*Pd)+'px;transform-origin:0 0;transform:scaleX('+k+')';}acc+=edL(sg);});
  E.items.forEach(function(x){var el=box.querySelector('[data-eid="'+x.id+'"]');if(el){el.style.left=(x.t0*P)+'px';el.style.width=Math.max(6,(x.t1-x.t0)*P)+'px';}});
  var ws=box.querySelectorAll('.ed-w');(E.words||[]).forEach(function(w,i){var el=ws[i];if(el){el.style.left=(w.s*P)+'px';el.style.width=Math.max(3,(w.e-w.s)*P-1)+'px';}});
  var ru=box.querySelector('.ed-ruler');if(ru){var h='',paso=P>60?1:(P>25?2:(P>12?5:10));for(var t=0;t<=tot+0.01;t+=paso)h+='<span class="ed-tick" style="left:'+(t*P)+'px">'+edFmt(t).replace(/\.0$/,'')+'</span>';ru.innerHTML=h;}
  edPlayhead();}
function edV(){var E=S.ed;return $(E&&E.av==='2'?'edVid2':'edVid');}
function edV2(){var E=S.ed;return $(E&&E.av==='2'?'edVid':'edVid2');}
function edCambiar(){var E=S.ed,a=edV(),b=edV2();if(!b)return;b.muted=a.muted;b.style.visibility='visible';a.style.visibility='hidden';E.av=E.av==='2'?'':'2';var pr=b.play();if(pr&&pr.catch)pr.catch(function(){});a.pause();}
function edPrecarga(){var E=S.ed,n=E.segs[E.pi+1],b=edV2();if(!n||!b)return;if(E._pre!==E.pi){E._pre=E.pi;b.pause();b.muted=true;try{b.currentTime=Math.max(0,n.d-0.12);}catch(e){}}}
function edPPS(){var w=(($('edTl')||{}).clientWidth||800)-110;return Math.max(6,w/Math.max(1,edTotal()))*S.ed.zoom;}

function vEditor(){
  var r=curReel();if(!r)return '<p>No hay Reel.</p>';var cortes=(S.edModo==='cortes');
  if(!r.fuenteId||(!cortes&&!(r.segmentosEditados&&r.segmentosEditados.length)))return '<section class="card"><h2>Editor</h2><p>Este Reel todavía no tiene cortes aprobados. Termina la fase de cortes y vuelve aquí.</p><button type="button" class="btn" data-go="editar">Volver</button></section>';
  edInit(r);S.ed.mounted=false;setTimeout(edMontar,0);
  var main=cortes?(r.estado==='Revisar cortes'?'Ahora sí, agrega todo':'Listo, guardar cortes'):'Crear versión nueva';
  return '<div class="ed'+(cortes?' ed-cortes':'')+'" id="ed" tabindex="-1">'+
  '<div class="ed-top"><button type="button" class="ed-b" data-e="salir">← '+esc(r.nombre||'Reel')+'</button><span class="ed-title">'+(cortes?'Tus cortes':'Tu edición')+'</span><span class="ed-sp"></span>'+
   '<button type="button" class="ed-b ed-ic" data-e="undo" title="Deshacer (⌘Z)" aria-label="Deshacer">↶</button><button type="button" class="ed-b ed-ic" data-e="redo" title="Rehacer (⌘⇧Z)" aria-label="Rehacer">↷</button>'+
   '<span class="ed-mut" id="edSaved"></span><button type="button" class="ed-b ed-main" data-e="render">'+main+'</button></div>'+
  '<div class="ed-mid"><div class="ed-insp" id="edInsp"></div>'+
   '<div class="ed-prev"><div class="ed-phone" id="edPhone"><video id="edVid" src="'+blob(r.fuenteId)+'" playsinline preload="auto"></video><video id="edVid2" src="'+blob(r.fuenteId)+'" playsinline preload="auto" muted style="visibility:hidden;position:absolute;inset:0"></video><div class="ed-ov" id="edOv"></div>'+(cortes?'':'<div class="ed-pl" id="edPl" hidden></div><div class="ed-plmsg" id="edPlMsg">Preparando la vista exacta de tu video…</div>')+'</div>'+
   '<div class="ed-ctl"><button type="button" class="ed-b ed-ic" data-e="ini" title="Al inicio" aria-label="Al inicio">⏮</button><button type="button" class="ed-b ed-play" data-e="play" id="edPlay" title="Reproducir (espacio)" aria-label="Reproducir">▶</button><span class="ed-time" id="edTime">0:00.0 / '+edFmt(edTotal())+'</span><button type="button" class="ed-b ed-ic" data-e="sonido" id="edMute" title="Sonido" aria-label="Sonido">🔊</button></div></div>'+
   '<div class="ed-side" id="edPartes"></div></div>'+
  '<div class="ed-tools"><button type="button" class="ed-b" data-e="split" title="Dividir en el cabezal (B)">✂ Dividir</button><button type="button" class="ed-b" data-e="qcut" title="Cortar lo de antes del cabezal (Q)">⇤ Antes</button><button type="button" class="ed-b" data-e="wcut" title="Cortar lo de después del cabezal (W)">Después ⇥</button><button type="button" class="ed-b" data-e="borrar" title="Borrar (Supr)">🗑 Borrar</button>'+
   (cortes?'<button type="button" class="ed-b" data-e="reiniciar">↺ Como lo propuso Claude</button>':'<button type="button" class="ed-b" data-e="addtxt">＋ Texto</button><button type="button" class="ed-b" data-e="addzoom">＋ Acercamiento</button>')+
   '<span class="ed-sp"></span><button type="button" class="ed-b ed-ic" data-e="zout" title="Alejar (−)" aria-label="Alejar">−</button><input type="range" id="edZoom" min="1" max="40" step="0.1" value="'+S.ed.zoom+'" aria-label="Zoom de la línea de tiempo"><button type="button" class="ed-b ed-ic" data-e="zin" title="Acercar (+)" aria-label="Acercar">+</button></div>'+
  '<div class="ed-tl" id="edTl"><div class="ed-lbls"><div class="ed-lbl ed-lr"></div>'+(cortes?'':'<div class="ed-lbl" data-elbl="fx">Textos y efectos</div>')+'<div class="ed-lbl ed-lv">Video</div><div class="ed-lbl">Subtítulos</div>'+(cortes?'':'<div class="ed-lbl" data-elbl="zoom">Acercamientos</div><div class="ed-lbl" data-elbl="snd">Sonidos</div>')+'</div><div class="ed-scroll" id="edScroll"><div class="ed-tracks" id="edTracks"></div></div></div>'+
  '<p class="ed-mut ed-help">'+(cortes?'Toca una palabra para quitarla o regresarla · ':'')+'Espacio: reproducir · B: dividir · Q / W: cortar antes / después del cabezal · Supr: borrar · ⌘Z: deshacer · , . o ← →: un cuadro · arrastra las orillas para recortar (Shift: 10× más lento)</p></div>';
}
function edMontar(){var E=S.ed;if(!E||!$('ed'))return;E.mounted=true;setTimeout(edAltoIni,0);edDraw();var v=$('edVid');
  v.addEventListener('loadedmetadata',function(){edSeek(E.t);if(S.edAuto){S.edAuto=0;setTimeout(edPlay,150);}});if(v.readyState>=1&&S.edAuto){S.edAuto=0;setTimeout(edPlay,150);}
  if(!E.raf){var loop=function(){E.raf=requestAnimationFrame(loop);edTick();};loop();}
  var z=$('edZoom');if(z)z.addEventListener('input',function(){edZoomA(+z.value,null);});
  var scr=$('edScroll');if(scr){var tlz=$('edTl')||scr,zw=0,zx=0,zr=0;function zap(){zr=0;var E2=S.ed;if(!E2||!zw)return;var t=zw;zw=0;edZoomA(t,zx);}
    tlz.addEventListener('wheel',function(e){if(!(e.ctrlKey||e.metaKey))return;e.preventDefault();var E2=S.ed;if(!E2)return;var dy=Math.max(-60,Math.min(60,e.deltaY*(e.deltaMode?16:1)));zw=(zw||E2.zoom)*Math.exp(-dy*0.014);zx=e.clientX;if(!zr)zr=requestAnimationFrame(zap);},{passive:false});
    var gz=1;tlz.addEventListener('gesturestart',function(e){e.preventDefault();gz=S.ed?S.ed.zoom:1;},{passive:false});tlz.addEventListener('gesturechange',function(e){e.preventDefault();if(!S.ed)return;zw=gz*e.scale;zx=e.clientX;if(!zr)zr=requestAnimationFrame(zap);},{passive:false});}
  edMedia();$('ed').focus();if(E.modo!=='cortes')edPlIniciar();}
/* miniaturas del video y forma de onda del audio (se hacen una vez por video, en tu navegador) */
S.edMed={};
function edMedia(){var r=curReel();if(!r||!r.fuenteId)return;var id=r.fuenteId;if(S.edMed[id])return;var M=S.edMed[id]={th:{},paso:1,peaks:null,ps:50};
  var v=document.createElement('video');v.muted=true;v.preload='auto';v.playsInline=true;v.src=blob(id);
  var cv=document.createElement('canvas');cv.width=72;cv.height=128;var cx=cv.getContext('2d');var cola=[],n=0;
  v.addEventListener('loadedmetadata',function(){var dur=v.duration||0;M.paso=Math.max(0.5,dur/360);for(var t=0;t<dur;t+=M.paso)cola.push(+t.toFixed(2));sig();});
  function sig(){if(!cola.length){edDrawTracks();return;}var t=cola.shift();v.currentTime=Math.min(t+0.05,(v.duration||t)-0.05);}
  v.addEventListener('seeked',function(){try{var vw=v.videoWidth||9,vh=v.videoHeight||16;var k=Math.max(72/vw,128/vh);cx.drawImage(v,(72-vw*k)/2,(128-vh*k)/2,vw*k,vh*k);M.th[(+(v.currentTime-0.05).toFixed(2))]=cv.toDataURL('image/jpeg',0.6);}catch(e){}
    n++;if(n%12===0&&S.ed&&S.ed.mounted&&!S.ed.drag)edDrawTracks();sig();});
  v.addEventListener('error',function(){});
  try{fetch(blob(id)).then(function(x){return x.arrayBuffer();}).then(function(buf){var AC=window.AudioContext||window.webkitAudioContext;var ac=new AC();return ac.decodeAudioData(buf).then(function(a){var ch=a.getChannelData(0),per=Math.floor(a.sampleRate/M.ps),N=Math.floor(ch.length/per),pk=new Float32Array(N),mx=0.0001;
    for(var i=0;i<N;i++){var m=0,o=i*per;for(var j=0;j<per;j+=4){var q=Math.abs(ch[o+j]);if(q>m)m=q;}pk[i]=m;if(m>mx)mx=m;}for(var i2=0;i2<N;i2++)pk[i2]=Math.sqrt(pk[i2]/mx);M.peaks=pk;try{ac.close();}catch(e){}if(S.ed&&S.ed.mounted)edDrawTracks();});}).catch(function(){});}catch(e){}}
function edTiras(){var E=S.ed,M=S.edMed[(curReel()||{}).fuenteId];if(!M||!M.peaks)return;document.querySelectorAll('canvas[data-wv]').forEach(function(c){var s=E.segs[+c.dataset.wv];if(!s)return;var w=c.clientWidth,h=c.clientHeight;if(!w)return;var dpr=Math.min(2,window.devicePixelRatio||1);c.width=Math.min(16000,w*dpr);c.height=h*dpr;var g=c.getContext('2d');g.scale(dpr,dpr);g.fillStyle='rgba(183,94,124,.85)';
  var span=s.h-s.d;for(var x=0;x<w;x+=2){var t=s.d+span*x/w;var p=M.peaks[Math.floor(t*M.ps)]||0;var bh=Math.max(1,p*(h-2));g.fillRect(x,(h-bh)/2,1.4,bh);}});}
function edTick(){var E=S.ed;if(!E||!E.mounted)return;if(E.player){var f=E.player.getCurrentFrame();E.t=f/30;var pl=E.player.isPlaying();if(pl!==E.playing){E.playing=pl;var bp=$('edPlay');if(bp)bp.textContent=pl?'❚❚':'▶';}edPlayhead();return;}var v=edV();if(!v)return;
  if(E.playing){var seg=E.segs[E.pi];if(!seg){edPause();return;}
    edPrecarga();var nx=E.segs[E.pi+1];if(nx&&E._pr!==E.pi&&v.currentTime>=seg.h-0.12){E._pr=E.pi;var b0=edV2();if(b0){b0.muted=true;var p0=b0.play();if(p0&&p0.catch)p0.catch(function(){});}}
    if(v.currentTime>=seg.h-0.017||v.ended){E.pi++;var n=E.segs[E.pi];if(!n){edPause();E.t=edTotal();}else{var b=edV2();if(b&&E._pr===E.pi-1&&Math.abs(b.currentTime-n.d)<0.12){edCambiar();v=edV();}else{v.currentTime=n.d;}}}
    var acc=0;for(var k=0;k<E.pi&&k<E.segs.length;k++)acc+=edL(E.segs[k]);var cur=E.segs[E.pi];if(cur){E.t=acc+Math.max(0,v.currentTime-cur.d)/edV1(cur);var rr=edV1(cur);if(cur.rampa){var pq=Math.max(0,Math.min(1,(v.currentTime-cur.d)/Math.max(0.05,cur.h-cur.d)));rr=cur.rampa.de+(cur.rampa.a-cur.rampa.de)*pq;}if(Math.abs(v.playbackRate-rr)>0.01)v.playbackRate=rr;}}
  edPlayhead();edOverlay();if(E.modo==='cortes')edAhora();}
function edAhora(){var E=S.ed,v=edV();if(!v)return;var t=v.currentTime,W=edTodas(),k=-1;for(var i=0;i<W.length;i++){var w=W[i];if(w.s!=null&&t>=w.s&&t<(w.e||w.s+0.2)){k=i;break;}}if(k===E.now)return;var o=document.querySelector('.ed-wd.ed-now');if(o)o.classList.remove('ed-now');E.now=k;var n=k>=0&&document.querySelector('[data-wi="'+k+'"]');if(n){n.classList.add('ed-now');if(E.playing&&!E.noSeguir){var bx=$('edWords');if(bx){var nt=n.offsetTop-bx.offsetTop;if(nt<bx.scrollTop||nt>bx.scrollTop+bx.clientHeight-30)bx.scrollTop=nt-40;}}}}
function edPlayhead(){var E=S.ed,ph=$('edPh');edPartesAct();if(ph)ph.style.transform='translateX('+(E.t*edPPS())+'px)';var tm=$('edTime');if(tm)tm.textContent=edFmt(E.t)+' / '+edFmt(edTotal());
  if(E.playing){var sc=$('edScroll');if(sc){var x=E.t*edPPS();if(x>sc.scrollLeft+sc.clientWidth-60)sc.scrollLeft=x-60;}}}
function edSeek(t){var E=S.ed;if(E&&E.player){E.t=Math.max(0,Math.min(edTotal(),t));E.player.seekTo(Math.round(E.t*30));edPlayhead();return;}var v=edV();E.t=Math.max(0,Math.min(edTotal(),t));var p=edSrc(E.t);E.pi=p.i;E._pre=-1;E._pr=-1;var vb=edV2();if(vb)vb.pause();if(v)try{v.currentTime=p.src;}catch(e){}edPlayhead();edOverlay();}
function edPlay(){var E=S.ed;if(E&&E.player){if(E.t>=edTotal()-0.05)edSeek(0);E.player.play();E.playing=true;var bp=$('edPlay');if(bp)bp.textContent='❚❚';return;}var v=edV();if(E)E.noSeguir=false;E._pre=-1;E._pr=-1;if(!v||!E.segs.length)return;if(E.t>=edTotal()-0.05)edSeek(0);var p=edSrc(E.t);E.pi=p.i;v.currentTime=p.src;E.playing=true;var pr=v.play();if(pr&&pr.catch)pr.catch(function(){});var b=$('edPlay');if(b)b.textContent='❚❚';}
function edPause(){var E=S.ed;if(E&&E.player){try{E.player.pause();}catch(e){}E.playing=false;var bp=$('edPlay');if(bp)bp.textContent='▶';return;}var v=edV();if(v)v.pause();var v2=edV2();if(v2)v2.pause();if(E)E.playing=false;var b=$('edPlay');if(b)b.textContent='▶';}
function edEsc(s){return esc(String(s==null?'':s));}
function edOverlay(){var E=S.ed,ov=$('edOv'),ph=$('edPhone');if(!ov||!ph)return;if(E.player){ov.innerHTML='';return;}var sc=ph.clientWidth/1080,t=E.t,h='';
  var zoom=E.items.some(function(x){return x.k==='zoom'&&t>=x.t0&&t<x.t1;});var pz=edSrc(t),sz=E.segs[pz.i],zs=1;
  if(sz&&(sz.zoom==='in'||sz.zoom==='out')){var fr=Math.max(0,Math.min(1,(pz.src-sz.d)/Math.max(0.01,sz.h-sz.d)));fr=fr*fr*(3-2*fr);zs=sz.zoom==='in'?1+0.15*fr:1.15-0.15*fr;}
  ['edVid','edVid2'].forEach(function(id){var q=$(id);if(q){q.style.transition=zs!==1?'none':'';q.style.transform=zs!==1?'scale('+zs.toFixed(4)+')':(zoom?'scale(1.08)':'');}});
  var tapaSubs=false;
  E.items.forEach(function(x){if(x.track!=='fx'||t<x.t0||t>=x.t1)return;var o=edItemObj(x)||{};var k=x.k;
    if(['gancho','palabra','cierre','tachado','titulo','curvo','caja','caja_escribe','paso','paso_escribe','flotante','cta','formula','sticker','imagen','sonido','zoom','animacion','burbujas','checklist','video','subtitulo'].indexOf(k)<0&&edTextos(o).length){tapaSubs=true;var els=Array.isArray(o.elementos)?o.elementos.filter(function(q){return q&&typeof q==='object'&&(q.texto||q.text);}):[];if(els.length){els.slice(0,10).forEach(function(q,ii){var qx=isFinite(+q.x)&&q.x!=null?+q.x:540,qy=isFinite(+q.y)&&q.y!=null?+q.y:480+ii*110,qt=+(q.tam||q.size||64);h+='<div class="ed-t'+(x.id===E.sel?' ed-on':'')+'" style="left:'+(qx*sc)+'px;top:'+(qy*sc)+'px;font-size:'+(qt*sc)+'px;color:'+edEsc(typeof (q.color||o.color)==='string'?(q.color||o.color):'#fff')+'" data-esel="'+x.id+'">'+edEsc(String(q.texto||q.text)).replace(/\n/g,'<br>')+'</div>';});return;}var tx=edTextos(o).slice(0,6),y0=o.y!=null&&isFinite(+o.y)?+o.y:480;tx.forEach(function(z,ii){h+='<div class="ed-t'+(x.id===E.sel?' ed-on':'')+'" style="left:'+((o.x!=null&&isFinite(+o.x)?+o.x:540)*sc)+'px;top:'+((y0+ii*110)*sc)+'px;font-size:'+(64*sc)+'px;color:'+edEsc(typeof o.color==='string'?o.color:'#fff')+'" data-esel="'+x.id+'">'+edEsc(z).replace(/\n/g,'<br>')+'</div>';});return;}
    if(['gancho','palabra','cierre','tachado','titulo','curvo','caja','caja_escribe','paso','paso_escribe','flotante','cta','formula'].indexOf(k)>=0){
      if(k!=='tachado')tapaSubs=true;
      var y=o.y!=null?o.y:(k==='cierre'?330:(k==='flotante'?(o.y||400):360));var x0=o.x!=null?o.x:540;
      var big=(k==='gancho'||k==='palabra'||k==='cierre')?(k==='palabra'?120:92):60;
      var caja=(k==='caja'||k==='caja_escribe'||k==='paso'||k==='paso_escribe'||k==='cta'||k==='formula');
      var curvo=k==='curvo'?' ed-curvo':'';
      h+='<div class="ed-t'+(caja?' ed-caja':'')+curvo+(x.id===E.sel?' ed-on':'')+(k==='tachado'?' ed-tach':'')+'" style="left:'+(x0*sc)+'px;top:'+(y*sc)+'px;font-size:'+(big*sc)+'px;color:'+edEsc(o.color||'#fff')+'" data-esel="'+x.id+'">'+edEsc(o.text||'').replace(/\n/g,'<br>')+'</div>';}
    else if(k==='sticker'||k==='imagen'){var pz=ED_POS[o.posicion||'abajo derecha']||[850,1560];var px=o.x!=null?o.x:pz[0],py=o.y!=null?o.y:pz[1];var tam=(o.tam||300)*sc;
      h+='<div class="ed-stk'+(x.id===E.sel?' ed-on':'')+'" style="left:'+(px*sc)+'px;top:'+(py*sc)+'px;width:'+tam+'px;height:'+tam+'px;transform:translate(-50%,-50%) rotate('+(o.rot||0)+'deg)" data-esel="'+x.id+'">'+edEsc(o.efecto||o.image||'sticker')+'</div>';}
    else{tapaSubs=tapaSubs||!!o.oculta_subs;h+='<div class="ed-comp'+(x.id===E.sel?' ed-on':'')+'" data-esel="'+x.id+'">✦ '+edEsc(edNom(k))+(o.text?'<br><small>'+edEsc(String(o.text).slice(0,40))+'</small>':(edTextos(o).length?'<br><small>'+edEsc(edTextos(o).slice(0,3).join(' · ').slice(0,60))+'</small>':''))+'</div>';}
  });
  if(!tapaSubs){var w=null;for(var i=0;i<E.words.length;i++){var ww=E.words[i];if(t>=ww.s&&t<ww.e+0.08){w=ww;break;}}
    if(w)h+='<div class="ed-sub" style="left:'+(0.78*1080*sc)+'px;top:'+(0.62*1920*sc)+'px;font-size:'+(52*sc)+'px">'+edEsc(w.t)+'</div>';}
  ov.innerHTML=h;}
function edDraw(){edDrawTracks();edInsp();edOverlay();edPartes();}
/* ---- panel "Por parte": transcripción de cada corte, notas y lo que aparece (de sus archivos) ---- */
function edNP(){var r=curReel();if(!r)return [];if(!r.notasPartes)r.notasPartes=[];return r.notasPartes;}
function edNotaDe(s,crear){if(!s)return null;var L=edNP();var n=L.find(function(x){return x.t>=s.d-0.001&&x.t<=s.h+0.001;});
  if(!n&&crear){n={id:'n'+Date.now().toString(36)+Math.floor(Math.random()*999),t:+((s.d+s.h)/2).toFixed(3),nota:'',media:[]};L.push(n);}return n||null;}
function edTextoParte(s){return edTodas().filter(function(w){if(w.s==null)return false;var m=(w.s+(w.e||w.s))/2;return m>=s.d&&m<=s.h;}).map(function(w){return w.t;}).join(' ')||s.texto||'';}
function edNotasSync(){var E=S.ed,out=[];if(!E)return edNP();var acc=0;
  E.segs.forEach(function(s){var n=edNotaDe(s,false);var len=edL(s);if(n&&(n.nota||(n.media&&n.media.length))){n.desde=+acc.toFixed(2);n.hasta=+(acc+len).toFixed(2);n.texto=edTextoParte(s);out.push(n);}acc+=len;});
  return out;}
function edGuardarNotas(){var r=curReel();if(!r)return;clearTimeout(S.ed._nT);S.ed._nT=setTimeout(function(){var np=edNotasSync();r.notasPartes=edNP().filter(function(n){return n.nota||(n.media&&n.media.length);});var ref=reelRef(r);if(ref)ref.update({notasPartes:np}).catch(function(){});var sv=$('edSaved');if(sv)sv.textContent='Notas guardadas';},600);}
function edUrlMedia(r){return '/api/brand/archivo?r='+encodeURIComponent(r);}
function edMiniMedia(m,cls){var rel=String(m.ruta||'').replace(/^Brand Assets\//,'');return m.tipo==='video'?'<video class="'+cls+'" src="'+edUrlMedia(rel)+'#t=0.1" muted preload="metadata"></video>':'<img class="'+cls+'" loading="lazy" src="'+edUrlMedia(rel)+'" alt="'+edEsc(m.nombre||'')+'">';}
function edPartes(){var E=S.ed,box=$('edPartes');if(!box||!E)return;var acc=0,h='<div class="ed-ph2"><h3>Por parte del video</h3><p class="ed-mut">Escribe qué quieres en cada parte y elige de tus archivos lo que debe aparecer.</p></div>';
  E.segs.forEach(function(s,i){var len=edL(s),n=edNotaDe(s,false),t=edTextoParte(s);
    h+='<div class="ed-pt" data-pi="'+i+'"><button type="button" class="ed-pth" data-e="irparte" data-i="'+i+'"><b>Parte '+(i+1)+'</b><span>'+edFmt(acc)+' – '+edFmt(acc+len)+'</span></button>'+
      '<p class="ed-ptx">'+(t?edEsc(t):'<i>(sin palabras)</i>')+'</p>'+
      '<textarea class="ed-nota" data-np="'+i+'" rows="2" placeholder="Nota para esta parte: por ejemplo, aquí quiero que aparezca esta foto mientras lo digo">'+edEsc(n?n.nota:'')+'</textarea>'+
      '<div class="ed-mrow">'+((n&&n.media||[]).map(function(m,k){return '<span class="ed-mchip" title="'+edEsc(m.nombre||'')+'">'+edMiniMedia(m,'ed-mth')+'<button type="button" class="ed-mx" data-e="mquitar" data-i="'+i+'" data-k="'+k+'" aria-label="Quitar">×</button></span>';}).join(''))+
      '<button type="button" class="ed-b ed-madd" data-e="mabrir" data-i="'+i+'">＋ De mis archivos</button></div></div>';acc+=len;});
  if(!E.segs.length)h+='<p class="ed-mut">Todavía no hay partes.</p>';
  var _st=box.scrollTop;box.innerHTML=h;box.scrollTop=_st;edPartesAct();}
function edPartesAct(){var E=S.ed;if(!E)return;var a=document.querySelector('.ed-pt.ed-pact');var i=E.pi==null?-1:E.pi;if(a&&+a.dataset.pi===i)return;if(a)a.classList.remove('ed-pact');var n=document.querySelector('.ed-pt[data-pi="'+i+'"]');if(n){n.classList.add('ed-pact');if(E.playing&&!E.noSeguir){var bx=$('edPartes');if(bx){var nt=n.offsetTop-bx.offsetTop;if(nt<bx.scrollTop||nt>bx.scrollTop+bx.clientHeight-80)bx.scrollTop=Math.max(0,nt-8);}}}}
function edPickAbrir(i){var E=S.ed;E.pick={i:i,tab:null,grupos:null};var m=$('edPick');if(m)m.remove();var d=document.createElement('div');d.id='edPick';d.className='ed-pick';$('ed').appendChild(d);edPickDibujar();
  fetch('/api/brand/lista').then(function(x){return x.json();}).then(function(j){if(!S.ed||!S.ed.pick)return;S.ed.pick.grupos=j.grupos||[];var g=S.ed.pick.grupos.find(function(q){return q.archivos.length;});S.ed.pick.tab=g?g.id:(S.ed.pick.grupos[0]||{}).id;edPickDibujar();}).catch(function(){if(S.ed&&S.ed.pick){S.ed.pick.grupos=[];edPickDibujar();}});}
function edPickDibujar(){var E=S.ed,pk=E&&E.pick,box=$('edPick');if(!pk||!box)return;var n=edNotaDe(E.segs[pk.i],false),sel=(n&&n.media||[]).map(function(m){return m.ruta;});
  var h='<div class="ed-pbox" role="dialog" aria-label="Elegir de tus archivos"><div class="ed-ptop"><h3>¿Qué aparece en la parte '+(pk.i+1)+'?</h3><button type="button" class="ed-b ed-main" data-e="mcerrar">Listo</button></div>';
  if(!pk.grupos)h+='<p class="ed-mut">Buscando tus archivos…</p>';
  else if(!pk.grupos.length)h+='<p class="ed-mut">No encontré tu carpeta Brand Assets. Revisa que esté dentro de The Edit Lab.</p>';
  else{h+='<div class="ed-ptabs">'+pk.grupos.map(function(g){return '<button type="button" class="ed-b'+(g.id===pk.tab?' ed-on':'')+'" data-e="mtab" data-g="'+g.id+'">'+edEsc(g.nombre)+' <span class="ed-pill">'+g.archivos.length+'</span></button>';}).join('')+'</div>';
    var g=pk.grupos.find(function(q){return q.id===pk.tab;});
    if(!g||!g.archivos.length)h+='<p class="ed-mut">'+(g?'Tu carpeta “'+edEsc(g.carpeta)+'” está vacía. Pon tus archivos ahí y vuelve a abrir esta ventana.':'')+'</p>';
    else h+='<div class="ed-pgrid">'+g.archivos.map(function(a){var ruta='Brand Assets/'+a.r;var on=sel.indexOf(ruta)>=0;return '<button type="button" class="ed-pi'+(on?' ed-on':'')+'" data-e="mpick" data-r="'+edEsc(a.r)+'" title="'+edEsc(a.n)+'">'+edMiniMedia({ruta:ruta,tipo:a.v?'video':'imagen',nombre:a.n},'ed-pimg')+'<span>'+edEsc(a.n)+'</span>'+(on?'<i class="ed-ck">✓</i>':'')+'</button>';}).join('')+'</div>';}
  box.innerHTML=h+'</div>';}
function edPickAlternar(rel){var E=S.ed,pk=E.pick;if(!pk)return;var s=E.segs[pk.i],n=edNotaDe(s,true),ruta='Brand Assets/'+rel;var k=n.media.findIndex(function(m){return m.ruta===ruta;});
  if(k>=0)n.media.splice(k,1);else{var g=pk.grupos.find(function(q){return q.archivos.some(function(a){return a.r===rel;});}),a=g&&g.archivos.find(function(q){return q.r===rel;});n.media.push({ruta:ruta,nombre:a?a.n:rel.split('/').pop(),tipo:a&&a.v?'video':'imagen',grupo:g?g.id:''});}
  edGuardarNotas();edPickDibujar();edPartes();}
document.addEventListener('input',function(e){var t=e.target;if(!S.ed||!S.ed.mounted||!t.dataset||t.dataset.np==null)return;var s=S.ed.segs[+t.dataset.np];if(!s)return;var n=edNotaDe(s,true);n.nota=t.value;edGuardarNotas();});
function edDrawTracks(){var E=S.ed,box=$('edTracks');if(!box)return;var P=edPPS();E._Pd=P;var tot=edTotal(),W=Math.ceil(tot*P+120);
  var ruler='';var paso=P>60?1:(P>25?2:(P>12?5:10));for(var s=0;s<=tot+0.01;s+=paso)ruler+='<span class="ed-tick" style="left:'+(s*P)+'px">'+edFmt(s).replace(/\.0$/,'')+'</span>';
  var lanes={};function lane(tr,x){var L=lanes[tr]||(lanes[tr]=[]);for(var i=0;i<L.length;i++){if(L[i]<=x.t0+0.001){L[i]=x.t1;return i;}}L.push(x.t1);return L.length-1;}
  function blk(x,cls,label){var w=Math.max(6,(x.t1-x.t0)*P);var ln=lane(x.track,x);return '<div class="ed-blk '+cls+(E.sel===x.id?' ed-on':'')+(x.sinUbicar?' ed-warn':'')+'" data-eid="'+x.id+'" style="left:'+(x.t0*P)+'px;width:'+w+'px;top:'+(5+ln*34)+'px" title="'+edEsc(label)+'"><span class="ed-h L" data-eh="L"></span><span class="ed-bt">'+edEsc(label)+'</span><span class="ed-h R" data-eh="R"></span></div>';}
  var fx='',zm='',sd='';E.items.slice().sort(function(a,b){return a.t0-b.t0;}).forEach(function(x){var o=edItemObj(x)||{};var lab=edNom(x.k)+(function(){var tx=o.text?[String(o.text)]:edTextos(o);return tx.length?' · '+tx.slice(0,3).join(' / ').replace(/\n/g,' '):(o.efecto?' · '+o.efecto:(o.sonido&&x.k==='sonido'?' · '+o.sonido:''));})();
    if(x.track==='fx')fx+=blk(x,'ed-fx',lab);else if(x.track==='zoom')zm+=blk(x,'ed-zm','Acercamiento');else sd+=blk(x,'ed-sd',lab);});
  var M=S.edMed[(curReel()||{}).fuenteId]||{th:{},paso:1};var TW=34;
  var acc=0,vid=E.segs.map(function(s,i){var w=Math.max(6,edL(s)*P);var vv=edV1(s);var tira='';var cada=Math.max(M.paso,TW/P);var keys=Object.keys(M.th);
    if(keys.length){for(var x=0;x<w;x+=TW){var ts=s.d+x/P*vv;var kk=Math.round(ts/M.paso)*M.paso;var u=M.th[+kk.toFixed(2)];if(!u){var best=null,bd=1e9;for(var q=0;q<keys.length;q++){var dd=Math.abs(+keys[q]-ts);if(dd<bd){bd=dd;best=keys[q];}}u=bd<cada*2?M.th[best]:null;}if(u)tira+='<i style="left:'+x+'px;background-image:url('+u+')"></i>';}}
    var h='<div class="ed-blk ed-vd'+(E.sel==='s'+i?' ed-on':'')+'" data-eid="s'+i+'" style="left:'+(acc*P)+'px;width:'+w+'px" title="'+edEsc(s.texto||'')+'"><span class="ed-strip">'+tira+'</span><canvas class="ed-wv" data-wv="'+i+'"></canvas><span class="ed-h L" data-eh="L"></span><span class="ed-bt">'+edEsc((s.texto||'').split(' ').slice(0,6).join(' '))+'</span><span class="ed-dur">'+(s.rampa?s.rampa.de+'→'+s.rampa.a+'× · ':vv!==1?vv+'× · ':'')+(s.zoom==='in'?'🔍+ ':s.zoom==='out'?'🔍− ':'')+edL(s).toFixed(1)+'s</span><span class="ed-h R" data-eh="R"></span></div>';acc+=edL(s);return h;}).join('');
  var subs=E.words.map(function(w){return '<span class="ed-w" style="left:'+(w.s*P)+'px;width:'+Math.max(3,(w.e-w.s)*P-1)+'px" title="'+edEsc(w.t)+'">'+(P*(w.e-w.s)>26?edEsc(w.t):'')+'</span>';}).join('');
  box.style.width=W+'px';
  function hh(tr){return 'style="height:'+(40+Math.max(0,((lanes[tr]||[]).length-1))*34)+'px"';}
  var cortes=E.modo==='cortes';
  box.innerHTML='<div class="ed-ruler" data-eruler="1">'+ruler+'</div>'+(cortes?'':'<div class="ed-row" data-erow="fx" '+hh('fx')+'>'+fx+'</div>')+'<div class="ed-row ed-rv" data-erow="vid">'+vid+'</div><div class="ed-row ed-subs">'+subs+'</div>'+(cortes?'':'<div class="ed-row" data-erow="zoom" '+hh('zoom')+'>'+zm+'</div><div class="ed-row" data-erow="snd" '+hh('snd')+'>'+sd+'</div>')+'<div class="ed-ph" id="edPh"><i></i></div>';
  edTiras();
  ['fx','zoom','snd'].forEach(function(tr){var l=document.querySelector('[data-elbl="'+tr+'"]');if(l)l.style.height=(40+Math.max(0,((lanes[tr]||[]).length-1))*34)+'px';});
  edPlayhead();}
function edSelItem(){var E=S.ed;return E.items.find(function(x){return x.id===E.sel;})||null;}
function edInsp(){var E=S.ed,box=$('edInsp');if(!box)return;var h='';
  if(E.modo==='cortes'){var top='';if(E.sel&&E.sel[0]==='s'){var si=+E.sel.slice(1),sg=E.segs[si];if(sg)top='<div class="ed-selbox"><h3>Parte '+(si+1)+' · '+edL(sg).toFixed(1)+' s</h3><div class="ed-f"><span>Inicio</span><button type="button" class="ed-b" data-e="nudge" data-l="L" data-v="-'+FR+'">−1 cuadro</button><button type="button" class="ed-b" data-e="nudge" data-l="L" data-v="'+FR+'">+1 cuadro</button></div><div class="ed-f"><span>Final</span><button type="button" class="ed-b" data-e="nudge" data-l="R" data-v="-'+FR+'">−1 cuadro</button><button type="button" class="ed-b" data-e="nudge" data-l="R" data-v="'+FR+'">+1 cuadro</button></div>'+edVelZoomHTML(sg)+'<button type="button" class="ed-b ed-del" data-e="borrar">Quitar esta parte</button></div>';}
    var W=edTodas(),nf=0;var ws=W.map(function(w,i){if(w.s==null)return '';var viva=edViva(w);if(!viva)nf++;return '<button type="button" class="ed-wd'+(viva?'':' ed-fuera')+(viva&&edMedias(w)?' ed-medias':'')+(i===E.now?' ed-now':'')+'" data-e="word" data-wi="'+i+'" title="Toca para quitar, resaltar o dejar una nota">'+(edResDe().indexOf(i)>=0?'<u class="ed-res">'+edEsc(w.t)+'</u>':edEsc(w.t))+(edNotaW()[i]?'<sup class="ed-wnota" title="'+edEsc(edNotaW()[i])+'">●</sup>':'')+'</button>';}).join('');
    var _ow=$('edWords'),_sw=_ow?_ow.scrollTop:0,_sb=box.scrollTop;
    box.innerHTML=top+'<div class="ed-trh"><h3>Tu transcripción</h3><span class="ed-pill">'+nf+' fuera</span></div><p class="ed-mut">Toca una palabra para quitarla. Las tachadas no salen; tócalas para regresarlas. Las amarillas quedaron cortadas a medias.</p><div class="ed-words" id="edWords">'+ws+'</div>';var _nw=$('edWords');if(_nw)_nw.scrollTop=_sw;box.scrollTop=_sb;return;}
  if(E.sel&&E.sel[0]==='s'){var i=+E.sel.slice(1),s=E.segs[i];if(s)h='<h3>Parte '+(i+1)+' del video</h3><p class="ed-mut">“'+edEsc((s.texto||'').slice(0,90))+'”</p><div class="ed-f"><span>Inicio</span><button type="button" class="ed-b" data-e="nudge" data-l="L" data-v="-'+FR+'">−1 cuadro</button><button type="button" class="ed-b" data-e="nudge" data-l="L" data-v="'+FR+'">+1 cuadro</button></div><div class="ed-f"><span>Final</span><button type="button" class="ed-b" data-e="nudge" data-l="R" data-v="-'+FR+'">−1 cuadro</button><button type="button" class="ed-b" data-e="nudge" data-l="R" data-v="'+FR+'">+1 cuadro</button></div><p class="ed-mut">Dura '+edL(s).toFixed(2)+' s. Arrastra sus bordes en la línea de tiempo para recortar.</p>'+edVelZoomHTML(s)+'<button type="button" class="ed-b ed-del" data-e="borrar">Quitar esta parte</button>';}
  else{var x=edSelItem();if(x){var o=edItemObj(x)||{};
    h='<h3>'+edEsc(edNom(x.k))+'</h3>'+(x.sinUbicar?'<p class="ed-warnt">No encontré dónde iba: acomódalo en la línea de tiempo.</p>':'')+
    ('text' in o||x.k==='palabra'||x.k==='gancho'?'<label class="ed-f ed-col"><span>Texto</span><textarea id="edTxt" rows="3">'+edEsc(o.text||'')+'</textarea></label>':'')+
    '<div class="ed-f"><span>Empieza</span><input type="number" id="edT0" step="0.05" min="0" value="'+x.t0.toFixed(2)+'"> s</div><div class="ed-f"><span>Dura</span><input type="number" id="edDur" step="0.05" min="0.1" value="'+(x.t1-x.t0).toFixed(2)+'"> s</div>'+
    edForma(o)+(('detras' in o)||x.k==='palabra'||x.k==='gancho'?'<label class="ed-f"><input type="checkbox" id="edDetras"'+(o.detras?' checked':'')+'> <span>Detrás de mi cabeza</span></label>':'')+
    (x.k==='sticker'?'<label class="ed-f ed-col"><span>Lugar</span><select id="edPos">'+Object.keys(ED_POS).map(function(p){return '<option'+((o.posicion||'abajo derecha')===p?' selected':'')+'>'+p+'</option>';}).join('')+'</select></label>':'')+
    '<div class="ed-f"><button type="button" class="ed-b" data-e="dup">Duplicar</button><button type="button" class="ed-b ed-del" data-e="borrar">Borrar</button></div>';}
  else h='<h3>Editor</h3><p class="ed-mut">Toca un bloque de la línea de tiempo para editarlo, o un texto en la vista previa.</p><p class="ed-mut">Lo que muevas aquí se respeta exacto en tu versión nueva. Tus cambios se guardan solos como borrador.</p>';}
  box.innerHTML=h;}
function edMover(x,dt,lado,base){var tot=edTotal();if(lado==='L'){x.t0=Math.max(0,Math.min(base.t1-0.1,base.t0+dt));}else if(lado==='R'){x.t1=Math.min(tot,Math.max(base.t0+0.1,base.t1+dt));}else{var d=base.t1-base.t0;x.t0=Math.max(0,Math.min(tot-d,base.t0+dt));x.t1=x.t0+d;}x.mano=true;}
/* al cortar, lo que pusiste a mano (textos, subtítulos, zooms, sonidos) se recorre con el video, como en CapCut */
function edAnclas(){var E=S.ed;return (E.items||[]).filter(function(x){return x.mano;}).map(function(x){return {src:x.src,i:x.i,sa:edSrc(x.t0).src,dur:x.t1-x.t0};});}
function edReubicar(anc){var E=S.ed;if(!anc||!anc.length)return;var total=edTotal();
  anc.forEach(function(a){var o=a.src==='e'?E.plan.efectos[a.i]:E.plan.acercamientos[a.i];if(!o)return;
    var t=edOut(a.sa);if(t==null){var acc=0,hallado=false;for(var k=0;k<E.segs.length;k++){var sg=E.segs[k];if(sg.d>=a.sa-0.001){t=acc;hallado=true;break;}acc+=edL(sg);}if(!hallado)t=Math.max(0,total-a.dur);}
    t=Math.max(0,Math.min(t,Math.max(0,total-a.dur)));o._t0=+t.toFixed(3);o._t1=+(t+a.dur).toFixed(3);var it=(E.items||[]).find(function(x){return x.src===a.src&&x.i===a.i;});if(it){it.t0=o._t0;it.t1=o._t1;}});}
function edDelSel(){var E=S.ed;if(!E.sel)return;edPush();
  if(E.sel[0]==='s'){if(E.segs.length<2){toast('El Reel necesita al menos una parte');E.hist.pop();return;}var anc=edAnclas();E.segs.splice(+E.sel.slice(1),1);edReubicar(anc);}
  else{var x=edSelItem();if(x){if(x.src==='e')E.plan.efectos[x.i]=null;else E.plan.acercamientos[x.i]=null;E.plan.efectos=E.plan.efectos;}}
  E.sel=null;edCompactar();edArmar();edDraw();edGuardarBorrador();}
function edCompactar(){var E=S.ed;var p=edPlanConTiempos();p.efectos=p.efectos.filter(Boolean);p.acercamientos=p.acercamientos.filter(Boolean);E.plan=p;}
/* Q / W: corta lo que hay antes / después del cabezal dentro de la parte donde está */
function edCortaCabezal(lado){var E=S.ed;var p=edSrc(E.t);var s=E.segs[p.i];if(!s||p.src-s.d<0.034||s.h-p.src<0.034){toast('Pon el cabezal dentro de una parte del video');return;}
  edPush();var anc=edAnclas();var acc=E.segs.slice(0,p.i).reduce(function(q,z){return q+edL(z);},0);if(lado==='L'){s.d=p.src;}else{s.h=p.src;}s.fijo=true;E.sel='s'+p.i;
  edReubicar(anc);edArmar();edDraw();edSeek(lado==='L'?acc:acc+edL(s));edGuardarBorrador();}
function edSplit(){var E=S.ed;var p=edSrc(E.t);var s=E.segs[p.i];if(!s||p.src-s.d<0.1||s.h-p.src<0.1){toast('Pon el cabezal dentro de una parte del video');return;}edPush();var nb={d:p.src,h:s.h,texto:'',fijo:true};s.fijo=true;var ws=(s.texto||'');s.h=p.src;E.segs.splice(p.i+1,0,nb);nb.texto=ws;E.sel='s'+(p.i+1);edCompactar();edArmar();edDraw();edGuardarBorrador();}
function edAdd(kind){var E=S.ed;edPush();var t=E.t;if(kind==='zoom'){E.plan.acercamientos.push({_t0:t,_t1:t+1.2});}else{E.plan.efectos.push({kind:'palabra',text:'TU TEXTO',detras:false,_t0:t,_t1:t+1.2,oculta_subs:true});}
  edArmar();var last=E.items.filter(function(x){return kind==='zoom'?x.k==='zoom':x.track==='fx';}).pop();if(last){last.mano=true;E.sel=last.id;}edDraw();edGuardarBorrador();var ta=$('edTxt');if(ta){ta.focus();ta.select();}}
function edDup(){var E=S.ed,x=edSelItem();if(!x)return;edPush();var o=edClone(edItemObj(x));var d=x.t1-x.t0;o._t0=Math.min(edTotal()-d,x.t1);o._t1=o._t0+d;if(x.src==='e')E.plan.efectos.push(o);else E.plan.acercamientos.push(o);edArmar();edDraw();edGuardarBorrador();}
function edRender(){var r=curReel(),E=S.ed;if(!r||!E)return;edPause();var plan=edPlanFinal();
  updReel(r,{planStoryboard:JSON.stringify(plan,null,1),segmentosEditados:E.segs,notasPartes:edNotasSync(),editadoEnEditor:true,editorBorrador:null,corteAprobado:true,cancelado:false,listo:true,listoEn:Date.now(),look:cfg('look','editorial'),estado:'En cola',progreso:'',paso:null,porcentaje:null,resultadoId:null,resultadoPartes:null});
  fire(r,'editar');edSalir();toast('Listo: Claude hace tu versión nueva con tus cambios exactos');}
function edSalir(){var E=S.ed;if(E){if(E.raf)cancelAnimationFrame(E.raf);E.raf=null;E.mounted=false;}edPause();S.ed=null;S.edModo=null;S.trim=null;S.view='editar';render();}
/* clics */
document.addEventListener('click',function(e){if(!S.ed||!S.ed.mounted)return;var b=e.target.closest('[data-e]');if(!b)return;var a=b.dataset.e,E=S.ed;
  if(a==='salir')return edSalir();if(a==='play')return E.playing?edPause():edPlay();if(a==='ini')return edSeek(0);
  if(a==='sonido'){if(E.player){E.muted=!E.muted;E.muted?E.player.mute():E.player.unmute();b.textContent=E.muted?'🔇':'🔊';return;}var v=edV();v.muted=!v.muted;b.textContent=v.muted?'🔇':'🔊';return;}
  if(a==='undo')return edUndo();if(a==='redo')return edRedo();if(a==='split')return edSplit();if(a==='borrar')return edDelSel();
  if(a==='vel'||a==='pzoom'){var si=E.sel&&E.sel[0]==='s'?+E.sel.slice(1):edSrc(E.t).i;var sv=E.segs[si];if(!sv)return;edPush();var anc=edAnclas();
    if(a==='vel'){if(b.dataset.r){var rp=b.dataset.r.split('-').map(Number);sv.rampa={de:rp[0],a:rp[1]};sv.vel=+edRampaProm(rp[0],rp[1]).toFixed(4);}else{delete sv.rampa;var nv=+b.dataset.v;if(nv===1)delete sv.vel;else sv.vel=nv;}}else{if(b.dataset.v)sv.zoom=b.dataset.v;else delete sv.zoom;}
    E.sel='s'+si;edReubicar(anc);edArmar();edDraw();edGuardarBorrador();return;}
  if(a==='qcut')return edCortaCabezal('L');if(a==='wcut')return edCortaCabezal('R');
  if(a==='word')return edWMenu(+b.dataset.wi,b);if(a==='wq'){var wi=S.ed.wm;edWCerrar();return edPalabra(wi);}if(a==='wh')return edWRes(S.ed.wm);if(a==='wn')return edWNota(S.ed.wm,b.dataset.t);if(a==='wnx')return edWNota(S.ed.wm,null);if(a==='wcerrar')return edWCerrar();if(a==='reiniciar')return edReiniciar();
  if(a==='addtxt')return edAdd('txt');if(a==='addzoom')return edAdd('zoom');if(a==='dup')return edDup();
  if(a==='zin'||a==='zout'){return edZoomA(E.zoom*(a==='zin'?1.4:1/1.4),null);}
  if(a==='nudge'){var s=E.segs[+E.sel.slice(1)];if(!s)return;edPush();var dv=+b.dataset.v;var anc=edAnclas();if(b.dataset.l==='L')s.d=Math.max(0,Math.min(s.h-0.1,s.d+dv));else s.h=Math.max(s.d+0.1,s.h+dv);s.fijo=true;edReubicar(anc);edArmar();edDraw();edGuardarBorrador();return;}
  if(a==='irparte'){edPause();var acc=0;for(var q=0;q<+b.dataset.i;q++)acc+=E.segs[q].h-E.segs[q].d;edSeek(acc+0.01);E.sel='s'+b.dataset.i;edInsp();edDrawTracks();return;}
  if(a==='mabrir')return edPickAbrir(+b.dataset.i);
  if(a==='mquitar'){var nq=edNotaDe(E.segs[+b.dataset.i],false);if(nq){nq.media.splice(+b.dataset.k,1);edGuardarNotas();edPartes();}return;}
  if(a==='mcerrar'){var pk=$('edPick');if(pk)pk.remove();E.pick=null;return;}
  if(a==='mtab'){E.pick.tab=b.dataset.g;edPickDibujar();return;}
  if(a==='mpick')return edPickAlternar(b.dataset.r);
  if(a==='render'){if(E.modo==='cortes')return edListoCortes();if(confirmar(b))edRender();return;}
});
function confirmar(b){if(b.dataset.ok){return true;}b.dataset.ok='1';var t=b.textContent;b.textContent='¿Crear versión nueva? Toca otra vez';setTimeout(function(){if(b){delete b.dataset.ok;b.textContent=t;}},3500);return false;}
/* seleccionar desde la vista previa */
document.addEventListener('pointerdown',function(e){if(!S.ed||!S.ed.mounted)return;var t=e.target.closest&&e.target.closest('[data-esel]');if(t){S.ed.sel=t.dataset.esel;edInsp();edDrawTracks();edOverlay();}});
/* arrastrar bloques, bordes y cabezal */
(function(){var drag=null;
  document.addEventListener('pointerdown',function(e){var E=S.ed;if(!E||!E.mounted)return;
    if(e.target.closest&&e.target.closest('[data-eruler],.ed-ph')){e.preventDefault();var tr=$('edTracks').getBoundingClientRect();drag={ph:true,x0:tr.left};edPause();edSeek((e.clientX-tr.left)/edPPS());return;}
    var blk=e.target.closest&&e.target.closest('[data-eid]');
    if(!blk){var row=e.target.closest&&e.target.closest('.ed-row');if(row){var tr2=$('edTracks').getBoundingClientRect();edPause();edSeek((e.clientX-tr2.left)/edPPS());E.sel=null;edInsp();edDrawTracks();}return;}
    e.preventDefault();var id=blk.dataset.eid,h=e.target.closest('[data-eh]');var lado=h?h.dataset.eh:'M';E.sel=id;
    edPush();
    if(id[0]==='s'){var i=+id.slice(1),s=E.segs[i];if(lado==='M'){E.hist.pop();edInsp();edDrawTracks();return;}var pv=E.segs[i-1],nx=E.segs[i+1];drag={seg:i,lado:lado,x:e.clientX,lx:e.clientX,dx:0,lo:Math.max(pv?pv.h:0,s.d-4),hi:Math.min(nx?nx.d:1e9,s.h+4),d:s.d,h:s.h,p:edPPS(),anc:edAnclas(),acc:E.segs.slice(0,i).reduce(function(q,z){return q+edL(z);},0),vel:edV1(s)};}
    else{var x=E.items.find(function(y){return y.id===id;});drag={it:x,lado:lado,x:e.clientX,base:{t0:x.t0,t1:x.t1},p:edPPS(),moved:false};}
    E.drag=true;try{blk.setPointerCapture(e.pointerId);}catch(z){}if(E.modo!=='cortes')edInsp();});
  document.addEventListener('pointermove',function(e){if(!drag)return;var E=S.ed;if(!E)return;
    if(drag.ph){edSeek((e.clientX-drag.x0)/edPPS());return;}
    var dt=(e.clientX-drag.x)/drag.p;
    if(drag.seg!=null){drag.dx+=(e.clientX-drag.lx)*(e.shiftKey?0.1:1);drag.lx=e.clientX;dt=drag.dx/drag.p*(drag.vel||1);var r=curReel(),dur=(r&&r.fuenteDur)||1e9,s=E.segs[drag.seg],P=drag.p,L=drag.lado==='L';
      var nd=drag.d,nh=drag.h;if(L)nd=Math.max(drag.lo,Math.min(drag.h-0.1,drag.d+dt));else nh=Math.min(dur,drag.hi,Math.max(drag.d+0.1,drag.h+dt));
      /* imán: la orilla que jalas se pega al cursor de la línea del tiempo, como en CapCut */
      if(drag.tp==null)drag.tp=E.t;var tp=drag.tp,snap=false;
      if(L){if(!e.shiftKey&&Math.abs((drag.acc+(nd-drag.d))-tp)*P<8){nd=Math.max(drag.lo,Math.min(drag.h-0.1,drag.d+(tp-drag.acc)));snap=Math.abs((drag.acc+(nd-drag.d))-tp)*P<1;}}
      else{if(!e.shiftKey&&Math.abs((drag.acc+(nh-drag.d))-tp)*P<8){nh=Math.min(dur,drag.hi,Math.max(drag.d+0.1,drag.d+(tp-drag.acc)));snap=Math.abs((drag.acc+(nh-drag.d))-tp)*P<1;}}
      s.d=nd;s.h=nh;s.fijo=true;
      var ph=document.querySelector('.ed-ph');if(ph)ph.classList.toggle('ed-snap',snap);
      /* como CapCut: la orilla que jalas recorta, el inicio de la parte se queda en su lugar y todo lo de después se recorre en vivo */
      drag.snap=snap;if(!drag.raf){drag.raf=requestAnimationFrame(function(){drag.raf=0;var sc=$('edScroll'),sl=sc?sc.scrollLeft:0;edDrawTracks();if(sc)sc.scrollLeft=sl;var ph2=document.querySelector('.ed-ph');if(ph2)ph2.classList.toggle('ed-snap',!!drag.snap);});}
      var v=edV();if(v)v.currentTime=L?s.d:Math.max(s.d,s.h-0.034);return;}
    if(Math.abs(e.clientX-drag.x)>2)drag.moved=true;edMover(drag.it,dt,drag.lado,drag.base);var el2=document.querySelector('[data-eid="'+drag.it.id+'"]');if(el2){el2.style.left=(drag.it.t0*drag.p)+'px';el2.style.width=Math.max(6,(drag.it.t1-drag.it.t0)*drag.p)+'px';}
    E.t=drag.lado==='R'?drag.it.t1-0.05:drag.it.t0;edSeek(E.t);});
  document.addEventListener('pointerup',function(){if(!drag)return;var E=S.ed,d=drag;drag=null;if(!E)return;
    E.drag=false;var ph0=document.querySelector('.ed-ph');if(ph0)ph0.classList.remove('ed-snap');if(d.ph)return;if(d.it&&!d.moved){E.hist.pop();edInsp();edDrawTracks();return;}
    if(d.seg!=null){edReubicar(d.anc);edArmar();var sg=E.segs[d.seg];if(sg){E.t=Math.min(edTotal(),d.tp==null?E.t:d.tp);var sc3=$('edScroll'),sl3=sc3?sc3.scrollLeft:0;edDraw();if(sc3)sc3.scrollLeft=sl3;edSeek(E.t);edGuardarBorrador();return;}}edDraw();edGuardarBorrador();});
})();

/* formulario genérico: cada propiedad de un efecto compuesto (texto, números, listas, elementos) es editable */
var ED_OCULTO={kind:1,t:1,en:1,escena:1,vez:1,hasta:1,dura:1,text:1,detras:1,posicion:1,mano:1,t0:1,t1:1,aparece:1};
var ED_ROT={x:'Posición horizontal',y:'Posición vertical',tam:'Tamaño',rot:'Giro',color:'Color',fondo:'Fondo',size:'Tamaño',fuente:'Letra',font:'Letra',texto:'Texto',titulo:'Título',etiqueta:'Etiqueta',label:'Etiqueta',items:'Elementos',elementos:'Elementos',pasos:'Pasos',opciones:'Opciones',imagen:'Imagen',image:'Imagen',file:'Archivo',sonido:'Sonido',efecto:'Efecto',delay:'Entra después de',retraso:'Entra después de',inicio:'Empieza',fin:'Termina',duracion:'Dura',ancho:'Ancho',alto:'Alto',escala:'Escala',opacidad:'Opacidad',animacion:'Animación',entrada:'Entrada',salida:'Salida',estilo:'Estilo'};
function edRot(k){if(ED_ROT[k])return ED_ROT[k];var t=String(k).replace(/_/g,' ');return t.charAt(0).toUpperCase()+t.slice(1);}
function edForma(o){var out='';Object.keys(o).forEach(function(k){if(ED_OCULTO[k]||k.charAt(0)==='_')return;out+=edCampo(o[k],k,k,0);});
  return out?'<div class="ed-forma"><h4>Elementos y ajustes</h4><p class="ed-mut">Cambia lo que quieras: textos, tamaños, posiciones, tiempos. Se ve al instante.</p>'+out+'</div>':'<p class="ed-mut">'+edEsc(edNom(S.ed&&edSelItem()?edSelItem().k:''))+': efecto animado. Muévelo o cámbiale la duración aquí.</p>';}
function edCampo(v,path,k,d){var lab=isNaN(+k)?edRot(k):'Elemento '+(+k+1);
  if(typeof v==='string'){var big=v.length>40||v.indexOf('\n')>=0;return '<label class="ed-f ed-col"><span>'+edEsc(lab)+'</span>'+(/^#[0-9a-f]{3,8}$/i.test(v)?'<input type="color" data-ep="'+path+'" data-tp="s" value="'+(v.length===7?v:'#000000')+'">':(big?'<textarea rows="2" data-ep="'+path+'" data-tp="s">'+edEsc(v)+'</textarea>':'<input type="text" data-ep="'+path+'" data-tp="s" value="'+edEsc(v)+'">'))+'</label>';}
  if(typeof v==='number')return '<label class="ed-f"><span>'+edEsc(lab)+'</span><input type="number" step="'+(Math.abs(v)<5&&v%1?0.05:1)+'" data-ep="'+path+'" data-tp="n" value="'+v+'"></label>';
  if(typeof v==='boolean')return '<label class="ed-f"><input type="checkbox" data-ep="'+path+'" data-tp="b"'+(v?' checked':'')+'> <span>'+edEsc(lab)+'</span></label>';
  if(Array.isArray(v)){var h='<div class="ed-grp"><div class="ed-grph"><b>'+edEsc(lab)+'</b><button type="button" class="ed-b" data-e="eadd" data-ep="'+path+'">＋ Agregar</button></div>';v.forEach(function(z,i){h+='<div class="ed-grpi">'+edCampo(z,path+'.'+i,String(i),d+1)+'<button type="button" class="ed-b ed-del" data-e="edel" data-ep="'+path+'.'+i+'" title="Quitar">×</button></div>';});return h+'</div>';}
  if(v&&typeof v==='object'){var h2='<div class="ed-grp"><div class="ed-grph"><b>'+edEsc(lab)+'</b></div>';Object.keys(v).forEach(function(kk){if(kk.charAt(0)!=='_')h2+=edCampo(v[kk],path+'.'+kk,kk,d+1);});return h2+'</div>';}
  return '';}
function edRuta(o,path,crear){var p=path.split('.'),c=o;for(var i=0;i<p.length-1;i++){c=c[p[i]];if(c==null)return null;}return {c:c,k:p[p.length-1]};}
document.addEventListener('input',function(e){var t=e.target;if(!t.dataset||!t.dataset.ep||t.dataset.e)return;var E=S.ed;if(!E||!E.mounted)return;var x=edSelItem();if(!x)return;var o=edItemObj(x);if(!o)return;var r=edRuta(o,t.dataset.ep);if(!r)return;
  if(!E._tx){edPush();E._tx=1;}var tp=t.dataset.tp;r.c[r.k]=tp==='n'?(isFinite(+t.value)?+t.value:0):(tp==='b'?t.checked:t.value);x.mano=true;edDrawTracks();edOverlay();edGuardarBorrador();});
document.addEventListener('change',function(e){var t=e.target;if(t.dataset&&t.dataset.ep&&S.ed)S.ed._tx=0;});
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-e="eadd"],[data-e="edel"]');if(!b||!S.ed||!S.ed.mounted)return;var E=S.ed,x=edSelItem();if(!x)return;var o=edItemObj(x);if(!o)return;var r=edRuta(o,b.dataset.ep);if(!r)return;edPush();
  if(b.dataset.e==='eadd'){var arr=r.c[r.k];if(Array.isArray(arr)){var m=arr.length?JSON.parse(JSON.stringify(arr[arr.length-1])):'';arr.push(m);}}else{r.c.splice(+r.k,1);}
  x.mano=true;e.stopImmediatePropagation();edDraw();edGuardarBorrador();},true);
/* inspector: texto, tiempos, opciones */
document.addEventListener('input',function(e){var E=S.ed;if(!E||!E.mounted)return;var x=edSelItem();if(!x)return;var o=edItemObj(x);if(!o)return;
  if(e.target.id==='edTxt'){if(!E._tx){edPush();E._tx=1;}o.text=e.target.value;x.mano=x.mano||false;edDrawTracks();edOverlay();edGuardarBorrador();}
  if(e.target.id==='edT0'||e.target.id==='edDur'){var t0=+$('edT0').value,du=+$('edDur').value;if(isFinite(t0)&&isFinite(du)&&du>0.05){edPush();x.t0=Math.max(0,t0);x.t1=x.t0+du;x.mano=true;edDrawTracks();edOverlay();edGuardarBorrador();}}});
document.addEventListener('focusout',function(e){if(S.ed&&e.target.id==='edTxt')S.ed._tx=0;});
document.addEventListener('change',function(e){var E=S.ed;if(!E||!E.mounted)return;var x=edSelItem();if(!x)return;var o=edItemObj(x);if(!o)return;
  if(e.target.id==='edDetras'){edPush();o.detras=e.target.checked;edGuardarBorrador();}
  if(e.target.id==='edPos'){edPush();o.posicion=e.target.value;delete o.x;delete o.y;edOverlay();edGuardarBorrador();}});
/* teclado tipo CapCut */
document.addEventListener('keydown',function(e){var E=S.ed;if(!E||!E.mounted||S.view!=='editor')return;var tg=e.target.tagName;if(tg==='INPUT'||tg==='TEXTAREA'||tg==='SELECT')return;
  var mod=e.metaKey||e.ctrlKey;
  if(e.code==='Space'){e.preventDefault();E.playing?edPause():edPlay();}
  else if(mod&&(e.key==='z'||e.key==='Z')){e.preventDefault();e.shiftKey?edRedo():edUndo();}
  else if(mod&&(e.key==='y'||e.key==='Y')){e.preventDefault();edRedo();}
  else if(e.key==='b'||e.key==='B'){e.preventDefault();edSplit();}
  else if(E.wm!=null&&$('edWm')&&(e.key==='Delete'||e.key==='Backspace')){e.preventDefault();var wi=E.wm;edWCerrar();edPalabra(wi);}
  else if(E.wm!=null&&$('edWm')&&(e.key==='h'||e.key==='H')){e.preventDefault();edWRes(E.wm);}
  else if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();edDelSel();}
  else if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();edPause();edSeek(E.t+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?1:FR));}
  else if(e.key==='+'||e.key==='='){edZoomA(E.zoom*1.4,null);}
  else if(e.key==='-'){edZoomA(E.zoom/1.4,null);}
  else if(e.key===','||e.key==='.'){e.preventDefault();edPause();edSeek(E.t+(e.key===','?-1:1)*FR);}
  else if(!mod&&(e.key==='q'||e.key==='Q')){e.preventDefault();edCortaCabezal('L');}
  else if(!mod&&(e.key==='w'||e.key==='W')){e.preventDefault();edCortaCabezal('R');}
  else if(e.key==='Escape'){edWCerrar();E.sel=null;edInsp();edDrawTracks();edOverlay();}});
window.addEventListener('resize',function(){if(S.ed&&S.ed.mounted){edDrawTracks();edOverlay();}});
/* ===== storyboard: comentario y recurso por escena ===== */
function sbCom(r,i,crear){if(!r.sbComentarios)r.sbComentarios=[];var c=r.sbComentarios.find(function(x){return x.i===i;});if(!c&&crear){c={i:i,nota:'',media:[]};r.sbComentarios.push(c);}return c||null;}
function sbGuardar(r){clearTimeout(S._sbT);S._sbT=setTimeout(function(){var L=(r.sbComentarios||[]).filter(function(c){return c.nota||(c.media&&c.media.length);});var ref=reelRef(r);if(ref)ref.update({sbComentarios:L}).catch(function(){});var sv=$('sbSaved');if(sv)sv.textContent='Comentarios guardados';},500);}
function sbEscenas(r){var es=((r.storyboard||{}).escenas)||[];if(!es.length)return '';
  return '<section class="card"><div class="row" style="justify-content:space-between"><h2>Tu storyboard por escena</h2><span class="small" id="sbSaved">Comentarios opcionales</span></div><p class="small" style="margin:0">Debajo de cada escena puedes escribir qué quieres ahí, o elegir un recurso de tus Brand Assets para decirme en qué frase va. Lo tomo en cuenta al editar.</p><div class="sbn-grid">'+es.map(function(e,i){var c=sbCom(r,i,false)||{nota:'',media:[]};
    var med=e.videoId?'<div class="sbn-med"><video src="'+blob(e.videoId)+'" playsinline controls loop muted preload="metadata"></video></div>':(e.fotoId?'<div class="sbn-med"><img src="'+blob(e.fotoId)+'" alt="Escena '+(i+1)+'"></div>':'');
    return '<div class="sbn">'+med+'<b>Escena '+(i+1)+(e.tiempo?' · '+esc(e.tiempo):'')+'</b><p class="small" style="margin:0">'+esc((e.pantalla||e.dice||'').slice(0,140))+'</p>'+
    '<textarea class="ed-nota" data-sbn="'+i+'" rows="2" placeholder="Tu comentario para esta escena">'+esc(c.nota||'')+'</textarea>'+
    '<div class="ed-mrow">'+(c.media||[]).map(function(m,k){return '<span class="ed-mchip" title="'+esc(m.nombre||'')+'">'+edMiniMedia(m,'ed-mth')+'<button type="button" class="ed-mx" data-sbx="'+i+'" data-k="'+k+'" aria-label="Quitar">×</button></span>';}).join('')+'<button type="button" class="btn soft sm" data-sbm="'+i+'">＋ De mis Brand Assets</button></div></div>';}).join('')+'</div></section>';}
function sbPickDibujar(){var pk=S.sbPick,box=$('sbPick');if(!pk||!box)return;var r=curReel(),c=r&&sbCom(r,pk.i,false),sel=(c&&c.media||[]).map(function(m){return m.ruta;});
  var h='<div class="ed-pbox" role="dialog"><div class="ed-ptop"><h3>¿Qué recurso va en la escena '+(pk.i+1)+'?</h3><button type="button" class="ed-b ed-main" data-sbclose="1">Listo</button></div>';
  if(!pk.grupos)h+='<p class="ed-mut">Buscando tus archivos…</p>';
  else if(!pk.grupos.length)h+='<p class="ed-mut">No encontré tu carpeta Brand Assets. Revisa que esté dentro de The Edit Lab.</p>';
  else{h+='<div class="ed-ptabs">'+pk.grupos.map(function(g){return '<button type="button" class="ed-b'+(g.id===pk.tab?' ed-on':'')+'" data-sbtab="'+g.id+'">'+esc(g.nombre)+' <span class="ed-pill">'+g.archivos.length+'</span></button>';}).join('')+'</div>';
    var g=pk.grupos.find(function(q){return q.id===pk.tab;});
    if(!g||!g.archivos.length)h+='<p class="ed-mut">Esta carpeta está vacía.</p>';
    else h+='<div class="ed-pgrid">'+g.archivos.map(function(a){var ruta='Brand Assets/'+a.r,on=sel.indexOf(ruta)>=0;return '<button type="button" class="ed-pi'+(on?' ed-on':'')+'" data-sbp="'+esc(a.r)+'" title="'+esc(a.n)+'">'+edMiniMedia({ruta:ruta,tipo:a.v?'video':'imagen',nombre:a.n},'ed-pimg')+'<span>'+esc(a.n)+'</span>'+(on?'<i class="ed-ck">✓</i>':'')+'</button>';}).join('')+'</div>';}
  box.innerHTML=h+'</div>';}
document.addEventListener('input',function(e){var t=e.target;if(!t.dataset||t.dataset.sbn==null)return;var r=curReel();if(!r)return;var c=sbCom(r,+t.dataset.sbn,true);c.nota=t.value;sbGuardar(r);});
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-sbm],[data-sbx],[data-sbclose],[data-sbtab],[data-sbp]');if(!b)return;var r=curReel();if(!r)return;var d=b.dataset;
  if(d.sbm!=null){S.sbPick={i:+d.sbm,tab:null,grupos:null};var m=$('sbPick');if(m)m.remove();var x=document.createElement('div');x.id='sbPick';x.className='ed-pick sb-pick';document.body.appendChild(x);sbPickDibujar();
    fetch('/api/brand/lista').then(function(q){return q.json();}).then(function(j){if(!S.sbPick)return;S.sbPick.grupos=j.grupos||[];var g=S.sbPick.grupos.find(function(q){return q.archivos.length;});S.sbPick.tab=g?g.id:(S.sbPick.grupos[0]||{}).id;sbPickDibujar();}).catch(function(){if(S.sbPick){S.sbPick.grupos=[];sbPickDibujar();}});return;}
  if(d.sbx!=null){var c=sbCom(r,+d.sbx,false);if(c){c.media.splice(+d.k,1);sbGuardar(r);render();}return;}
  if(d.sbclose){var m2=$('sbPick');if(m2)m2.remove();S.sbPick=null;render();return;}
  if(d.sbtab){S.sbPick.tab=d.sbtab;sbPickDibujar();return;}
  if(d.sbp){var pk=S.sbPick;if(!pk)return;var c2=sbCom(r,pk.i,true),rel=d.sbp,ruta='Brand Assets/'+rel,k=c2.media.findIndex(function(m){return m.ruta===ruta;});
    if(k>=0)c2.media.splice(k,1);else{var g=pk.grupos.find(function(q){return q.archivos.some(function(a){return a.r===rel;});}),a=g&&g.archivos.find(function(q){return q.r===rel;});c2.media.push({ruta:ruta,nombre:a?a.n:rel.split('/').pop(),tipo:a&&a.v?'video':'imagen',grupo:g?g.id:''});}
    sbGuardar(r);sbPickDibujar();}});
['wheel','touchmove'].forEach(function(ev){document.addEventListener(ev,function(e){var E=S.ed;if(E&&E.playing&&e.target.closest&&e.target.closest('#edInsp,#edPartes'))E.noSeguir=true;},{passive:true});});

/* ===== vista EXACTA: el mismo motor del video final (Main.tsx en @remotion/player), con tus cambios del momento =====
   Cada cambio pasa por el mismo cálculo de la versión final (cues.py en tu compu) y se vuelve a dibujar aquí. */
function edPlIniciar(){var r=curReel(),E=S.ed;if(!r||!E||E.plIni)return;E.plIni=1;var msg=$('edPlMsg');
  (function pide(n){fetch('/api/player/preparar?reel='+encodeURIComponent(r.id)).then(function(x){return x.json();}).then(function(j){if(S.ed!==E)return;
    if(j.estado==='instalando'){if(msg)msg.textContent=j.error?'No pude preparar la vista exacta: '+j.error:'Preparando la vista exacta de tu video (solo la primera vez, 1–3 minutos)…';if(!j.error&&n<80)setTimeout(function(){pide(n+1);},5000);return;}
    if(j.estado!=='listo'){if(msg)msg.textContent='La vista exacta no está disponible ('+String(j.error||'').slice(0,120)+'). Ves una vista aproximada.';return;}
    if(j.plan&&j.plan.efectos&&!E.dirty&&(!r.editorBorrador||JSON.stringify(r.editorBorrador.plan||null)===JSON.stringify(edPlanOf(r)))){/* el plan con el que de verdad quedó su video (con los últimos ajustes) */j.plan.acercamientos=j.plan.acercamientos||[];E.plan=j.plan;try{edDraw();}catch(e){}}
    fetch(j.js).then(function(x){return x.text();}).then(function(txt){E.plJs=txt;edPlActualizar();});}).catch(function(){if(msg)msg.textContent='La vista exacta no está disponible. Ves una vista aproximada.';});})(0);}
function edPlActualizar(){var r=curReel(),E=S.ed;if(!r||!E||!E.plJs)return;var n=(E.plN=(E.plN||0)+1);var msg=$('edPlMsg');
  var W=(E.words||[]).map(function(w){return {t:w.t,s:w.s,e:w.e};});
  fetch('/api/player/datos',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reel:r.id,plan:edPlanFinal(),segs:E.segs,words:W})}).then(function(x){return x.json();}).then(function(d){
    if(S.ed!==E||n!==E.plN)return;
    if(d.error){if(msg){msg.hidden=false;msg.textContent=d.error;}return;}
    E.plAvisos=(d.problemas||[]).concat((d.movidos||[]).map(function(m){return 'Lo moví para no tapar tu cara: '+m;}));
    var t0=E.t,play=E.playing;if(E.player){try{E.player.pause();}catch(e){}}
    var api=window.__TEL_API;if(api&&api.root){try{api.root.unmount();}catch(e){}}
    var el=$('edPl');if(!el)return;el.hidden=false;el.innerHTML='';
    if(!el._clk){el._clk=1;el.style.cursor='pointer';el.title='Toca un texto o efecto para editarlo';el.addEventListener('click',function(){var E2=S.ed;if(!E2)return;var t=E2.t;
      var c=(E2.items||[]).filter(function(x){return x.track==='fx'&&t>=x.t0-0.05&&t<=x.t1+0.05;}).sort(function(a,b){return (a.t1-a.t0)-(b.t1-b.t0);});
      if(!c.length){toast('En este momento no hay un texto o efecto. Ve a uno en la línea de tiempo.');return;}
      if(E2.playing)edPause();E2.sel=c[0].id;edDraw();edInsp();});}
    window.remotion_staticBase='/player/'+encodeURIComponent(r.id)+'/f';
    d.segs=d.base?null:E.segs;d.t0=t0;d.play=play;d.mute=!!E.muted;window.__TEL=d;window.__TEL_EL=el;
    window.__TEL_API={listo:function(p){if(S.ed!==E)return;E.player=p;['edVid','edVid2'].forEach(function(id){var q=$(id);if(q){q.pause();q.style.visibility='hidden';}});if(msg)msg.hidden=true;edOverlay();edInsp();}};
    try{(new Function(E.plJs))();}catch(e){if(msg){msg.hidden=false;msg.textContent='La vista exacta falló: '+String(e).slice(0,120);}}
  }).catch(function(){});}

/* ===== menú de cada palabra (como el Engine): quitar o regresar, resaltar en los subtítulos, nota para Claude ===== */
var ED_NOTAS_RAPIDAS=['Se corta el sonido','Pausa incómoda','Toma equivocada','No se entiende'];
function edResDe(){var r=curReel();return (r&&Array.isArray(r.resaltadas))?r.resaltadas:[];}
function edNotaW(){var r=curReel();return (r&&r.notasPalabras&&typeof r.notasPalabras==='object')?r.notasPalabras:{};}
function edWGuardar(){var r=curReel();if(!r)return;var ref=reelRef(r);var pw={resaltadas:edResDe(),notasPalabras:edNotaW(),notasPalabrasTexto:edNotasPalabrasTexto()};Object.assign(r,pw);if(ref)ref.update(pw).catch(function(){});var s=$('edSaved');if(s)s.textContent='Guardado';}
function edNotasPalabrasTexto(){var W=edTodas(),N=edNotaW();return Object.keys(N).map(function(k){var i=+k,w=W[i]||{};var ctx=W.slice(Math.max(0,i-3),i+4).map(function(x){return x.t;}).join(' ');return {i:i,palabra:w.t||'',s:w.s,nota:N[k],contexto:ctx};});}
function edWMenu(i,btn){var E=S.ed,W=edTodas(),w=W[i];if(!w||w.s==null)return;edWCerrar();E.wm=i;var viva=edViva(w),res=edResDe().indexOf(i)>=0,nota=edNotaW()[i]||'';
  var m=document.createElement('div');m.id='edWm';m.className='ed-wm';m.setAttribute('role','dialog');
  m.innerHTML='<div class="ed-wmh"><b>“'+edEsc(w.t)+'”</b><button type="button" class="ed-b ed-ic" data-e="wcerrar" aria-label="Cerrar">×</button></div>'+
    '<div class="ed-wmr"><button type="button" class="ed-b" data-e="wq">'+(viva?'✂ Quitar':'↩ Regresar')+'</button><button type="button" class="ed-b'+(res?' ed-on':'')+'" data-e="wh" title="H">'+(res?'Quitar resaltado':'✦ Resaltar')+'</button></div>'+
    '<div class="ed-wmn"><span class="ed-mut">Nota para Claude</span><div class="ed-wmq">'+ED_NOTAS_RAPIDAS.map(function(q){return '<button type="button" class="ed-b'+(nota===q?' ed-on':'')+'" data-e="wn" data-t="'+edEsc(q)+'">'+q+'</button>';}).join('')+'</div>'+
    '<div class="ed-wmq"><input type="text" id="edWmTxt" placeholder="O escribe tu nota…" value="'+(ED_NOTAS_RAPIDAS.indexOf(nota)<0?edEsc(nota):'')+'"><button type="button" class="ed-b" data-e="wn" data-t="">Guardar</button>'+(nota?'<button type="button" class="ed-b" data-e="wnx">Quitar nota</button>':'')+'</div></div>';
  document.body.appendChild(m);var rc=btn.getBoundingClientRect(),mw=m.offsetWidth,mh=m.offsetHeight;var x=Math.min(window.innerWidth-mw-8,Math.max(8,rc.left)),y=rc.bottom+6;if(y+mh>window.innerHeight-8)y=Math.max(8,rc.top-mh-6);m.style.left=x+'px';m.style.top=y+'px';
  var inp=m.querySelector('#edWmTxt');inp.addEventListener('keydown',function(ev){if(ev.key==='Enter'){ev.preventDefault();edWNota(E.wm,'');}else if(ev.key==='Escape')edWCerrar();});
  setTimeout(function(){document.addEventListener('mousedown',edWFuera,true);},0);}
function edWFuera(ev){var m=$('edWm');if(m&&!m.contains(ev.target)&&!ev.target.closest('[data-e="word"]'))edWCerrar();}
function edWCerrar(){var m=$('edWm');if(m)m.remove();document.removeEventListener('mousedown',edWFuera,true);if(S.ed)S.ed.wm=null;}
function edWRes(i){if(i==null)return;var L=edResDe().slice(),k=L.indexOf(i);if(k>=0)L.splice(k,1);else L.push(i);L.sort(function(a,b){return a-b;});curReel().resaltadas=L;edWGuardar();var b=$('edWm');var keep=b?document.querySelector('[data-e="word"][data-wi="'+i+'"]'):null;edInsp();var nb=document.querySelector('[data-e="word"][data-wi="'+i+'"]');if(b&&nb)edWMenu(i,nb);}
function edWNota(i,t){if(i==null)return;var r=curReel(),N=Object.assign({},edNotaW());if(t===null){delete N[i];}else{var v=t||(($('edWmTxt')||{}).value||'').trim();if(!v)return;N[i]=v;}r.notasPalabras=N;edWGuardar();edWCerrar();edInsp();toast(t===null?'Nota quitada':'Nota guardada: Claude la revisa cuando apruebes tus cortes');}
/* línea de tiempo más alta: arrastra la orilla de arriba (doble clic la regresa) */
function edAltoIni(){var tl=$('edTl');if(!tl||tl._alto)return;tl._alto=1;var g=document.createElement('div');g.className='ed-grip';g.title='Arrastra para hacer la línea de tiempo más alta (doble clic: regresar)';tl.prepend(g);
  var h0=null;try{h0=+localStorage.getItem('tel-tl-alto')||null;}catch(e){}if(h0)tl.style.setProperty('--ed-tl-h',h0+'px');
  g.addEventListener('dblclick',function(){tl.style.removeProperty('--ed-tl-h');try{localStorage.removeItem('tel-tl-alto');}catch(e){}edDrawTracks();});
  g.addEventListener('pointerdown',function(ev){ev.preventDefault();var y0=ev.clientY,a0=tl.getBoundingClientRect().height;g.setPointerCapture(ev.pointerId);
    function mv(e2){var h=Math.max(160,Math.min(window.innerHeight*0.75,a0+(y0-e2.clientY)));tl.style.setProperty('--ed-tl-h',h+'px');}
    function up(e2){g.removeEventListener('pointermove',mv);g.removeEventListener('pointerup',up);var h=parseFloat(getComputedStyle(tl).getPropertyValue('--ed-tl-h'))||0;try{if(h)localStorage.setItem('tel-tl-alto',Math.round(h));}catch(e){}edDrawTracks();}
    g.addEventListener('pointermove',mv);g.addEventListener('pointerup',up);});}
/* Q / W: al pasar el mouse por el botón se sombrea exactamente lo que va a cortar */
function edSombraQW(lado){var E=S.ed,box=$('edTracks');if(!E||!box)return;var x=box.querySelector('.ed-qw');if(!lado){if(x)x.remove();return;}var p=edSrc(E.t),s=E.segs[p.i];if(!s)return;var acc=0;for(var k=0;k<p.i;k++)acc+=edL(E.segs[k]);var P=E._P||edPPS();var t=E.t,a0=lado==='L'?acc:t,a1=lado==='L'?t:acc+edL(s);
  if(!x){x=document.createElement('div');x.className='ed-qw';box.appendChild(x);}x.style.left=(a0*P)+'px';x.style.width=Math.max(0,(a1-a0)*P)+'px';}
document.addEventListener('mouseover',function(e){var b=e.target.closest&&e.target.closest('[data-e="qcut"],[data-e="wcut"]');if(b&&S.ed)edSombraQW(b.dataset.e==='qcut'?'L':'R');});
document.addEventListener('mouseout',function(e){var b=e.target.closest&&e.target.closest('[data-e="qcut"],[data-e="wcut"]');if(b&&S.ed)edSombraQW(null);});
