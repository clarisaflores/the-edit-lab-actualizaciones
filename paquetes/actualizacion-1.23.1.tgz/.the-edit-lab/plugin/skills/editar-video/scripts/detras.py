"""Títulos DETRÁS de la silueta de la clienta (su cabeza tapa parte de las letras).

Remotion no dibuja los efectos con "detras": true; este módulo los pinta después del render, cuadro por cuadro:
recorta su silueta con el segmentador de MediaPipe (modelo selfie_segmenter.tflite) sobre el cuadro YA renderizado
(con zoom y todo), dibuja las letras y vuelve a poner su silueta encima. Lo llama final.py solo; no hace falta correrlo.

Si MediaPipe o el modelo no están, disponible() es False y cues.py pone esos títulos delante, arriba de la cabeza.
"""
import os, json, subprocess, math
import numpy as np

MODELO = os.path.expanduser('~/.cvs-motor/modelos/selfie_segmenter.tflite')
W, H, FPS = 1080, 1920, 30


def disponible():
    if not os.path.exists(MODELO):
        return False
    try:
        import mediapipe  # noqa: F401
        from PIL import Image  # noqa: F401
        return True
    except Exception:
        return False


class _Seg:
    def __init__(self):
        import mediapipe as mp
        from mediapipe.tasks.python import vision, BaseOptions
        self.mp = mp
        self.s = vision.ImageSegmenter.create_from_options(vision.ImageSegmenterOptions(
            base_options=BaseOptions(model_asset_path=MODELO), output_confidence_masks=True,
            running_mode=vision.RunningMode.VIDEO))
        self.prev = None; self.ts = 0

    def close(self):
        try: self.s.close()
        except Exception: pass

    def mask(self, rgb):
        import cv2
        small = cv2.resize(rgb, (540, 960))
        self.ts += 34
        m = self.s.segment_for_video(self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=np.ascontiguousarray(small)), self.ts).confidence_masks[0].numpy_view().copy()
        m = cv2.resize(m, (rgb.shape[1], rgb.shape[0]))
        self.prev = m if self.prev is None else 0.6 * m + 0.4 * self.prev
        return cv2.GaussianBlur(self.prev, (0, 0), 1.5)


def _frames(path):
    p = subprocess.Popen(['ffmpeg', '-nostdin', '-v', 'error', '-i', path, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
    n = W * H * 3
    while True:
        b = p.stdout.read(n)
        if len(b) < n: break
        yield np.frombuffer(b, np.uint8).reshape(H, W, 3)
    p.wait()


def cabeza_top(video, muestras=8):
    """Altura (px, en 1080x1920) donde empieza la cabeza: la mediana de varias muestras del video."""
    import cv2
    if not disponible(): return None
    dur = float(json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'json', video], capture_output=True, text=True).stdout)['format']['duration'])
    seg = _Seg(); tops = []
    for k in range(muestras):
        t = dur * (k + 0.5) / muestras
        r = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-ss', f'{t:.2f}', '-i', video, '-frames:v', '1', '-vf', f'scale={W}:{H}', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], capture_output=True)
        if len(r.stdout) < W * H * 3: continue
        seg.prev = None
        m = seg.mask(np.frombuffer(r.stdout[:W * H * 3], np.uint8).reshape(H, W, 3)) > 0.5
        rows = np.where(m[:, 300:780].any(1))[0]
        if len(rows): tops.append(int(rows.min()))
    seg.close()
    return int(np.median(tops)) if tops else None


def _eb(p):
    p = min(max(p, 0), 1); c1 = 1.70158 * 0.6; c3 = c1 + 1
    return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2


def _capa(o, t, fuente, color, cache):
    """Dibuja las líneas del efecto en el segundo t (misma animación que Main.tsx). Devuelve RGBA o None."""
    from PIL import Image, ImageDraw, ImageFont
    fin = 1.0 if t <= o['t1'] - 0.25 else max(0.0, (o['t1'] - t) / 0.25)
    capa = None
    for i, l in enumerate(o['lineas']):
        p = (t - l['t']) / 0.28
        if p <= 0: continue
        key = (id(o), i)
        if key not in cache:
            f = ImageFont.truetype(fuente, int(l['size']))
            bb = f.getbbox(l['text']); im = Image.new('RGBA', (bb[2] - bb[0] + 20, bb[3] - bb[1] + 20), (0, 0, 0, 0))
            ImageDraw.Draw(im).text((10 - bb[0], 10 - bb[1]), l['text'], font=f, fill=color); cache[key] = im
        L = cache[key]; sc = 0.6 + 0.4 * _eb(p); a = min(1.0, p * 2) * fin
        if a <= 0.01: continue
        if abs(sc - 1) > 1e-3: L = L.resize((max(1, int(L.size[0] * sc)), max(1, int(L.size[1] * sc))), Image.LANCZOS)
        if a < 0.999: L = L.copy(); L.putalpha(L.getchannel('A').point(lambda v: int(v * a)))
        if capa is None: capa = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        capa.alpha_composite(L, (int(W / 2 - L.size[0] / 2), int(l['y'] - L.size[1] / 2)))
    return capa


def procesar(video, inicio_cuadro, overlays, fuente, color_hex):
    """Pinta los efectos con detras=True en `video` (empieza en el cuadro `inicio_cuadro`). Lo reescribe en su lugar."""
    from PIL import Image
    det = [o for o in overlays if o.get('detras') and o.get('lineas')]
    n = int(float(json.loads(subprocess.run(['ffprobe', '-v', 'error', '-count_packets', '-select_streams', 'v:0', '-show_entries', 'stream=nb_read_packets', '-of', 'json', video], capture_output=True, text=True).stdout)['streams'][0]['nb_read_packets']))
    t_a, t_b = inicio_cuadro / FPS, (inicio_cuadro + n) / FPS
    det = [o for o in det if o['t0'] < t_b and o['t1'] > t_a]
    if not det: return False
    color = o_color = tuple(int(color_hex.lstrip('#')[i:i + 2], 16) for i in (0, 2, 4))
    seg = _Seg(); cache = {}
    tmp = video + '.detras.mp4'
    enc = subprocess.Popen(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                            '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', tmp], stdin=subprocess.PIPE)
    for k, fr in enumerate(_frames(video)):
        t = (inicio_cuadro + k) / FPS
        vivos = [o for o in det if o['t0'] <= t <= o['t1']]
        if not vivos:
            seg.prev = None; enc.stdin.write(fr.tobytes()); continue
        img = Image.fromarray(fr).convert('RGBA'); con = img.copy(); hubo = False
        for o in vivos:
            c = tuple(int(o['color'].lstrip('#')[i:i + 2], 16) for i in (0, 2, 4)) if o.get('color') else color
            capa = _capa(o, t, fuente, c, cache)
            if capa is not None: con.alpha_composite(capa); hubo = True
        if not hubo:
            enc.stdin.write(fr.tobytes()); continue
        m = seg.mask(fr)[..., None]
        out = (fr.astype(np.float32) * m + np.asarray(con.convert('RGB')).astype(np.float32) * (1 - m))
        enc.stdin.write(np.clip(out, 0, 255).astype(np.uint8).tobytes())
    seg.close(); enc.stdin.close(); enc.wait()
    if enc.returncode != 0: raise SystemExit('detras.py: no se pudo codificar ' + video)
    os.replace(tmp, video)
    return True
