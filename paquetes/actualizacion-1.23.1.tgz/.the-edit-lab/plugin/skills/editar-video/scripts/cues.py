"""Paso 8: convierte plan.json (los efectos que eliges) en cues.json para Remotion, con tiempos exactos y sonidos.

Uso: python3 cues.py <carpeta_trabajo> --estilo <estilo.json> [--emoji <carpeta de PNG>] [--publico <remotion/public>]
plan.json:
{
  "efectos": [
    {"kind": "titulo", "text": "Texto del gancho ✨", "t": 0, "dura": 4},
    {"kind": "flotante", "text": "cosa 1", "en": "palabra", "escena": "2", "x": 300, "y": 160},
    {"kind": "paso", "text": "1. Primer paso", "en": "primero", "hasta": "segundo"},
    {"kind": "caja_escribe", "text": "Ejemplo largo", "en": "ejemplo", "vez": 2},
    {"kind": "imagen", "image": "portada.png", "en": "ebook", "x": 900, "y": 220},
    {"kind": "gancho", "text": "LE PEDÍ A UNA IA\nQUE EDITARA\nMI VIDEO", "t": 0, "dura": 2.3, "detras": true},
    {"kind": "palabra", "text": "DINÁMICA", "en": "dinámica", "hasta": "borre", "detras": true},
    {"kind": "tachado", "text": "PAUSAS", "en": "pausas", "hasta": "cometer"},
    {"kind": "cierre", "text": "MOSTRAR TODOS\nMIS CONOCIMIENTOS", "en": "mostrar", "aparece": ["mostrar", "mis"]}
  ],
  "acercamientos": [{"en": "importante"}, {"t": 42.5}]
}
- "en": palabra donde empieza (como se dijo, sin importar acentos ni mayúsculas). "escena" limita la búsqueda
  a esa escena (su número o nombre). "vez": 1 = la primera vez que la dice en esa escena (2 = la segunda…).
- "t": segundo exacto, si no hay palabra que sirva. "hasta" (palabra) o "dura" (segundos) marcan el final.
- "x"/"y" en píxeles de 1080x1920; si no pones "y", se acomoda en la franja de títulos del perfil.
- Sonidos: salen solos según el tipo (perfil → sonidos). "sonido": "ninguno" o un nombre para cambiarlo.
- Títulos editoriales (Inter Black grande, una línea por renglón del texto, cada renglón entra con un pop):
  gancho (2-3 renglones, el último más corto y más grande; con "detras": true queda detrás de su cabeza),
  palabra (una palabra protagonista; "detras": true por defecto), tachado (la palabra aparece y una línea la tacha
  al terminar de decirla, con click; "tacha_en": otra palabra para tacharla después), cierre (renglones arriba,
  delante; "aparece": una palabra por renglón para que cada uno entre cuando lo dice). Esconden los subtítulos
  mientras están (menos tachado). Los tamaños y la altura se calculan solos para no salirse ni tapar la cara.
"""
import argparse, os, sys, re, unicodedata, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_json, save_json, carpeta
import detras as DET

ap = argparse.ArgumentParser()
ap.add_argument('trabajo'); ap.add_argument('--estilo', required=True); ap.add_argument('--emoji'); ap.add_argument('--publico')
a = ap.parse_args()
T = a.trabajo
tl = load_json(os.path.join(T, 'timeline.json')); W = tl['words']; D = tl.get('duration_real', tl['duration'])
plan = load_json(os.path.join(T, 'plan.json')); est = load_json(a.estilo)
cara = load_json(os.path.join(T, 'cara.json'), default={'top': 420, 'cx': 540})
snd = est.get('sonidos', {}); tit = est.get('titulos', {}); H = 1920
zona = tit.get('zona', [0.10, 0.28]); y_min, y_max = zona[0] * H + 60, min(zona[1] * H, cara['top'] - 40)
cuts = [c['t0_real'] if 't0_real' in c else c['t0'] for c in tl['clips']] + [D]
def caja(t0, t1):
    """Dónde está ella en ESE momento (cara.json → tramos, medidos cada segundo); si no hay medida, su lugar de siempre."""
    T_ = [r for r in cara.get('tramos', []) if t0 - 0.6 <= r[0] <= t1 + 0.6]
    if not T_:
        return {'cx': cara.get('cx', 540), 'top': cara.get('top', 420), 'bottom': cara.get('bottom', 1100),
                'izq': cara.get('izq', cara.get('cx', 540) - 190), 'der': cara.get('der', cara.get('cx', 540) + 190)}
    return {'cx': sorted(r[1] for r in T_)[len(T_) // 2], 'top': min(r[2] for r in T_) - 20, 'bottom': max(r[3] for r in T_) + 20,
            'izq': min(r[4] for r in T_), 'der': max(r[5] for r in T_)}
def choca(o, b):
    hw = o['tam'] / 2
    return o['x'] + hw > b['izq'] and o['x'] - hw < b['der'] and o['y'] + hw > b['top'] and o['y'] - hw < b['bottom']
movidos = []
TY = 0.035
EST = os.path.dirname(os.path.abspath(a.estilo))
MIS = {e['id']: e for e in load_json(os.path.join(EST, 'mis-efectos.json'), default={'efectos': []})['efectos']}
PROP = {p['kind']: p for p in est.get('efectos_propios', [])}
# dónde va un sticker o una animación (centro x, y y ancho en px de 1080x1920); los lados quedan a la altura de la cara, sin taparla
POS = {'arriba': (540, 330, 380), 'arriba izquierda': (230, 330, 320), 'arriba derecha': (850, 330, 320),
       'izquierda': (170, cara.get('cy', 700), 280), 'derecha': (910, cara.get('cy', 700), 280),
       'abajo': (540, 1560, 420), 'abajo izquierda': (230, 1560, 340), 'abajo derecha': (850, 1560, 340),
       'centro': (540, 960, 520), 'pantalla completa': (540, 960, 1080)}
SONIDO = {'titulo': 'inicio', 'flotante': 'lista', 'caja': 'lista', 'cta': 'lista', 'burbujas': 'lista', 'paso': 'paso', 'formula': 'paso',
          'checklist': 'paso', 'contador': 'paso', 'caja_escribe': 'escribir', 'paso_escribe': 'escribir', 'imagen': 'click'}
SONIDO.update({'gancho': 'inicio', 'palabra': 'lista', 'tachado': 'ninguno', 'cierre': 'ninguno'})
EDIT = ('gancho', 'palabra', 'tachado', 'cierre')
DURA = {'gancho': 2.4, 'palabra': 1.0, 'tachado': 2.5, 'cierre': 3.0, 'titulo': 4.5, 'flotante': 5, 'paso': 4, 'paso_escribe': 6, 'caja': 4.5, 'caja_escribe': 6, 'formula': 5, 'checklist': 5,
        'contador': 3.5, 'burbujas': 3.5, 'imagen': 6, 'cta': 5, 'sticker': 3}

def norm(s):
    s = unicodedata.normalize('NFD', s.lower()); s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ]', '', s)
def en_escena(w, esc):
    if esc is None: return True
    esc = str(esc); return w['escena'] == esc or w['escena'].split(' ')[0] == esc
problemas = []; problemas_suaves = []
def busca(word, esc=None, vez=1, despues=0.0):
    hits = [w for w in W if norm(w['w']) == norm(word) and en_escena(w, esc) and w['s'] >= despues - 0.01]
    if len(hits) < vez:
        # palabra de varias partes ("PDF," "tres-ingredientes"): prueba que empiece igual
        hits = [w for w in W if norm(w['w']).startswith(norm(word)) and en_escena(w, esc) and w['s'] >= despues - 0.01]
    if len(hits) < vez:
        problemas.append(f'no encontré la palabra "{word}"' + (f' en la escena {esc}' if esc else '')); return None
    return hits[vez - 1]

# ---------- títulos editoriales: medir renglones con su fuente de títulos ----------
def _fuente_titulos():
    fn = est.get('fuentes', {}).get('titulos')
    for c in ([os.path.join(carpeta(EST, 'fuentes'), fn)] if fn else []) + ([os.path.join(a.publico, 'fonts', fn)] if (fn and a.publico) else []) + [os.path.expanduser('~/.cvs-motor/fuentes/Inter-Bold.ttf')]:
        if c and os.path.exists(c): return c
    return None
FT = _fuente_titulos()
DETRAS_OK = DET.disponible()
_cab = {}
def cabeza():
    if 'y' not in _cab:
        y = DET.cabeza_top(os.path.join(T, 'base.mp4')) if DETRAS_OK and os.path.exists(os.path.join(T, 'base.mp4')) else None
        _cab['y'] = y if y else cara['top']
        print(f'La cabeza empieza en y≈{_cab["y"]} px')
    return _cab['y']
if DETRAS_OK and os.path.exists(os.path.join(T, 'base.mp4')):   # la medida real de su silueta manda sobre el detector de caras
    cara['top'] = cabeza(); y_max = min(zona[1] * H, cara['top'] - 40)
def _ancho(txt, size):
    from PIL import ImageFont
    return ImageFont.truetype(FT, int(size)).getlength(txt) if FT else len(txt) * size * 0.62
def lineas_de(k, txt, detras, tiempos):
    rs = [r.strip() for r in txt.split('\n') if r.strip()]
    n = len(rs)
    if k == 'gancho': caps = [100 + 90 * i / (n - 1) for i in range(n)] if n > 1 else [190]
    elif k == 'palabra': caps = [170] * n
    elif k == 'tachado': caps = [120] * n
    else: caps = [100] * n
    sizes = [min(c, 100 * 880 / max(1, _ancho(r, 100))) for r, c in zip(rs, caps)]
    top_cab = cabeza(); gap = 24; ch = 0.74
    if k == 'palabra':   # va con acercamiento: la cabeza sube y crece; que tape solo la parte de abajo de las letras
        z = est.get('movimiento', {}).get('escala', 1.1) if est.get('movimiento', {}).get('acercamientos') else 1.0
        cy = cara.get('cy', 900); top_cab = cy - (cy - top_cab) * z
    for _ in range(12):
        if detras: y_last = top_cab + (0.10 if k == 'gancho' else -0.12) * sizes[-1]
        else: y_last = top_cab - 40 - ch * sizes[-1] / 2
        ys = [y_last]
        for i in range(n - 2, -1, -1): ys.insert(0, ys[0] - ch * sizes[i + 1] / 2 - gap - ch * sizes[i] / 2)
        if ys[0] - ch * sizes[0] / 2 >= 235: break
        sizes = [x * 0.92 for x in sizes]
    return [{'text': r, 'size': round(sz), 'y': round(y), 't': round(tt, 3)} for r, sz, y, tt in zip(rs, sizes, ys, tiempos)]

O, Z, S = [], [], []
def sfx(name, t, dur=None):
    f = snd.get(name, name)
    if f and f != 'ninguno': S.append({'file': f, 't': round(max(0, t), 3), 'dur': None if dur is None else round(dur, 3)})

def copia_emoji(c):
    if not (a.emoji and a.publico) or unicodedata.category(c) != 'So': return
    code = format(ord(c), 'x'); dst = os.path.join(a.publico, 'emoji', code + '.png')
    for name in (code, code + '-fe0f'):
        src = os.path.join(a.emoji, name + '.png')
        if os.path.exists(src):
            os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy(src, dst); return
    problemas.append(f'no tengo imagen para el símbolo {c}; quítalo o cámbialo por un emoji')

for e in plan.get('efectos', []):
    e = dict(e); k = e['kind']
    if e.get('efecto'):   # uno de "Mis efectos"
        m = MIS.get(e['efecto'])
        if not m: problemas.append(f'no encontré "{e["efecto"]}" en Mis efectos (corre mis_efectos.py)'); continue
        if m['tipo'] == 'sonido': k = e['kind'] = 'sonido'; e.setdefault('sonido', m['archivo'])
        else:
            k = e['kind'] = m['tipo']; e['file'] = m['archivo']
            if m.get('mezcla'): e['mezcla'] = m['mezcla']
            if m['tipo'] == 'animacion': e.setdefault('dura', m.get('duracion', 2))
            e.setdefault('sonido', 'lista' if m['tipo'] == 'sticker' else 'ninguno')
    if k in PROP:
        e.setdefault('dura', PROP[k].get('dura', 4)); e.setdefault('sonido', PROP[k].get('sonido', 'ninguno'))
    if 't' in e: t0 = float(e['t'])
    else:
        w = busca(e['en'], e.get('escena'), e.get('vez', 1))
        if not w: continue
        t0 = w['s'] - 0.05
    t0 = max(0, t0)
    if 'hasta' in e:
        w2 = busca(e['hasta'], e.get('escena'), 1, despues=t0 + 0.1); t1 = (w2['s'] - 0.1) if w2 else t0 + DURA.get(k, 4)
    else:
        txt = e.get('text', '')
        t1 = t0 + e.get('dura', DURA.get(k, 4) + (len(txt) * TY if k.endswith('escribe') else 0))
    t1 = min(t1, D)
    if k == 'sonido':   # solo suena, no se ve nada
        sfx(e['sonido'], t0); continue
    o = {'kind': k, 'text': e.get('text', ''), 't0': round(t0, 3), 't1': round(t1, 3)}
    if k in EDIT:
        quiere = e.get('detras', k == 'palabra') and k in ('gancho', 'palabra')
        if quiere and k == 'palabra' and _ancho(e.get('text', '').split('\n')[-1], 170) < 560:
            quiere = False   # una palabra corta detrás de la cabeza casi no se lee: va delante, arriba
            problemas_suaves.append(f'"{e.get("text", "")[:20]}" es corta: la puse delante, arriba de la cabeza, para que se lea')
        if quiere and not DETRAS_OK:
            problemas_suaves.append(f'"{o["text"][:25]}": no puedo ponerlo detrás de su cabeza en esta compu (falta MediaPipe); va delante, arriba de la cabeza')
        det = bool(quiere and DETRAS_OK)
        rs = [r for r in o['text'].split('\n') if r.strip()]
        if k == 'gancho': tiempos = [t0 + 0.10 + 0.25 * i for i in range(len(rs))]
        elif k == 'cierre' and e.get('aparece'):
            tiempos = []
            for i, pal in enumerate(e['aparece'][:len(rs)]):
                w = busca(pal, e.get('escena'), 1, despues=t0 - 0.1); tiempos.append((w['s'] - 0.05) if w else t0 + 0.6 * i)
            tiempos += [t0 + 0.6 * i for i in range(len(tiempos), len(rs))]
        else: tiempos = [t0 + 0.12 * i for i in range(len(rs))]
        o['lineas'] = lineas_de(k, o['text'], det, tiempos); o['detras'] = det
        if e.get('color'): o['color'] = e['color']
        if k == 'tachado':
            vivos_t = [x for x in O if x['kind'] == 'tachado' and x['t0'] < t1 and x['t1'] > t0]
            yb = 300
            for l in o['lineas']: l['y'] = yb; yb += 140
            if vivos_t:   # se acomoda debajo del tachado anterior
                base_y = max(l['y'] for x in vivos_t for l in x['lineas']) + 140
                for l in o['lineas']: l['y'] = round(base_y); base_y += 140
                if o['lineas'][-1]['y'] + 0.37 * o['lineas'][-1]['size'] > cabeza() - 30:
                    problemas.append(f'"{o["text"][:25]}" ya no cabe arriba de la cabeza junto con el otro tachado; acórtalo o sepáralos en el tiempo')
            wt = busca(e['tacha_en'], e.get('escena'), 1, despues=t0) if e.get('tacha_en') else None
            if not wt and 'en' in e:
                w0 = busca(e['en'], e.get('escena'), e.get('vez', 1)); wt = {'s': w0['e'] + 0.05} if w0 else None
            o['tacha'] = round(wt['s'] if wt else t0 + 0.4, 3)
            sfx('click', o['tacha'])
    if e.get('oculta_subs') or (t0 < 0.5 and k in ('caja', 'caja_escribe', 'flotante', 'paso', 'paso_escribe', 'tachado', 'imagen')):
        o['oculta_subs'] = True   # el hook de apertura no compite con los subtítulos
    for f in ('x', 'items', 'image', 'n', 'file', 'tam', 'rot', 'mezcla'):
        if f in e: o[f] = e[f]
    for f, v in e.items():   # campos extra de un efecto propio
        if k in PROP and f not in o and f not in ('kind', 'en', 'escena', 'vez', 'hasta', 'dura', 't', 'sonido', 'posicion'): o[f] = v
    if k in ('sticker', 'animacion') or e.get('posicion'):
        px, py, pw = POS.get(e.get('posicion', 'arriba derecha'), POS['arriba derecha'])
        o.setdefault('x', px); o['y'] = e.get('y', py); o.setdefault('tam', pw)
        if e.get('posicion') == 'pantalla completa' and k == 'sticker':
            problemas.append(f'el sticker "{e.get("efecto")}" en pantalla completa taparía tu cara; elige otro lugar')
        bx = caja(t0, t1)
        if e.get('posicion') != 'pantalla completa' and 'y' not in e and choca(o, bx):
            # como en CapCut a mano: se pasa al lugar libre más cercano, del mismo lado si se puede
            orig = e.get('posicion', 'arriba derecha'); lado = 'izquierda' if 'izquierda' in orig else ('derecha' if 'derecha' in orig else '')
            orden = sorted(POS, key=lambda q: (lado not in q, abs(POS[q][1] - o['y'])))
            for q in orden:
                if q in ('pantalla completa', 'centro'): continue
                prueba = dict(o, x=POS[q][0], y=POS[q][1])
                if not choca(prueba, bx):
                    o['x'], o['y'] = POS[q][0], POS[q][1]; movidos.append(f'"{e.get("efecto", k)}" de {orig} a {q}'); break
            else:
                problemas.append(f'"{e.get("efecto", k)}" en {orig} tapa parte de la cara; hazlo más chico ("tam")')
    elif k in EDIT: pass
    elif 'y' in e: o['y'] = e['y']
    elif k not in ('burbujas', 'checklist'):
        # se acomoda en la franja de títulos, sin encimarse con otro texto que esté al mismo tiempo
        vivos = [x for x in O if x['t0'] < t1 and x['t1'] > t0 and 'y' in x and x['kind'] != 'burbujas']
        o['y'] = round(min(y_max, y_min + 95 * len(vivos)))
    if 'y' in o and k not in ('burbujas', 'checklist', 'sticker', 'animacion') and not e.get('posicion') and not o.get('detras'):
        tb = caja(t0, t1)['top']
        if o['y'] > tb - 40:
            if 'y' not in e and tb - 40 >= 270:
                movidos.append(f'"{o.get("text", "")[:30]}" subió de y={o["y"]} a y={tb - 40} (su cabeza en ese momento)'); o['y'] = tb - 40
            else:
                problemas.append(f'"{o.get("text", "")[:30]}" (y={o["y"]}) queda muy cerca de la cara (en ese momento empieza en y={tb}); súbelo')
    if k in ('sticker', 'animacion') and e.get('posicion') != 'pantalla completa':
        hw = o['tam'] / 2
        for x in O:
            if x['kind'] not in ('sticker', 'animacion', 'burbujas', 'checklist') and 'y' in x and x['t0'] < o['t1'] and x['t1'] > o['t0'] \
               and abs(x['y'] - o['y']) < hw + 60 and abs(x.get('x', 540) - o['x']) < hw + 470:
                problemas.append(f'"{e.get("efecto", k)}" se encima con el texto "{x["text"][:25]}"; cambia su posición, su tamaño o su momento'); break
    O.append(o)
    s = e.get('sonido', SONIDO.get(k))
    if s and s != 'ninguno':
        sfx(s, t0, len(o['text']) * TY if s == 'escribir' else None)
    if k == 'gancho' and e.get('sonido', 'x') != 'ninguno':
        for l in o['lineas'][1:]: sfx('lista', l['t'])
    if k in ('flotante', 'burbujas', 'checklist') and o.get('items'):
        for i in range(1, len(o['items'])): sfx(s or 'lista', t0 + i * (0.6 if k == 'checklist' else 0.35))
    for txt in [o['text']] + list(o.get('items') or []):
        for c in txt: copia_emoji(c)

for z in plan.get('acercamientos', []):
    if 't' in z: t = float(z['t'])
    else:
        w = busca(z['en'], z.get('escena'), z.get('vez', 1))
        if not w: continue
        t = w['s']
    t0 = max(0, t - 0.05); nc = min([c for c in cuts if c > t0 + 0.05], default=D); t1 = min(nc, t0 + z.get('dura', 3.0))
    Z.append({'t0': round(t0, 3), 't1': round(t1, 3), 'cut': abs(t1 - nc) < 1e-6})

fd = est.get('movimiento', {}).get('fundido_final', 0.75)
if snd.get('cierre') and snd.get('cierre') != 'ninguno' and not plan.get('sin_cierre'): sfx('cierre', D - max(fd or 0, 0.75))
O.sort(key=lambda o: o['t0'])
save_json(os.path.join(T, 'cues.json'), {'overlays': O, 'zooms': Z, 'sfx': S, 'duration': D})
print(f'{len(O)} efectos, {len(Z)} acercamientos, {len(S)} sonidos')
for o in O: print(f"  {o['t0']:7.2f}-{o['t1']:7.2f}  {o['kind']:12s} {o['text'][:50]!r}")
for p in movidos: print('MOVÍ para no tapar su cara: ' + p)
for p in problemas_suaves: print('AVISO: ' + p)
if problemas:
    print('REVISAR:'); [print('  - ' + p) for p in problemas]; sys.exit(2)
