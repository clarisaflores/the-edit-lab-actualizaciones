"""Rescata las palabras que la transcripción se comió cuando repites ("misma, misma cámara").

Uso: python3 repeticiones.py <carpeta_trabajo> [--modelo medium] [--todo]
Whisper, al transcribir un bloque largo, junta o se salta las repeticiones y los arranques en falso: la palabra repetida
no aparece en el texto y entonces nadie la corta. Aquí se vuelve a transcribir, SOLO y con un poco de contexto, cada pedazo
sospechoso (voz lenta para las palabras que trae, o una palabra demasiado larga). Si la segunda lectura trae las mismas
palabras MÁS alguna que repite a una vecina (la del propio pedazo, o la última del pedazo anterior), se adopta.
Las palabras rescatadas llevan "rep": true. Después hay que correr afinar_palabras.py (pedazos.py ya lo hace).
"""
import argparse, os, sys, re, unicodedata
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_wav, load_json, save_json, nfc

ap = argparse.ArgumentParser()
ap.add_argument('trabajo'); ap.add_argument('--modelo', default='medium'); ap.add_argument('--todo', action='store_true')
ap.add_argument('--idioma', default='es'); ap.add_argument('--pad', type=float, default=0.25)
a = ap.parse_args()
ruta = os.path.join(a.trabajo, 'pedazos.json')
data = load_json(ruta, default={'pedazos': []}); P = data['pedazos']
if not P or any('texto' not in p for p in P): print('Faltan pedazos por transcribir; salto.'); sys.exit(0)


def norm(t):
    t = unicodedata.normalize('NFD', t.lower()); t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ]', '', t)


def silabas(t):
    return max(1, len(re.findall(r'[aeiouáéíóúü]+', t.lower())))


def sospechoso(p):
    ws = p.get('palabras') or []
    if not ws: return False
    dur = p['off'] - p['on']
    if dur > 8: return False                       # un pedazo largo ya trae contexto; el riesgo está en los cortos
    sil = sum(silabas(w['w']) for w in ws)
    return dur / sil > 0.21 or any((w['e'] - w['s']) > 0.75 for w in ws)


cand = [p for p in P if a.todo or sospechoso(p)]
if not cand: print('Sin pedazos sospechosos.'); sys.exit(0)
from faster_whisper import WhisperModel
import numpy as np
model = WhisperModel(a.modelo, device='cpu', compute_type='int8', cpu_threads=(min(8, max(4, (os.cpu_count() or 4) - 2)) if os.environ.get('EDIT_LAB_LOCAL') else min(4, os.cpu_count() or 2)))
audios = {}; rescatadas = 0; tocados = 0
for p in cand:
    arch = p['archivo']
    if arch not in audios: audios[arch] = load_wav(os.path.join(a.trabajo, f"a{arch}.wav"))
    x, sr = audios[arch]
    s0 = max(0, p['on'] - a.pad); s1 = min(len(x) / sr, p['off'] + a.pad)
    try:
        segs, _ = model.transcribe(x[int(s0 * sr):int(s1 * sr)], language=a.idioma, beam_size=5, word_timestamps=True,
                                   condition_on_previous_text=False, vad_filter=False)
        nw = [{'w': nfc(w.word.strip()), 's': round(w.start + s0, 3), 'e': round(w.end + s0, 3)} for sg in segs for w in sg.words if w.word.strip()]
    except Exception as ex:
        print('pedazo', p['id'], 'sin segunda lectura:', ex); continue
    # solo las palabras cuyo centro cae dentro del pedazo (el contexto de los lados no es de este pedazo)
    nw = [w for w in nw if p['on'] - 0.08 <= (w['s'] + w['e']) / 2 <= p['off'] + 0.08]
    ow = p['palabras']
    if len(nw) <= len(ow): continue
    # ¿las viejas son subsecuencia de las nuevas?
    j = 0; usadas = set()
    for k, w in enumerate(nw):
        if j < len(ow) and norm(w['w']) == norm(ow[j]['w']): usadas.add(k); j += 1
    if j < len(ow): continue
    extras = [k for k in range(len(nw)) if k not in usadas]
    ant = [w['w'] for q in P if q['id'] < p['id'] and q['archivo'] == arch for w in q.get('palabras', [])][-6:]
    vecinas = [norm(w['w']) for w in nw] + [norm(t) for t in ant]
    ok = True
    for k in extras:
        n = norm(nw[k]['w'])
        otras = [norm(w['w']) for i, w in enumerate(nw) if i != k] + [norm(t) for t in ant]
        if not n or n not in otras: ok = False
    if not ok: continue
    nuevas = []
    for k, w in enumerate(nw):
        w = dict(w)
        if k in extras: w['rep'] = True; rescatadas += 1
        nuevas.append(w)
    print(f"pedazo {p['id']} ({p['on']:.2f}-{p['off']:.2f}): «{p['texto']}» -> «{' '.join(w['w'] for w in nuevas)}»")
    p['palabras'] = nuevas; p['texto'] = ' '.join(w['w'] for w in nuevas); tocados += 1
save_json(ruta, data)
with open(os.path.join(a.trabajo, 'pedazos.txt'), 'w', encoding='utf-8') as f:
    for p in P: f.write(f"#{p['id']:<4} [{p['archivo']}] {p['on']:8.2f}-{p['off']:8.2f}  {p.get('texto', '…pendiente')}\n")
print(f"{len(cand)} pedazos revisados, {tocados} corregidos, {rescatadas} palabras rescatadas.")
