---
name: instalar-the-edit-lab
description: Instala The Edit Lab de la clienta - su propia página de edición, sus carpetas, el motor y su editor en segundo plano. Usar cuando diga "instala mi The Edit Lab", "instala The Edit Lab", "configura mi Edit Lab", "reinstala mi Edit Lab" o "conecta mi carpeta del lab".
---

# Instalar The Edit Lab

Deja lista **su** página The Edit Lab, en **su** cuenta, conectada a **su** computadora. Habla en español, cálido y sencillo. No muestres rutas internas, comandos, nombres de herramientas ni errores técnicos: si algo falla, di qué significa para ella y qué hacer. Cada clienta tiene su propia página y su propia tarea; nunca uses datos, archivos ni páginas de otra persona.

`SK` = la carpeta de este skill (la ruta base que te dio el sistema). `PLUG` = dos carpetas arriba de `SK` (la raíz del plugin).

## 0. Revisar que se puede (sin instalar nada todavía)

1. **Computadora conectada:** tienen que existir las herramientas de su computadora (`mcp__remote-devices__…`: búscalas con ToolSearch). Si no aparecen, dile: "Abre este chat en la app de escritorio de Claude en tu computadora (Mac o Windows) y vuelve a escribir *instala mi The Edit Lab*." y termina.
2. **Su carpeta:** debe haber una carpeta conectada llamada **The Edit Lab** (`get_device_info` → `connectedFolders`). Si no existe, dile exactamente: "En tu computadora crea una carpeta llamada **The Edit Lab** (por ejemplo en Documentos). Luego, aquí junto al cuadro de mensaje, toca **+ → Agregar carpeta**, elígela y escríbeme *listo*." Espera.
3. **Red:** prueba con device_bash que se puede bajar algo pequeño (`curl -sI https://registry.npmjs.org`) y, en tu terminal, que funcionan `pip` y `npm`. Si la red está cerrada, dile: "En Claude ve a **Configuración → Capacidades** y activa el acceso a la red con *Todos los dominios*. Luego escríbeme *listo*." Espera.
4. **Tareas programadas:** carga con ToolSearch `create_trigger` (de claude-code-remote). Si no existe, dile que su plan o su organización no permite tareas programadas y que hace falta para que la página edite sola; termina.

Dile en una línea lo que vas a hacer: "Voy a crear tus carpetas, tu página The Edit Lab y tu editor. Te van a salir 2 o 3 tarjetas para aprobar."

## 1. Sus carpetas

En `device_bash`, dentro de su carpeta The Edit Lab (`$HOME/mnt/The Edit Lab`), crea solo las que falten (nunca borres ni muevas nada que ya esté):
```
Reels/Reel 1
Reels/Reel 1/Hooks
Brand Assets/01 LOGO & FONTS
Brand Assets/02 COLORS
Brand Assets/03 BACKGROUNDS
Brand Assets/04 STICKERS & GRAPHICS
Brand Assets/05 EDITING REFERENCES
Brand Assets/06 MY CONTENT & B-ROLL
Brand Assets/07 SOUNDS EFFECTS
Brand Assets/09 MUSIC
```
Guarda la ruta real de su carpeta en la computadora (la de `connectedFolders`, por ejemplo `/Users/ana/Documents/The Edit Lab`) como `RAIZ`.

## 2. Su página

1. Si ya tiene una página The Edit Lab (lista sus artifacts con `Artifact` action `list` y busca el título "The Edit Lab"), pregúntale si quiere **reconectar** esa (no se pierde nada) o crear una nueva. Si reconecta, salta al paso 3 con esa `url`.
2. Si no: carga el skill `artifact-capabilities` y publica `SK/assets/pagina.html` con `Artifact` (action `publish`, `title` "The Edit Lab", `icon` "video") y estas capacidades:
   `{"db": {}, "assets": {}, "downloads": {}, "mcp": {"servers": [{"server": "Claude Code Remote", "tools": ["fire_trigger", "update_trigger"]}]}}`.
   Guarda su `url` como `PAGINA`. Si te sale una tarjeta para aprobar, dile que la apruebe.

## 3. Su editor (motor e instrucciones)

1. `python3 SK/scripts/motor.py PLUG <carpeta de trabajo>/motor.json` y súbelo a su página (`publish`, `url` = PAGINA, `asset: true`) → `motorId`.
2. Sube `SK/assets/PROCESADOR.md` igual → `procesadorId`.
3. Crea la tarea con `create_trigger`:
   - `name`: "The Edit Lab · editor"
   - `requires_local_device`: true, `folders`: [RAIZ], `initiation`: "human_request", sin horario (la página la despierta).
   - `prompt` (cambia PAGINA y RAIZ por los valores reales):
     > Eres la editora de video en segundo plano de The Edit Lab de esta clienta. Carga con ToolSearch las herramientas Artifact, ArtifactData y las de su computadora (mcp__remote-devices__: get_device_info, device_request_folder_access, device_list_dir, device_bash, device_stage_files, device_commit_files). Su página es PAGINA. Su carpeta de Reels es "RAIZ/Reels" (una carpeta por Reel; el resultado va en la subcarpeta "Resultado final" de cada Reel) y su carpeta de assets es "RAIZ/Brand Assets" (01 LOGO & FONTS, 02 COLORS, 03 BACKGROUNDS, 04 STICKERS & GRAPHICS, 05 EDITING REFERENCES, 06 MY CONTENT, 07 SOUNDS EFFECTS, 08 B-ROLL, 09 MUSIC). Nunca modifiques, renombres ni borres sus archivos originales. Lee con ArtifactData el documento studio/config de su página: motor.procesadorId es el id de tus instrucciones. Descárgalas con Artifact (action "read", url = su página, path = ese id) y síguelas COMPLETAS, de principio a fin, sin hacer preguntas: nadie va a contestar. Si después de este mensaje viene un JSON con el pedido, úsalo; si no, revisa qué hay pendiente como dicen tus instrucciones en el paso 0.
   - Guarda su id como `TAREA`. Dile que apruebe la tarjeta si aparece. Si el resultado dice que sus ejecuciones van a pedir permiso, dile en una línea que puede activar "Aprobar automáticamente" en la tarea (Programadas) para que la página edite sin detenerse.
4. Escribe en su página (`ArtifactData`, `update` o `set` si no existe, colección `studio`, documento `config`):
   `{"motor": {"procesadorId": …, "motorId": …, "tareaCompu": TAREA, "version": "<versión del plugin>"}, "carpeta": "RAIZ/Reels", "carpetaAssets": "RAIZ/Brand Assets", "carpetaEstado": "Conectada", "look": "editorial"}`.
   Si ya había un `config` (reconexión), conserva todo lo demás: solo cambia esos campos.

## 4. Revisar y abrir

Lee `studio/config` de vuelta y comprueba que tiene `motor.tareaCompu`, `motor.procesadorId`, `motor.motorId` y `carpeta`. Abre su página (`Artifact` action `open`). No digas que quedó instalado si algo de esto falló.

## 5. Qué le dices al final (corto)

- "Tu The Edit Lab está listo." y que su página quedó abierta (también está en sus Artefactos; puede fijarla).
- En la página, **Mis Brand Assets** se carga solo desde su carpeta *The Edit Lab → Brand Assets* (01 LOGO & FONTS, 02 COLORS… 09 MUSIC). Si agrega archivos, toca **Revisar mis carpetas**.
- **Mi marca**: con su carpeta Brand Assets ya llena, contesta los 12 pasos (o toca «No sé: usa la recomendada») y toca **Crear mi marca**: Claude hace su Brand Kit y su Editing System. Los revisa y los aprueba. Si edita para clientes, agrega cada uno como marca de cliente.
- **Mis instrucciones**: sube tu *YOUR EDITING SYSTEM* y *THE EDIT METHOD* (en .md si los tienes, o PDF) y, si quieres, escribe tus reglas.
- **Para editar**: pon tu material en *The Edit Lab → Reels → Reel 1*, entra a **Editar Reel → Ver mis Reels**, elige el formato del video (hablando a cámara, tutorial, voiceover o montaje con textos) y sigue las 5 fases.
- Su compu debe estar prendida, con la app de Claude abierta, mientras Claude trabaja.

## Si algo falla

- Una tarjeta rechazada: explícale para qué era y ofrece repetir solo ese paso.
- Repetir la instalación es seguro: no borra sus carpetas ni sus archivos; si ya tiene página, se reconecta.
