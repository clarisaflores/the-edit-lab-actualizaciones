/* The Edit Lab · modo local: la página habla con tu Mac en vez de con la nube. */
(function () {
  function j(url, opt) {
    return fetch(url, opt).then(function (r) {
      return r.json().then(function (x) {
        if (!r.ok) { var e = new Error(x.error || ('error ' + r.status)); e.code = x.code || ('http_' + r.status); throw e; }
        return x;
      });
    });
  }
  function post(url, body) { return j(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }
  function copia(x) { return x == null ? x : JSON.parse(JSON.stringify(x)); }

  /* --- avisos de cambios (la página se actualiza sola cuando Claude escribe) --- */
  var oyentes = [], ultimaV = -1;
  function vigilar() {
    j('/api/db/v').then(function (x) {
      if (x.v !== ultimaV) { ultimaV = x.v; oyentes.forEach(function (f) { try { f(); } catch (e) {} }); }
    }).catch(function () {}).then(function () { setTimeout(vigilar, 1500); });
  }
  setTimeout(vigilar, 1500);

  function snapDoc(path, x) {
    return { id: path.split('/').pop(), exists: !!x.exists, data: function () { return copia(x.data); } };
  }
  function snapCol(x) {
    return { docs: (x.docs || []).map(function (d) { var id = d.id; var o = copia(d); delete o.id; return { id: id, data: function () { return copia(o); } }; }) };
  }
  function docRef(path) {
    return {
      id: path.split('/').pop(), path: path,
      get: function () { return j('/api/db/doc?path=' + encodeURIComponent(path)).then(function (x) { return snapDoc(path, x); }); },
      set: function (d) { return post('/api/db', { op: 'set', path: path, data: d }); },
      update: function (d) { return post('/api/db', { op: 'update', path: path, data: d }); },
      delete: function () { return post('/api/db', { op: 'delete', path: path }); },
      onSnapshot: function (cb) {
        var f = function () { docRef(path).get().then(cb).catch(function () {}); };
        oyentes.push(f); f();
        return function () { oyentes = oyentes.filter(function (g) { return g !== f; }); };
      }
    };
  }
  function colRef(col) {
    return {
      get: function () { return j('/api/db/col?col=' + encodeURIComponent(col)).then(snapCol); },
      add: function (d) { return post('/api/db', { op: 'add', path: col, data: d }).then(function (x) { return docRef(x.path); }); },
      doc: function (id) { return docRef(col + '/' + id); },
      onSnapshot: function (cb) {
        var f = function () { colRef(col).get().then(cb).catch(function () {}); };
        oyentes.push(f); f();
        return function () { oyentes = oyentes.filter(function (g) { return g !== f; }); };
      }
    };
  }
  var db = { doc: docRef, collection: colRef };

  var assets = {
    upload: function (blob) {
      return fetch('/api/assets', { method: 'POST', body: blob, headers: { 'X-Tipo': blob.type || 'application/octet-stream', 'X-Nombre': encodeURIComponent(blob.name || '') } })
        .then(function (r) { if (!r.ok) throw { code: 'upload_failed' }; return r.json(); });
    },
    list: function () { return j('/api/assets'); },
    delete: function (id) { return post('/api/assets/borrar', { id: id }); },
    url: function (id) { return '/_blob/' + id; }
  };

  var downloads = {
    save: function (o) {
      var url = URL.createObjectURL(o.data);
      var a = document.createElement('a');
      a.href = url; a.download = o.filename || 'archivo';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
      return Promise.resolve({ ok: true });
    }
  };

  /* Despertar a la editora: en tu Mac es Claude Code, corriendo en esta carpeta. */
  var mcp = {
    callTool: function (server, tool, args) {
      var texto = (args && args.text) || null;
      return post('/api/claude', { tool: tool, text: texto }).then(function (x) { return { payload: x.payload }; });
    }
  };

  /* --- licencia: esta copia es de una sola persona --- */
  function licencia() {
    j('/api/licencia').then(function (x) { if (x.ok) { sello(x); var a = document.getElementById('lab-act'); if (a) a.remove(); } else { pantalla(); if (x.cancelada) { var e = document.getElementById('la-e'); if (e) e.textContent = x.error; } } }).catch(function () {});
  }
  function sello(x) {
    var b = document.getElementById('lab-lic');
    if (!b) { b = document.createElement('div'); b.id = 'lab-lic'; document.body.appendChild(b); }
    b.textContent = 'Licencia #' + x.n + ' · ' + x.correo;
    b.style.cssText = 'position:fixed;left:14px;bottom:10px;z-index:5;font:600 11px/1.2 Poppins,system-ui,sans-serif;color:#9B7E74;opacity:.75;pointer-events:none';
  }
  function pantalla() {
    if (document.getElementById('lab-act')) return;
    var d = document.createElement('div'); d.id = 'lab-act';
    d.innerHTML = '<div class="la-c" role="dialog" aria-modal="true" aria-labelledby="la-t"><div class="la-star">✦</div><h1 id="la-t">Activa tu The Edit Lab</h1>' +
      '<p>Escribe el correo con el que compraste y la clave que te llegó. Solo se hace una vez.</p>' +
      '<label>Tu correo<input id="la-c" type="email" autocomplete="email" placeholder="tu@correo.com"></label>' +
      '<label>Tu clave<textarea id="la-k" rows="4" placeholder="EDLAB-…" spellcheck="false"></textarea></label>' +
      '<p id="la-e" class="la-e" role="alert"></p><button type="button" id="la-b">Activar</button>' +
      '<p class="la-n">Tu licencia es personal: no se puede compartir, copiar ni revender.</p></div>';
    var st = document.createElement('style');
    st.textContent = '#lab-act{position:fixed;inset:0;z-index:999;background:#F7F1E8;display:grid;place-items:center;padding:20px;font-family:Poppins,system-ui,sans-serif;color:#000}' +
      '#lab-act .la-c{width:min(460px,100%);background:#FFFDF5;border:1px solid #EADCCB;border-radius:24px;padding:32px;display:flex;flex-direction:column;gap:14px;box-shadow:0 20px 50px rgba(59,36,35,.08)}' +
      '#lab-act .la-star{color:#CF8199;font-size:26px}#lab-act h1{margin:0;font-family:Inter,system-ui,sans-serif;font-weight:800;letter-spacing:-.02em;font-size:26px}#lab-act p{margin:0;font-size:14px;line-height:1.5}' +
      '#lab-act label{display:flex;flex-direction:column;gap:6px;font-size:13px;font-weight:600}#lab-act input,#lab-act textarea{font:inherit;font-size:14px;font-weight:400;padding:12px;border:1px solid #E2D2C2;border-radius:12px;background:#fff;color:inherit}' +
      '#lab-act textarea{font-family:ui-monospace,Menlo,monospace;font-size:12px;resize:vertical}#lab-act input:focus,#lab-act textarea:focus{outline:2px solid #CF8199;outline-offset:1px}' +
      '#lab-act button{min-height:48px;border:1px solid #E7DCBB;border-radius:99px;background:#EEE6CE;color:#000;box-shadow:0 8px 18px rgba(120,100,50,.13);font:600 15px Poppins,system-ui,sans-serif;cursor:pointer}#lab-act button:disabled{opacity:.6}' +
      '#lab-act .la-e{color:#B04A5A;min-height:1em}#lab-act .la-n{font-size:12px;color:#6E6466}';
    document.head.appendChild(st); document.body.appendChild(d);
    var btn = document.getElementById('la-b');
    btn.onclick = function () {
      var c = document.getElementById('la-c').value, k = document.getElementById('la-k').value, e = document.getElementById('la-e');
      if (!c.trim() || !k.trim()) { e.textContent = 'Escribe tu correo y tu clave.'; return; }
      btn.disabled = true; btn.textContent = 'Revisando…'; e.textContent = '';
      post('/api/licencia', { correo: c, clave: k }).then(function (x) {
        if (x.ok) { d.remove(); sello(x); } else { e.textContent = x.error || 'No pude activar esa clave.'; }
      }).catch(function () { e.textContent = 'No pude conectar con The Edit Lab. ¿Sigue abierta su ventana?'; })
        .then(function () { btn.disabled = false; btn.textContent = 'Activar'; });
    };
    setTimeout(function () { document.getElementById('la-c').focus(); }, 50);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', licencia); else licencia();
  setInterval(licencia, 30 * 60 * 1000);

  var caps = { db: db, assets: assets, downloads: downloads, mcp: mcp };
  window.claude = { use: function (name) { return Promise.resolve(caps[name] || null); }, local: true };
})();
