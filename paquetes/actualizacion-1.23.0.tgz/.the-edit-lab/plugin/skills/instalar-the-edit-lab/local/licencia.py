#!/usr/bin/env python3
"""The Edit Lab · licencia personal. Solo biblioteca estándar.

Cada copia de The Edit Lab se activa con una clave hecha para UNA persona (su correo).
La clave está firmada por The Clari Edit: no se puede inventar ni cambiar de dueña.
La página muestra siempre a nombre de quién está la licencia, y cada Reel que sale
lleva ese número de licencia guardado dentro del MP4.

  python3 licencia.py estado                 {"ok": true, "correo": ..., "n": ...}
  python3 licencia.py activar <correo> <clave>
"""
import base64, hashlib, json, os, sys, time

# Llave PÚBLICA de The Clari Edit (solo sirve para comprobar claves, no para hacerlas).
N = int('f053e91b0da0c8701be522fbc645bc575fc68ba693c715aaa5955a36a3dad52f1e29325aaf4140517293fedecc4fd7ab3baa8a408d13e492e88d8fafdfab32f0d4b84faabee2ff52622e7c1d4a9ba59f6059f833e2f5b178d7edecee0c44df969656a77905cabd119afea4e4d0859dd8cd062360bc9e12e8240caa69b6d59c7baa18b4bc200435e0fa5a614db926f38506a809841c59d949b99e676c835e59b1eb3a0ac7081dcaaa945406b13c130d84869cbc31e46e80d1625a4fe2db6f4216f8d9179a0fe4b417198ab21f3866416b47b11f50fe53217030daa0225bb292feda17384fc142c23d180272cffa15cbdfbe901b7891997c6b27fffa1a58193123', 16)
E = 65537


def _b32d(s):
    s = s.strip().upper().replace('-', '')
    return base64.b32decode(s + '=' * (-len(s) % 8))


def _num(h):
    return int.from_bytes(hashlib.sha256(h).digest(), 'big')


def verificar(correo, clave):
    """Devuelve los datos de la licencia si la clave es válida para ese correo; si no, None."""
    try:
        clave = ''.join(clave.split())
        if clave.upper().startswith('EDLAB'):
            clave = clave[5:]
        clave = clave.strip('-')
        cuerpo, _, firma = clave.partition('.')
        datos = _b32d(cuerpo)
        s = int.from_bytes(_b32d(firma), 'big')
        if pow(s, E, N) != _num(b'the-edit-lab|' + datos):
            return None
        x = json.loads(datos.decode())
        if x.get('c'):   # clave hecha para un correo: solo sirve con ese correo
            if x['c'].strip().lower() != (correo or '').strip().lower():
                return None
        elif '@' not in (correo or ''):   # clave de la tienda: se queda a nombre del correo con que se activa
            return None
        else:
            x['c'] = correo.strip().lower()
        return x
    except Exception:
        return None


def _archivo():
    est = os.path.abspath(os.environ.get('EDIT_LAB_ESTUDIO') or os.getcwd())
    return os.path.join(est, '.the-edit-lab', 'licencia.json')


def _sin_licencia():
    # Ya no existe un «modo de pruebas» que se active con un archivo: cualquiera podría crearlo y usar el lab sin licencia.
    return False


def _canceladas():
    """Licencias que The Clari Edit canceló (copias compartidas o revendidas). Se baja sola de su GitHub."""
    try:
        with open(os.path.join(os.path.dirname(_archivo()), 'datos', 'licencias-canceladas.json'), encoding='utf-8') as f:
            j = json.load(f)
        return set(str(n) for n in (j.get('numeros') or [])), set(c.strip().lower() for c in (j.get('correos') or []))
    except Exception:
        return set(), set()


def estado():
    if _sin_licencia():
        return {'ok': True, 'correo': 'modo de pruebas', 'nombre': '', 'n': 'prueba', 'desde': ''}
    try:
        with open(_archivo(), encoding='utf-8') as f:
            g = json.load(f)
        x = verificar(g.get('correo'), g.get('clave'))
        if x:
            nums, correos = _canceladas()
            if str(x.get('n')) in nums or x['c'] in correos:
                return {'ok': False, 'cancelada': True, 'correo': x['c'], 'n': x.get('n'),
                        'error': 'Esta licencia de The Edit Lab fue cancelada. Si crees que es un error, escribe a theclariedit@gmail.com.'}
            return {'ok': True, 'correo': x['c'], 'nombre': x.get('a', ''), 'n': x.get('n'), 'desde': x.get('f')}
    except Exception:
        pass
    return {'ok': False}


def activar(correo, clave):
    x = verificar(correo, clave)
    if not x:
        return {'ok': False, 'error': 'No pude activar con esos datos. Revisa que el correo sea el de tu compra y que la clave esté completa (empieza con EDLAB-).'}
    p = _archivo()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f:
        json.dump({'correo': correo.strip(), 'clave': ''.join(clave.split()), 'activada': time.strftime('%Y-%m-%d')}, f, ensure_ascii=False, indent=1)
    return estado()


if __name__ == '__main__':
    a = sys.argv[1:]
    if a[:1] == ['activar'] and len(a) >= 3:
        r = activar(a[1], a[2])
    else:
        r = estado()
    print(json.dumps(r, ensure_ascii=False))
    sys.exit(0 if r.get('ok') else 1)
