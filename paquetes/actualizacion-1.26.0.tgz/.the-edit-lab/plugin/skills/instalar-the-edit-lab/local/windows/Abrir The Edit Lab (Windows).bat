@echo off
rem The Edit Lab - abre tu pagina en Windows (doble clic). Deja esta ventana abierta mientras editas.
chcp 65001 >nul
cd /d "%~dp0"
title The Edit Lab - deja esta ventana abierta
set "PY=%USERPROFILE%\.cvs-motor\venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Primero instala The Edit Lab: doble clic en "Instalar The Edit Lab (Windows).bat".
  pause
  exit /b 1
)
set "EDIT_LAB_ESTUDIO=%CD%"
set "PYTHONUTF8=1"
set "PATH=%USERPROFILE%\.cvs-motor\venv\Scripts;%USERPROFILE%\.cvs-motor\bin;%USERPROFILE%\.local\bin;%LOCALAPPDATA%\Microsoft\WinGet\Links;%ProgramFiles%\nodejs;%ProgramFiles%\Git\bin;%PATH%"
"%PY%" ".the-edit-lab\plugin\skills\instalar-the-edit-lab\local\lab.py" servir
echo.
pause
