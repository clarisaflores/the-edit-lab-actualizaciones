#!/bin/bash
# The Edit Lab · instalación en la computadora (Mac o Windows con Git Bash).
# Uso: bash instalar-local.sh "<carpeta The Edit Lab>"
# Es seguro repetirla: no borra nada tuyo y no vuelve a bajar lo que ya está.

di()    { printf "\n\033[1m✦ %s\033[0m\n" "$1"; }
falla() { printf "\n\033[31m✗ %s\033[0m\nSi no sabes qué hacer, abre Claude Code en tu carpeta The Edit Lab y escribe: revisa mi instalación\n" "$1"; exit 1; }

case "$(uname -s)" in
  Darwin) OS=mac ;;
  MINGW*|MSYS*|CYGWIN*) OS=win ;;
  *) falla "The Edit Lab funciona en Mac y en Windows." ;;
esac

EST_IN="${1:?falta la carpeta The Edit Lab}"
[ "$OS" = win ] && EST_IN="$(cygpath -u "$EST_IN")"
EST="$(cd "$EST_IN" && pwd)" || falla "No encuentro tu carpeta The Edit Lab."
LAB="$EST/.the-edit-lab"
PLUG="$LAB/plugin"
M="$HOME/.cvs-motor"
LOG="$LAB/instalacion.log"
mkdir -p "$LAB" "$M/bin"
[ -d "$PLUG/skills" ] || falla "No encuentro .the-edit-lab/plugin. Vuelve a copiar la carpeta The Edit Lab completa."
: > "$LOG"

echo "THE EDIT LAB ✦ instalación ($([ $OS = mac ] && echo Mac || echo Windows))"
echo "La primera vez tarda entre 10 y 20 minutos. Después ya no hace falta: todo queda guardado en tu computadora."

# 0 · Tus carpetas (solo crea las que falten; nunca mueve ni borra nada)
for d in "Reels" "Mis efectos" "Brand Assets/01 LOGO & FONTS" "Brand Assets/02 COLORS" "Brand Assets/03 BACKGROUNDS" \
         "Brand Assets/04 STICKERS & GRAPHICS" "Brand Assets/05 EDITING REFERENCES" "Brand Assets/06 MY CONTENT" \
         "Brand Assets/07 SOUNDS EFFECTS" "Brand Assets/08 B-ROLL" "Brand Assets/09 MUSIC"; do
  mkdir -p "$EST/$d"
done

# 1 · Programas base
if [ $OS = mac ]; then
  di "1/5 · Revisando Homebrew (el instalador de programas de Mac)"
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$("$b" shellenv)"; done
  if ! command -v brew >/dev/null; then
    echo "Hace falta Homebrew. Te va a pedir la CONTRASEÑA de tu Mac (al escribirla no se ven las letras, es normal)."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || falla "No se pudo instalar Homebrew."
    for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$("$b" shellenv)"; done
  fi
  command -v brew >/dev/null || falla "Homebrew no quedó instalado."
  grep -q "brew shellenv" "$HOME/.zprofile" 2>/dev/null || echo "eval \"\$($(command -v brew) shellenv)\"" >> "$HOME/.zprofile"
  di "2/5 · Instalando ffmpeg, node y python (solo lo que falte)"
  for f in ffmpeg node python@3.12; do brew list "$f" >/dev/null 2>&1 || brew install "$f" >>"$LOG" 2>&1 || falla "No se pudo instalar $f."; done
  PY="$(brew --prefix python@3.12)/bin/python3.12"
  VPY="$M/venv/bin/python3"
else
  di "1/5 · Revisando winget (el instalador de programas de Windows)"
  command -v winget >/dev/null || falla "No encuentro winget. Actualiza 'Instalador de aplicación' desde Microsoft Store y vuelve a intentar."
  di "2/5 · Instalando ffmpeg, node y python (solo lo que falte). Si Windows pregunta si permites cambios, di que Sí."
  W="winget install -e --silent --accept-source-agreements --accept-package-agreements --id"
  command -v ffmpeg >/dev/null || $W Gyan.FFmpeg >>"$LOG" 2>&1
  command -v node   >/dev/null || $W OpenJS.NodeJS.LTS >>"$LOG" 2>&1
  PY=""
  for p in "$LOCALAPPDATA/Programs/Python/Python312/python.exe" "/c/Program Files/Python312/python.exe"; do
    p="$(cygpath -u "$p" 2>/dev/null || echo "$p")"; [ -x "$p" ] && PY="$p" && break
  done
  if [ -z "$PY" ]; then
    $W Python.Python.3.12 >>"$LOG" 2>&1
    for p in "$LOCALAPPDATA/Programs/Python/Python312/python.exe" "/c/Program Files/Python312/python.exe"; do
      p="$(cygpath -u "$p" 2>/dev/null || echo "$p")"; [ -x "$p" ] && PY="$p" && break
    done
  fi
  [ -n "$PY" ] || falla "No encuentro Python 3.12 después de instalarlo. Cierra esta ventana y vuelve a abrir el instalador."
  # Lo recién instalado no aparece hasta abrir otra ventana: lo agregamos a mano para esta instalación.
  for d in "/c/Program Files/nodejs" "$(cygpath -u "$LOCALAPPDATA")/Microsoft/WinGet/Links" "$(cygpath -u "$APPDATA")/npm"; do
    [ -d "$d" ] && export PATH="$d:$PATH"
  done
  if ! command -v ffmpeg >/dev/null; then
    FF="$(ls -d "$(cygpath -u "$LOCALAPPDATA")"/Microsoft/WinGet/Packages/Gyan.FFmpeg*/ffmpeg-*/bin 2>/dev/null | head -1)"
    [ -n "$FF" ] && export PATH="$FF:$PATH"
  fi
  command -v ffmpeg >/dev/null || falla "No encuentro ffmpeg después de instalarlo. Cierra esta ventana y vuelve a abrir el instalador."
  command -v node   >/dev/null || falla "No encuentro node después de instalarlo. Cierra esta ventana y vuelve a abrir el instalador."
  VPY="$M/venv/Scripts/python.exe"
fi

# Python propio de The Edit Lab (aparte de cualquier otro Python de la computadora, para que nada choque)
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
[ -x "$VPY" ] || "$PY" -m venv "$M/venv" >>"$LOG" 2>&1 || falla "No se pudo preparar el Python de The Edit Lab."
for n in python3 python; do
  rm -f "$M/bin/$n"
  printf '#!/bin/bash\nexec "%s" "$@"\n' "$VPY" > "$M/bin/$n"; chmod +x "$M/bin/$n"
done
export PATH="$M/bin:$HOME/.local/bin:$PATH" PYTHONUTF8=1
PERFIL="$HOME/.zprofile"; [ $OS = win ] && PERFIL="$HOME/.bashrc"
grep -q ".cvs-motor/bin" "$PERFIL" 2>/dev/null || echo 'export PATH="$HOME/.cvs-motor/bin:$PATH" PYTHONUTF8=1' >> "$PERFIL"

# Tus skills de edición para Claude Code en esta carpeta (ruta sin espacios para que los comandos no fallen)
rm -rf "$HOME/.the-edit-lab-plugin"
if [ $OS = mac ]; then ln -sfn "$PLUG" "$HOME/.the-edit-lab-plugin"; else cp -R "$PLUG" "$HOME/.the-edit-lab-plugin"; fi
mkdir -p "$EST/.claude/skills"
for s in editar-video ajustar-video crear-efecto crear-mi-estilo preparar-estudio reportar-problema; do
  rm -rf "$EST/.claude/skills/$s"; cp -R "$PLUG/skills/$s" "$EST/.claude/skills/$s"
  python3 - "$EST/.claude/skills/$s/SKILL.md" <<'PYEOF'
import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read().replace('${CLAUDE_PLUGIN_ROOT}', '$HOME/.the-edit-lab-plugin')
open(p, 'w', encoding='utf-8').write(s)
PYEOF
done
# Instrucciones para Claude Code (solo si todavía no tienes las tuyas)
[ -f "$EST/CLAUDE.md" ] || cp "$PLUG/skills/instalar-the-edit-lab/local/CLAUDE_PLANTILLA.md" "$EST/CLAUDE.md"

# 3-4 · Motor de edición (se guarda en tu computadora, no se vuelve a descargar)
I="$PLUG/skills/preparar-estudio/scripts/instalar.sh"
di "3/5 · Motor de edición: programas de voz, cara y silueta"
bash "$I" "$EST" python 2>&1 | tee -a "$LOG" | grep -v -i "warn" | tail -3
di "4/5 · Fuentes, sonidos base y motor de animaciones"
bash "$I" "$EST" recursos >>"$LOG" 2>&1
bash "$I" "$EST" remotion 2>&1 | tee -a "$LOG" | tail -3
echo "Bajando el modelo que escucha tu voz (es lo más pesado, ~2 GB; solo esta vez)…"
bash "$I" "$EST" voz medium small 2>&1 | tee -a "$LOG" | grep -i "listo" || echo "AVISO: el modelo de voz se bajará en tu primera edición."

# 5 · Revisión final
di "5/5 · Revisando"
bash "$I" "$EST" revisar 2>&1 | tee -a "$LOG" | grep -E "LISTO|INCOMPLETO|FALTA|AVISO"
command -v claude >/dev/null || [ -x "$HOME/.local/bin/claude" ] || [ -x "$HOME/.local/bin/claude.exe" ] \
  || echo "AVISO: no encuentro Claude Code. Instálalo desde claude.com/claude-code y vuelve aquí."

if [ $OS = mac ]; then  # comando para abrir tu página desde cualquier terminal: the-edit-lab
  printf '#!/bin/bash\nexec "%s/Abrir The Edit Lab.command"\n' "$EST" > "$M/bin/the-edit-lab"; chmod +x "$M/bin/the-edit-lab"
  chmod +x "$EST"/*.command 2>/dev/null
fi
date +%s > "$LAB/instalado"
echo
echo "✦ ¡Listo! The Edit Lab ya vive en tu computadora."
if [ $OS = mac ]; then echo "Para editar: doble clic en «Abrir The Edit Lab.command» (o escribe the-edit-lab en la terminal)."
else echo "Para editar: doble clic en «Abrir The Edit Lab (Windows).bat»."; fi
