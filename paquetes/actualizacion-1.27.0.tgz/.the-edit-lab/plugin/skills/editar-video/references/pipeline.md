# Cómo funciona el motor (y por qué)

Cada paso trae lo que sale mal si se hace de la forma obvia. Los scripts ya lo resuelven; esto sirve para decidir bien y para arreglar casos raros.

## 1. Orientación (`preparar.py`)
- Los teléfonos guardan el giro como dato y ffmpeg lo aplica solo. Pero algunas cámaras graban acostado sin ese dato: el script prueba si la cara aparece al girar el cuadro. Si se equivoca, fuerza `--girar si|no`.
- Hace dos audios por archivo: el original (para transcribir) y uno sin ruido con `arnndn` (para medir dónde está la voz de verdad).

## 2. Pedazos y repeticiones (`pedazos.py`)
- Una transcripción normal junta "si tienes… si tienes… si tienes una cuenta" en una sola frase y esconde las repeticiones. Por eso el audio limpio se parte en pedazos de voz (umbral −26 dB, huecos de 0.12 s) y cada pedazo se transcribe solo.
- Sin `initial_prompt` (en pedazos cortos el modelo lo repite como si se hubiera dicho) y sin filtro VAD (se come frases enteras).
- Ruidos de casa, niños, mascotas o la calle salen como pedazos con textos raros ("¡Ah!", "Gracias", palabras en inglés): no son tomas.
- Memoria: el modelo `medium` usa unos 3 GB. Con menos RAM, `--modelo small`.

## 3. Elegir tomas (`tomas.json` → `linea_tiempo.py`)
- La persona repite cada frase hasta que le sale; normalmente la buena es la ÚLTIMA completa.
- Arranques en falso dentro de un mismo pedazo: recórtalos con `desde_palabra`.
- Bordes: los tiempos de las palabras de la transcripción empiezan tarde. El script busca el arranque suave real de la voz (−38 dB en el audio limpio) sin pasar de la mitad del silencio con el pedazo vecino, así no se come el inicio de las palabras ni mete el final de la toma repetida.
- Pausas internas de `--pausa` segundos o más se recortan dejando 0.06 s a cada lado (por defecto 0.12 s: sin pausas, solo la respiración mínima).
- Subtítulos: quita los "..." de la transcripción y pone mayúscula al inicio de cada oración y escena. Revisa el texto impreso: es exactamente lo que saldrá en pantalla. Para una palabra compuesta mal escrita que no se arregla con `correcciones`, edita `timeline.json → words` a mano.

## 4. Corte (`cortar.py`)
- Vertical 1080×1920 a 30 fps, escalado para cubrir sin deformar (`--acerca` acerca un poco el encuadre).
- Cada corte se ajusta a cuadros exactos y su audio se rellena a esa misma duración: si no, la voz se adelanta y los subtítulos se descuadran.
- La unión se re-codifica limpia (`setpts`, GOP 15, sin B-frames, sin pista de datos). Si no, Remotion falla con "No frame found at position".

## 5. Cara (`cara.py`)
- Mide el centro de la cara y dónde empieza la cabeza. Todo texto va arriba de `top − 40` px (o en la zona que diga su estilo, siempre sin tocar la cara). Los acercamientos se centran en la cara.

## 6. Efectos (`plan.json` → `cues.py`)
- **Reglas de ritmo de todos los Reels** (cualquier estilo, cualquier marca): (1) **texto desde el primer segundo**: el hook escrito ya está en pantalla en 0.0 s, sin intro, logo ni silencio antes; (2) **nunca más de ~4 s sin que algo cambie** en pantalla (un corte, un acercamiento, un texto, una imagen), salvo un momento emocional que pida calma; (3) **acercamientos rectos**: siempre centrados en su cara, entran y salen en línea recta, sin desplazarse de lado ni cortar su cabeza; (4) **sin pausas**: entre frases no queda silencio, solo la respiración mínima para que no suene cortado (`ritmo.pausa_max`, por defecto 0.12 s); la única pausa que se deja es una con intención (un chiste, un remate).
- Ver `efectos.md`. Se anclan a la palabra (sin importar acentos o mayúsculas); `vez` elige la 2.ª o 3.ª vez que la dice.
- Uno o dos textos a la vez como máximo. Si dos coinciden, el script los apila en la franja de títulos.
- Los emojis se dibujan como imagen (PNG del paquete `emoji-datasource-google`): la fuente de emojis no siempre aparece en el render. Si un símbolo no tiene imagen, cámbialo.

## 7. Audio (`audio.py`)
- Voz: filtro de graves, `arnndn` + `afftdn` y una compuerta guiada por las palabras (entre palabras baja a 6 %, con rampas de 30 ms). Así se van los ruidos de casa sin tocar la voz. Si un ruido suena ENCIMA de la voz, solo se puede bajar, no quitar: dilo.
- Efectos de sonido con pico a −9 dBFS antes de nivelar: se oyen claro y debajo de la voz. `--sfx_db` sube o baja todos.
- Música solo si ella la pide y el archivo es suyo o libre de derechos (`--musica`), unos 20 dB debajo de la voz.
- Nivel final −14 LUFS en dos pasadas y limitador.

## 8. Animación y render (`final.py`)
- Subtítulos en posición FIJA del perfil; en modo `palabra` se achican solo si una palabra no cabe en el ancho.
- Si su fuente no trae acentos o ñ (fuentes demo), la de respaldo los dibuja; `ajuste_respaldo` iguala su tamaño (p. ej. 130–140 %).
- Entrada de textos en 0.28 s con desenfoque de movimiento solo durante la entrada; máquina de escribir a 0.035 s por letra; fundido final según el perfil.
- Render por tramos de 15 s con `--concurrency=1` (poca RAM) y reintento automático. Siempre haz primero la vista previa de 5 s del gancho.

## 9. Guardar
- Nombre corto del tema en minúsculas con guiones: `tema_v1.mp4`. La versión siguiente nunca reemplaza a la anterior.
- En carpetas conectadas a veces no se puede borrar ni mover: copia, no muevas; y no borres nada de ella.

## Calidad automática (todas las marcas)

- **Video HDR → color normal.** `preparar.py` detecta si un clip viene en HDR (HLG o PQ, lo normal en iPhone con "Video HDR" encendido) y `cortar.py` lo pasa a color normal (BT.709) con mapeo de tonos, para que la piel no salga gris, lavada ni quemada en Instagram. Si el ffmpeg de su compu no trae `zscale`, usa una aproximación y sigue.
- **Voz pareja.** `audio.py` agrega a la limpieza una compresión suave (2.5:1) y un control de «s» fuertes (de-esser), así la voz suena igual de cerca en todo el Reel y las «s» no pican. Solo si su ffmpeg trae esos filtros; si no, sigue sin ellos.
- **Música medida bajo la voz.** `audio.py --musica` ya mide la canción contra SU voz y la deja a un nivel fijo debajo (`--musica-db`, −18 dB por defecto), con salida suave al final.
- **Revisión de acomodo antes de animar.** `final.py preparar` corre `revisar_layout.py`: ningún texto, sticker o animación fuera del marco seguro (x 60–1020, y 270–1620) ni encima de su cara en ese momento (los títulos «detrás» sí pueden cruzarla). Lo arregla solo (achica, sube arriba de su cabeza o baja bajo su barbilla) y avisa lo que no pudo. Nunca detiene la edición.
- **Hoja de momentos.** `final.py fotos --momentos …` saca un cuadro YA animado de cada escena, numerado, para que ella apruebe el storyboard sobre fotos reales y comente por número.
- **Portada.** `portada.py candidatos` elige los mejores cuadros de su grabación (nítidos, de frente, ojos abiertos, cara quieta); `portada.py componer` les pone su título en el tercio de arriba, sin tocar su cara y en un color que se lea.
- **Efectos dichos en voz alta.** Si ella nombra un efecto mientras habla, esa frase lleva ese efecto (y nunca se corta).
- **Hooks.** Se escriben con `references/escribir-hooks.md`.

