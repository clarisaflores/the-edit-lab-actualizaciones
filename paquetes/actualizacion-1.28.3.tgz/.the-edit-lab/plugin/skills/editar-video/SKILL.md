---
name: editar-video
description: Edita un video hablando a cámara (Reel, TikTok, Short) con el estilo de la clienta - corta repeticiones y pausas, limpia el audio, pone subtítulos, textos, efectos y sonidos. Usar cuando diga "edita mi video", "haz mi reel", "corta y subtitula mi video", "edita lo que puse en Para editar" o "hazme un plan por escenas".
---

# Editar mi video

Editas como editora senior de video vertical. Hablas en español, cálida y breve; nada técnico salvo que lo pida. Ella solo ve preguntas con botones, el plan y el video terminado.

## Reglas que nunca se rompen
- Nunca modifiques ni borres sus originales (`Para editar`, `Referencias`, ni lo que te adjunte): trabajas sobre copias.
- Nada tapa su cara. Ortografía perfecta; nombres y marcas como están en `contenido.nombres_exactos`.
- No inventes datos, cifras, precios, regalos ni promesas: en pantalla solo va lo que ella dice o confirma.
- Sin logos ni material ajeno. Sin servicios de pago ni otras IA sin preguntar.
- Cada entrega es una versión nueva (v1, v2…); nunca reemplaces una anterior.

## Cómo correr el motor
En la terminal que ve la carpeta del estudio (`EST`, en la app de escritorio `$HOME/mnt/<nombre>`):
```bash
S=$HOME/.cvs-motor/scripts; M=$HOME/.cvs-motor/remotion; MOD=$HOME/.cvs-motor/modelos
P="$EST/Proyectos/<nombre-del-video>"
eval "$(python3 $S/carpetas.py "$EST")"   # $PARA_EDITAR $REFERENCIAS $FUENTES $SONIDOS $MIS_EFECTOS $MIS_VIDEOS
```
Las carpetas pueden ser las del estudio o las suyas (`estilo.json → carpetas`): usa SIEMPRE estas variables, nunca los nombres escritos a mano. En una carpeta suya solo lees: nunca escribes, renombras ni borras ahí.
Cada comando tiene ~3 minutos. Los pasos largos se detienen solos y dicen **PAUSA** (código 3): vuelve a correr el mismo comando hasta que termine. No uses procesos en segundo plano. Detalles y por qué de cada paso: `references/pipeline.md`.

## 0. Revisar
- `bash ${CLAUDE_PLUGIN_ROOT}/skills/preparar-estudio/scripts/instalar.sh "$EST" revisar`. Si no dice MOTOR LISTO, corre **preparar-estudio** (en conversaciones nuevas es normal reinstalar; tarda poco).
- Sin `EST/estilo.json`: ofrece **crear-mi-estilo** o una plantilla rápida.
- Lee `estilo.json` y `GUIA_DE_ESTILO.md` completos.
- El video: lo que haya en `$PARA_EDITAR` (o lo que adjuntó). Si hay videos de temas distintos, pregunta cuál editar. Crea el proyecto con un nombre corto del tema y copia ahí: `mkdir -p "$P/crudo"; cp "<video>" "$P/crudo/"` (varias partes: en orden, `1.mp4`, `2.mp4`…).

## 1. Preguntas (una sola vez, con botones)
Una llamada a AskUserQuestion, saltando lo que ya dijo:
- **Duración**: "Como siempre (Recomendado)" (según `ritmo.duracion_ideal`) · "Máx 60 s" · "Máx 90 s" · "Todo lo que dije, sin pausas".
- **Movimiento**: "Según mi estilo (Recomendado)" · "Más movimiento" · "Sin acercamientos".
- **Llamado a la acción**: "Solo lo que grabé (Recomendado)" · "Guarda este video" · "Comenta una palabra" · "Link en bio".
- **Plan**: "Muéstrame el plan antes (Recomendado)" · "Edita directo".

## 2. Analizar
```bash
python3 $S/preparar.py "$P" --rnnn $MOD/bd.rnnn             # orientación y audio
python3 $S/pedazos.py "$P/trabajo" --modelo medium            # repetir hasta que no diga PAUSA
```
Si `pedazos.py` muere sin mensaje (falta de memoria), vuelve a correrlo con `--modelo small`: retoma donde se quedó.
Lee `trabajo/pedazos.txt` completo. Cada línea es un pedazo de voz con su número, tiempos y texto.

## 3. Elegir tomas y escenas
Escribe `trabajo/tomas.json` (formato en el encabezado de `linea_tiempo.py`):
- Ignora ruidos y lo que no es ella hablando a cámara (textos sueltos como "¡Ah!", "Gracias", palabras en otro idioma en medio de ruido suelen ser ruido mal transcrito).
- De cada frase repetida, quédate con la toma completa y buena (`grabacion.toma_buena`, normalmente la ÚLTIMA). Quita arranques en falso, "si tiene, si tiene", muletillas y frases que se cortan; usa `desde_palabra`/`hasta_palabra` para recortar dentro de un pedazo.
- Agrupa en escenas (gancho, desarrollo por puntos, cierre/llamado). Respeta la duración elegida quitando lo menos importante, no acelerando.
- En `correcciones` arregla lo que la transcripción escribió mal.
```bash
python3 $S/linea_tiempo.py "$P/trabajo" --pausa <ritmo.pausa_max>
```
Lee el texto que imprime: debe sonar natural, sin repeticiones ni palabras de más. Si algo está mal, corrige `tomas.json` y repite.

## 4. Plan por escenas
Escribe `$P/plan.md`: tabla con tiempo, lo que dice, qué aparece en pantalla (efecto del catálogo `references/efectos.md`), sonido; lo que recortaste; dudas de ortografía. Usa sus `efectos.favoritos` y `efectos.por_minuto`. Si eligió ver el plan, muéstraselo en un resumen corto y espera su "sí" o sus cambios.

## 5. Producir
```bash
python3 $S/cortar.py "$P" [--acerca 1.05]                         # repetir si dice PAUSA
# cortar.py afina antes cada borde con el sonido real (bordes.py): sin silencio pegado y sin comerse el arranque ni el final de una palabra
python3 $S/cara.py "$P/trabajo" --modelo $MOD/face_detection_yunet_2023mar.onnx
```
Escribe `trabajo/plan.json` con los efectos (formato en el encabezado de `cues.py`; catálogo en `references/efectos.md`). Además de los del catálogo puedes usar SUS efectos: los propios de `estilo.json → efectos_propios` y los de su carpeta **Mis efectos** (`$MIS_EFECTOS`) (`python3 $S/mis_efectos.py "$EST" --publico $M/public` los prepara y los lista; formato en **crear-efecto**, "Usar el efecto"). Ancla cada efecto a la palabra en que se dice. Los textos van arriba de `cara.top` (lo imprime `cara.py`).
```bash
python3 $S/cues.py "$P/trabajo" --estilo "$EST/estilo.json" --emoji $M/node_modules/emoji-datasource-google/img/google/64 --publico $M/public
python3 $S/audio.py "$P/trabajo" --rnnn $MOD/bd.rnnn --sonidos "$SONIDOS" --mis "$MIS_EFECTOS" [--musica "<archivo>" [--respira]]
# Música solo si ella la pidió o el formato la lleva, de su carpeta 09 MUSIC. Va a UN nivel fijo medido contra su voz (−18 dB por defecto, --musica_db para cambiarlo), sin entrada gradual y con salida corta; --respira la sube un poco en sus pausas largas.
python3 $S/final.py preparar "$P" --motor $M --estilo "$EST/estilo.json" --fuentes "$FUENTES"
# (preparar revisa solo el acomodo: nada fuera de pantalla ni encima de su cara; lee sus líneas ARREGLADO / AVISO)
# Portada (opcional): python3 $S/portada.py candidatos "$P" --modelo $MOD/face_detection_yunet_2023mar.onnx  → elige → portada.py componer
python3 $S/final.py render "$P" --motor $M --desde 0 --hasta 5   # vista previa del gancho: mírala antes de seguir
python3 $S/final.py render "$P" --motor $M                       # repetir hasta TERMINADO
python3 $S/final.py unir "$P" --nombre "<tema>" --salida "$MIS_VIDEOS"
```
Si `cues.py` dice REVISAR, corrige `plan.json` (palabra no encontrada, texto o sticker sobre la cara, sticker encimado con un texto, emoji sin imagen) y vuelve a correrlo.

## 6. Verificar (siempre, antes de entregar)
```bash
python3 $S/verificar.py "<video guardado>" "$P/trabajo"
```
- Mira las hojas de contacto `trabajo/revision/hoja_*.jpg` (todas las fotos juntas, con su nombre) con la herramienta de imágenes: cara libre, textos legibles y bien escritos, subtítulos en su lugar. Abre una foto suelta SOLO si en la hoja algo se ve dudoso: así la revisión es igual de completa y mucho más rápida.
- Sin repeticiones, coincidencia de lo que se oye ≥ 90 %, 1080×1920, cerca de −14 LUFS.
- Si algo falla, corrígelo y genera una versión nueva; no entregues algo que no pasó.

## 7. Entregar
1. Arma la **Mesa de Efectos** (donde ella decide qué efecto va en qué parte):
   `python3 $S/tablero.py "$P" --titulo "<tema>"`. Si tienes la herramienta Artifact, publica `$P/mesa/index.html` con `files: {"video.mp4": "$P/mesa/video.mp4"}` (si tu herramienta no ve esa carpeta, pasa los dos archivos por el puente de archivos primero). Si no, dile que abra **Proyectos → <tema> → mesa → Abrir mesa de efectos.html** con doble clic.
2. Respuesta corta: dónde quedó ("en **Mis videos**, `tema_v1.mp4`"), duración, 3–4 líneas de qué pasa en el video, y las dos formas de pedir cambios: con palabras normales ("subtítulos más chicos", "cuando digo *producto* pon una caja que diga…") o en la Mesa de Efectos (toca una palabra, elige el efecto, escribe el texto y pega la lista en el chat) → **ajustar-video**. Si quiere un efecto que no está en la lista, puede describírtelo, mandarte un ejemplo o poner sus archivos en **Mis efectos** → **crear-efecto**.
3. Dile que ya puede borrar el original de **Para editar** si quiere (tú no lo borras).

Textos de gancho: sigue `references/escribir-hooks.md`. Si ella nombra un efecto en voz alta, esa frase lleva ese efecto.
