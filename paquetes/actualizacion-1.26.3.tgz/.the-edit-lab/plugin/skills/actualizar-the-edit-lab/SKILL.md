---
name: actualizar-the-edit-lab
description: Actualiza The Edit Lab de la clienta a la versión de este plugin - su página (mismo link, sin perder datos), su editor y sus instrucciones. Usar cuando diga "actualiza mi The Edit Lab", "actualiza mi Edit Lab", "instalé la versión nueva", "subí el plugin nuevo" o "qué hay de nuevo en The Edit Lab".
---

# Actualizar The Edit Lab

Pone **su** The Edit Lab al día con la versión de este plugin, sin borrar nada suyo. Habla en español, cálido y sencillo. No muestres rutas internas, comandos, nombres de herramientas ni errores técnicos: si algo falla, di qué significa para ella y qué hacer. Nunca uses datos, archivos ni páginas de otra persona.

`SK` = la carpeta de este skill. `PLUG` = dos carpetas arriba de `SK` (la raíz del plugin). `INST` = `PLUG/skills/instalar-the-edit-lab` (ahí están la página, las instrucciones y el script del motor).

Lo que es de ella y **nunca** se toca: sus Reels, su Brand Kit, sus colores, sus instrucciones y reglas, sus archivos de contexto, su receta (`motor.recetaId`, `motor.estiloId`, `motor.referenciaId`), sus carpetas y sus archivos de la computadora. Esta actualización no necesita su computadora.

## 0. Encontrar su página

1. Carga con ToolSearch `Artifact` y `ArtifactData`.
2. Lista sus artifacts (`Artifact` action `list`) y busca el título "The Edit Lab". Si hay más de una, pregúntale cuál usa (o que pegue el link). Si no hay ninguna, dile que todavía no tiene The Edit Lab instalado y que escriba **instala mi The Edit Lab**; termina.
3. Lee `studio/config` (`ArtifactData` `get`) y guarda su `version` de documento. Si no tiene `motor.tareaCompu`, su instalación quedó a medias: dile que escriba **instala mi The Edit Lab** (no pierde nada) y termina.
4. Compara `motor.version` con la versión de `PLUG/.claude-plugin/plugin.json`. Si ya es la misma, dile que ya tiene la versión más reciente y pregúntale si quiere reinstalarla igual.

Dile en una línea: "Voy a actualizar tu The Edit Lab a la versión X. Tus Reels y tu marca no se tocan."

## 1. Su página (mismo link)

1. Lee la página con `Artifact` action `read` (url = su página). Es obligatorio antes de publicar sobre ella.
2. Publica `INST/assets/pagina.html` con `Artifact` action `publish`, `url` = su página. **No pases `capabilities`** (así conserva las que ya tiene) y no pases `icon`. Los datos de la página (Reels, Brand Kit, instrucciones) viven en su base de datos y no se borran al publicar.
3. Si el resultado dice que la versión nueva necesita una capacidad que no tiene, vuelve a publicar con `capabilities` = `{"db": {}, "assets": {}, "downloads": {}, "mcp": {"servers": [{"server": "Claude Code Remote", "tools": ["fire_trigger", "update_trigger"]}]}}` y dile que apruebe la tarjeta si aparece.

## 2. Su editor y sus instrucciones

1. `python3 INST/scripts/motor.py PLUG <carpeta de trabajo>/motor.json` y súbelo a su página (`publish`, `url` = su página, `asset: true`) → `motorId` nuevo.
2. Sube `INST/assets/PROCESADOR.md` igual → `procesadorId` nuevo.
3. Escribe en `studio/config` con `ArtifactData` `update` (con `if_version`) el objeto `motor` COMPLETO: copia todos los campos que ya tenía (`tareaCompu`, `recetaId`, `estiloId`, `referenciaId` y cualquier otro) y cambia solo `motorId`, `procesadorId` y `version`. No toques ningún otro campo de `config`.
4. Si existe la herramienta `update_trigger` (claude-code-remote; cárgala con ToolSearch), actualiza el `prompt` de la tarea `motor.tareaCompu` con el texto del paso 3 de `INST/SKILL.md`. Usa como PAGINA su página y como RAIZ la carpeta `config.carpeta` sin el `/Reels` final. Si no existe o la rechaza, no pasa nada: su editor sigue funcionando.

5. **Carpetas nuevas:** si están las herramientas de su computadora (`mcp__remote-devices__…`, búscalas con ToolSearch) y su carpeta está conectada, crea con `device_bash` `mkdir -p` solo las carpetas de la lista del paso 1 de `INST/SKILL.md` que le falten (dentro de `config.carpetaAssets` y `config.carpeta`). Nunca borres, muevas ni renombres nada. Si no hay computadora, dile en el paso 4 qué carpeta crear y dónde.

No borres los archivos viejos de la página (motores e instrucciones anteriores): no estorban y sirven de respaldo.

## 3. Revisar

Lee `studio/config` de vuelta: `motor.version` debe ser la nueva, y `motorId`, `procesadorId` y `tareaCompu` no deben estar vacíos. No digas que quedó actualizado si algo falló.

## 4. Qué le dices al final (corto)

- "Tu The Edit Lab ya está en la versión X." Ábrele su página (`Artifact` action `open`).
- Las novedades de esa versión, sacadas de `PLUG/CAMBIOS.md`, en 1 a 3 frases sencillas.
- Si una novedad le pide algo (por ejemplo, elegir una carpeta nueva en Mis Brand Assets), díselo con pasos claros.
- Si un Reel estaba a la mitad, sigue donde iba: no tiene que empezarlo de nuevo.

## Si algo falla

- Una tarjeta rechazada: explícale para qué era y ofrece repetir solo ese paso.
- Repetir la actualización es seguro: no borra nada suyo.
