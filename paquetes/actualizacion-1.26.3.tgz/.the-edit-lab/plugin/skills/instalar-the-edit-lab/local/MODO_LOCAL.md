# Modo local: cómo se traduce todo a su Mac

Estás corriendo en SU Mac, dentro de su carpeta del estudio (la carpeta actual; también en `$EDIT_LAB_ESTUDIO`). Sus instrucciones de editora (PROCESADOR.md) se escribieron para la nube; aquí todo es más simple y más rápido. Donde PROCESADOR.md diga una herramienta de la nube, usa su equivalente local:

```bash
export PATH="$HOME/.cvs-motor/bin:$HOME/.local/bin:/opt/homebrew/bin:$PATH" PYTHONUTF8=1
lab() { python3 "$EDIT_LAB_PLUGIN/skills/instalar-the-edit-lab/local/lab.py" "$@"; }
ahora() { python3 -c 'import time; print(int(time.time()*1000))'; }   # hora real en milisegundos
```
Puede ser una Mac o una PC con Windows (en Windows tu Bash es Git Bash: las rutas se escriben `/c/Users/...` o entre comillas como `"C:/Users/..."`). Los comandos de abajo funcionan igual en las dos. Donde PROCESADOR.md diga `date +%s%3N`, usa `ahora` (en Mac `date` no da milisegundos). Donde diga `$LAB`, usa `lab`.

| En PROCESADOR.md | En su Mac |
|---|---|
| ArtifactData `get` de un documento (`studio/config`, `reels/<id>`, `brand`…) | `lab db get <col/id>` (imprime `{}` si no existe) |
| ArtifactData `list` / `query` de una colección | `lab db list <col>` y filtra tú |
| ArtifactData `set` / `merge` / `update` / `delete` | `lab db set\|merge\|update\|delete <col/id> '<json>'` (no hay versiones: escribe directo; vuelve a leer antes de escribir si importa `cancelado`). Para JSON largo, escríbelo a un archivo y pásalo con `"$(cat archivo.json)"`. |
| Artifact `read` de un archivo subido (id) | el archivo está en `$(lab asset ruta <id>)`: léelo o cópialo directo |
| Artifact `publish` / subir un archivo (`asset: true`) para la página | `lab asset add <ruta> [tipo-mime]` → usa el `id` que responde (la página lo muestra en `/_blob/<id>`). Videos grandes: un solo archivo, no hace falta partirlo; `partes` = `[id]`. |
| `device_bash` | tu Bash, directo. Donde diga `$HOME/mnt/<carpeta>/…` usa la ruta real (por ejemplo `"$EDIT_LAB_ESTUDIO/Reels/Reel 5"`). |
| `device_stage_files`, `device_commit_files`, `/mnt/user-data/…` | no hacen falta: lee y escribe los archivos en su lugar. Una copia de trabajo va en tu carpeta de trabajo, nunca encima de sus originales. |
| `get_device_info`, `device_list_dir` | `ls` / `find` en su carpeta del estudio. |
| `device_request_folder_access` | no hace falta: ya estás en su carpeta. |
| `device_request_delete_permission` (paso 7, Video listo) | no hace falta: borra con `rm -rf` solo lo que el paso 7 permite. |
| Paso 1.1: descargar `config.motor.motorId` y extraerlo en `~/cvs-plugin` | NO: el plugin ya está en `$EDIT_LAB_PLUGIN`. Donde diga `~/cvs-plugin` usa esa ruta (entre comillas: puede tener espacios). |
| Paso 1.2: instalar el motor | Solo corre `bash "$EDIT_LAB_PLUGIN/skills/preparar-estudio/scripts/instalar.sh" ~/estudio revisar`. Si dice **MOTOR LISTO**, no corras `python`, `recursos` ni `remotion`: ya están en su Mac. Los modelos de voz ya están bajados; solo si `pedazos.py` dice que falta uno, corre el paso `voz`. |
| `estiloId`, `recetaId`, `referenciaId`, `procesadorId` | son ids de archivos: `lab asset ruta <id>`. Si `config.motor` no trae `estiloId`, usa `"$EDIT_LAB_ESTUDIO/estilo.json"` y `"$EDIT_LAB_ESTUDIO/GUIA_DE_ESTILO.md"`. |
| Fotos o videos que necesitas VER | ábrelos con Read directo desde su ruta. |

**Licencia, antes de todo.** Corre `lab licencia`. Si no dice `"ok": true`, no edites nada: escribe en el reel que te tocaba `estado`: `Necesita licencia`, `aviso`: "Activa tu licencia de The Edit Lab en la página para editar." y termina. Nunca crees, cambies ni borres `.the-edit-lab/licencia.json`, ni toques `licencia.py`.

Reglas que no cambian: no preguntas nada (nadie va a contestar), la hora real con `ahora`, revisas `cancelado` antes de cada paso grande, nunca tocas sus originales ni sus Brand Assets (salvo `Brand Assets/.efectos-propios/` y, en el paso 9, `Mi Brand Kit.md` y `Mi Editing System.md` de la carpeta de la marca), y cada video final va a `Reels/<su Reel>/Resultado final/` como versión nueva.

Rapidez: ya estás en su Mac, así que no copies videos de un lado a otro sin necesidad, no reduzcas un video que ya está reducido en `.studio` y no renderices pruebas completas para revisar: unas fotos bastan.

**Rápido en su Mac (menos vueltas = menos uso y menos espera):**
- Los scripts que aceptan `--tiempo` (`pedazos.py`, `cortar.py`, `final.py render`) se escribieron para pausas de 2 minutos en la nube. Aquí córrelos con `--tiempo 540` y con el timeout de tu Bash en 600000 ms: terminan en una o dos llamadas en vez de salir con PAUSA a cada rato. Si aun así dicen PAUSA, repite el mismo comando.
- `final.py render` y la transcripción ya usan varios núcleos de su Mac solos (`EDIT_LAB_LOCAL=1`): no cambies eso ni renderices por pedacitos.
- El avance con porcentaje lo calcula la página sola con el reloj: no escribas `porcentaje` ni `actualizadoEn` a media fase; solo `progreso` y `paso` al empezar cada paso numerado.
- Si el pedido trae `accion`, haz SOLO esa acción para ese reel (o esa marca) y termina: no revises otros pendientes (la fila los lanza sola).

**Gasta poco (cada vuelta cuenta contra el límite de uso de la clienta):**
- Lee `studio/config`, `brand` y el reel UNA sola vez al empezar; no los vuelvas a leer salvo `cancelado` (revísalo al empezar cada paso grande, no antes de cada escritura).
- `progreso`, `porcentaje` y `paso` se escriben al empezar cada paso numerado, con un solo `lab db merge`. No actualices cada 3 minutos: nada de bucles de espera con escrituras. Para esperar un proceso largo, corre el comando hasta el final en una sola llamada.
- La foto real del avance: una sola, al terminar la fase (no una por etapa).
- Usa los scripts que ya existen (`pedazos.py`, `cortar.py`, `cues.py`, `final.py`…). No escribas herramientas nuevas ni releas sus archivos de código para entenderlos: usa lo que dice su uso (`--help` o la primera línea).
- Salidas largas: siempre con `| head -40` o `| tail -40`; nunca imprimas un JSON o una transcripción completos, extrae solo lo que necesitas con `python3 -c`.
- Al terminar, tu respuesta final es una sola línea. Todo lo que ella necesita ver ya está escrito en el reel.
