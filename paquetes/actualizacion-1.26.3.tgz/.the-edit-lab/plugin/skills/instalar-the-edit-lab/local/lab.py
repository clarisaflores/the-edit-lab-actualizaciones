#!/usr/bin/env python3
"""The Edit Lab · modo local. Solo biblioteca estándar.

Sirve tu página The Edit Lab en tu Mac (http://localhost:4791) y hace lo que en la nube hace la plataforma:
  - base de datos      → .the-edit-lab/datos/db.json
  - archivos subidos   → .the-edit-lab/datos/archivos/<id>
  - despertar a Claude → corre Claude Code en esta carpeta (claude -p) con tus instrucciones del editor

Uso:
  python3 lab.py servir [--puerto 4791] [--no-abrir]
  python3 lab.py db get <col/id>             imprime el documento (JSON) o {} si no existe
  python3 lab.py db list <col>               imprime [{id, ...datos}]
  python3 lab.py db set <col/id> '<json>'    reemplaza el documento
  python3 lab.py db update <col/id> '<json>' mezcla campos ({"campo": {"__delete__": true}} lo borra)
  python3 lab.py db delete <col/id>
  python3 lab.py asset add <ruta> [tipo]     guarda una copia y responde {"id":..., "ruta":...}
  python3 lab.py asset ruta <id>             ruta del archivo en tu Mac
  python3 lab.py estado                      qué está haciendo Claude ahora
  python3 lab.py licencia                    a nombre de quién está esta copia
"""
import glob, json, mimetypes, os, re, shutil, subprocess, sys, threading, time, uuid, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote

AQUI = os.path.dirname(os.path.abspath(__file__))           # .../plugin/skills/instalar-the-edit-lab/local
PLUG = os.path.normpath(os.path.join(AQUI, '..', '..', '..'))
PAGINA = os.path.join(PLUG, 'skills', 'instalar-the-edit-lab', 'assets', 'pagina.html')
PROCESADOR = os.path.join(PLUG, 'skills', 'instalar-the-edit-lab', 'assets', 'PROCESADOR.md')
LOCAL_MD = os.path.join(AQUI, 'MODO_LOCAL.md')
SHIM = os.path.join(AQUI, 'shim.js')
sys.path.insert(0, AQUI)
import licencia  # noqa: E402


def estudio():
    """Carpeta del estudio: la variable EDIT_LAB_ESTUDIO o la carpeta actual."""
    return os.path.abspath(os.environ.get('EDIT_LAB_ESTUDIO') or os.getcwd())


def rutas():
    est = estudio()
    d = os.path.join(est, '.the-edit-lab', 'datos')
    os.makedirs(os.path.join(d, 'archivos'), exist_ok=True)
    os.makedirs(os.path.join(est, '.the-edit-lab', 'registros'), exist_ok=True)
    return est, d


# ---------- base de datos (un JSON con candado) ----------
try:
    import fcntl
except ImportError:          # Windows
    fcntl = None
    import msvcrt


class Bloqueo:
    """Un solo escritor a la vez (la página y Claude escriben en el mismo archivo). Mac y Windows."""
    def __enter__(self):
        _, d = rutas()
        self.f = open(os.path.join(d, '.candado'), 'a+')
        if fcntl:
            fcntl.flock(self.f, fcntl.LOCK_EX)
        else:
            self.f.seek(0)
            while True:
                try:
                    msvcrt.locking(self.f.fileno(), msvcrt.LK_LOCK, 1)
                    break
                except OSError:
                    time.sleep(0.05)
        return self

    def __exit__(self, *a):
        if fcntl:
            fcntl.flock(self.f, fcntl.LOCK_UN)
        else:
            self.f.seek(0)
            try:
                msvcrt.locking(self.f.fileno(), msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
        self.f.close()


def _leer():
    _, d = rutas()
    p = os.path.join(d, 'db.json')
    try:
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {'v': 0, 'docs': {}}


def _guardar(db):
    _, d = rutas()
    db['v'] = db.get('v', 0) + 1
    p = os.path.join(d, 'db.json')
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(db, f, ensure_ascii=False)
    os.replace(tmp, p)


def _mezclar(base, patch):
    for k, v in patch.items():
        if isinstance(v, dict) and v.get('__delete__') is True:
            base.pop(k, None)
        else:
            base[k] = v
    return base


def db_get(path):
    return _leer()['docs'].get(path)


def db_list(col):
    docs = _leer()['docs']
    pre = col.rstrip('/') + '/'
    return [dict(v, id=k[len(pre):]) for k, v in docs.items() if k.startswith(pre) and '/' not in k[len(pre):]]


def db_escribir(op, path, data=None):
    with Bloqueo():
        db = _leer()
        docs = db['docs']
        if op == 'set':
            docs[path] = _mezclar({}, data or {})
        elif op == 'merge':
            docs[path] = _mezclar(docs.get(path, {}), data or {})
        elif op == 'update':
            if path not in docs:
                raise KeyError('not found: ' + path)
            docs[path] = _mezclar(docs[path], data or {})
        elif op == 'delete':
            docs.pop(path, None)
        elif op == 'add':
            path = path.rstrip('/') + '/' + uuid.uuid4().hex[:20]
            docs[path] = _mezclar({}, data or {})
        _guardar(db)
        return path


def db_version():
    return _leer().get('v', 0)


# ---------- archivos ----------
def asset_ruta(aid):
    _, d = rutas()
    aid = os.path.basename(aid)
    return os.path.join(d, 'archivos', aid)


def asset_meta():
    _, d = rutas()
    try:
        with open(os.path.join(d, 'archivos.json'), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def asset_guardar_meta(m):
    _, d = rutas()
    with open(os.path.join(d, 'archivos.json'), 'w', encoding='utf-8') as f:
        json.dump(m, f, ensure_ascii=False)


def asset_add_desde(origen, tipo=None, nombre=None):
    aid = uuid.uuid4().hex
    shutil.copyfile(origen, asset_ruta(aid))
    with Bloqueo():
        m = asset_meta()
        m[aid] = {'tipo': tipo or mimetypes.guess_type(nombre or origen)[0] or 'application/octet-stream',
                  'nombre': nombre or os.path.basename(origen), 'creado': time.time()}
        asset_guardar_meta(m)
    return aid


# ---------- Claude Code en segundo plano ----------
CORRIDA = {'activa': None, 'pendientes': [], 'ultima': None}
CANDADO_CORRIDA = threading.Lock()


def buscar_claude():
    extra = [os.path.expanduser('~/.local/bin'), os.path.expanduser('~/.claude/local'), '/opt/homebrew/bin', '/usr/local/bin']
    ruta = os.pathsep.join(extra + [os.environ.get('PATH', '')])
    return shutil.which('claude', path=ruta)


ACCION_SECCION = {  # acción -> secciones de PROCESADOR.md que le tocan (además de las comunes)
    'analizar': ['## 4.'], 'corte': ['## 4b.'], 'aperturas': ['## 4c.'], 'storyboard': ['## 4d.'],
    'editar': ['## 5.', '## 8.'], 'multiplicar': ['## 6.'], 'limpiar': ['## 7.'], 'marca': ['## 9.'],
}
COMUNES = ['## 0.', '## 2.', '## 2b.', '## 3.', '## Carpeta de la compu', '## Si algo falla', '## L\u00edmites']
MINIMAS = ['## 0.', '## Si algo falla', '## L\u00edmites']  # limpiar no necesita su estilo ni su formato


def _accion_de(texto):
    try:
        return (json.loads(texto) or {}).get('accion')
    except Exception:
        return None


def instrucciones_para(accion):
    """Escribe una copia corta de PROCESADOR.md solo con lo que esa acción necesita (antes Claude leía las 56 KB cada vez)."""
    try:
        if accion not in ACCION_SECCION:
            return PROCESADOR
        s = open(PROCESADOR, encoding='utf-8').read()
        partes = re.split(r'(?m)^(?=## )', s)
        intro, resto = partes[0], partes[1:]
        quiero = (MINIMAS if accion in ('limpiar', 'marca') else COMUNES) + ACCION_SECCION[accion]
        elegidas = [p for p in resto if any(p.startswith(q) for q in quiero)]
        if not elegidas:
            return PROCESADOR
        carpeta = os.path.join(estudio(), '.the-edit-lab', 'datos')
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, 'procesador_%s.md' % accion)
        with open(ruta, 'w', encoding='utf-8') as f:
            f.write(intro + ''.join(elegidas))
        return ruta
    except Exception:
        return PROCESADOR


ACCIONES_REEL = ('analizar', 'corte', 'aperturas', 'storyboard', 'editar', 'multiplicar', 'limpiar')


def _accion_que_espera(r):
    """Qué le toca a Claude en este reel según su ESTADO real (la misma tabla del paso 0 de PROCESADOR.md), o None."""
    if not r or r.get('cancelado'):
        return None
    e = r.get('estado')
    if e in ('Por analizar', 'Analizando'):
        return 'analizar'
    if e == 'Preparando corte':
        return 'corte'
    if e == 'Preparando aperturas':
        return 'aperturas'
    if e == 'Preparando storyboard':
        return 'storyboard'
    if r.get('listo') and e in ('En cola', 'Editando'):
        return 'editar'
    if (r.get('multi') or {}).get('estado') in ('En cola', 'Creando'):
        return 'multiplicar'
    if r.get('limpieza') in ('En cola', 'Limpiando'):
        return 'limpiar'
    return None


def pedido_pendiente():
    """La página casi siempre despierta sin mensaje: buscamos aquí qué reel espera y QUÉ espera, por su estado real.
    Así Claude recibe el pedido exacto (lee solo su parte de las instrucciones) y nunca se repite un paso que ya pasó."""
    try:
        L = [r for r in db_list('reels') if _accion_que_espera(r)]
        L.sort(key=lambda r: r.get('listoEn') or r.get('actualizado') or r.get('orden') or 0)
        if L:
            return json.dumps({'reel': L[0].get('id'), 'accion': _accion_que_espera(L[0])})
        M = [m for m in db_list('marcas') if m.get('estado') == 'Creando']
        M.sort(key=lambda m: m.get('pedidoEn') or 0)
        if M:
            return json.dumps({'marca': M[0].get('id'), 'accion': 'marca'})
    except Exception:
        pass
    return None


def prompt_editor(texto):
    est = estudio()
    msg = (
        'Eres la editora de video en segundo plano de The Edit Lab de esta clienta, en MODO LOCAL: trabajas en su Mac, '
        f'en su carpeta del estudio "{est}". Antes que nada lee COMPLETO el archivo "{LOCAL_MD}" (cómo se traduce todo a su Mac) '
        f'y después sigue COMPLETAS, de principio a fin, las instrucciones de "{instrucciones_para(_accion_de(texto))}", sin hacer preguntas: nadie va a contestar. '
        f'Su carpeta de Reels es "{est}/Reels" y su carpeta de assets es "{est}/Brand Assets".'
    )
    if texto:
        msg += ' El pedido de la página es este JSON: ' + texto
    else:
        msg += ' No hay JSON con el pedido: revisa qué hay pendiente como dicen tus instrucciones en el paso 0.'
    return msg



def _clasificar(salida):
    """Si Claude respondió con un error conocido, devuelve (clave, título, qué pasó, qué hacer); si no, None."""
    import re
    t = salida or ''
    low = t.lower()
    if re.search(r'weekly limit|usage limit|hit your .{0,20}limit|limit reached|out of (extra )?usage|credit balance', low):
        m = re.search(r'resets?[^\n]{0,60}', t, re.I)
        cuando = (' Se restablece: ' + m.group(0).replace('resets', '', 1).strip(' \u00b7').strip() + '.') if m else ''
        return ('limite', 'Se agotó tu límite de uso de Claude',
                'Claude Code llegó a su límite de uso y no puede trabajar por ahora.' + cuando,
                'Espera a que se restablezca (puedes ver cuándo escribiendo /usage en la Terminal dentro de claude) y después toca Volver a intentar. Lo que ya elegiste se conserva.')
    if re.search(r'not logged in|/login|invalid api key|authentication|unauthorized|oauth|please run', low):
        return ('sesion', 'Claude Code no tiene la sesión iniciada',
                'Claude Code no reconoce tu cuenta, por eso no puede trabajar.',
                'Abre la Terminal, escribe claude, inicia sesión con tu cuenta, ciérralo y toca Volver a intentar.')
    if re.search(r'overloaded|rate limit|\b529\b|\b503\b|try again later|service unavailable', low):
        return ('saturado', 'Claude está saturado',
                'Los servidores de Claude están con demasiada demanda en este momento.',
                'Espera unos minutos y toca Volver a intentar. No perdiste nada.')
    if re.search(r'enotfound|econnrefused|network error|fetch failed|could not resolve|connection (error|refused)', low):
        return ('internet', 'No hay conexión a internet',
                'The Edit Lab no pudo comunicarse con Claude porque no hay internet.',
                'Revisa tu conexión (wifi) y toca Volver a intentar.')
    return None


def _error_claude(salida):
    """Mensaje en español para el reel si Claude respondió con un error conocido; si no, None."""
    c = _clasificar(salida)
    if not c:
        return None
    if c[0] == 'limite':
        return 'Se agotó tu límite de uso de Claude, por eso no pudo trabajar.' + c[2].replace('Claude Code llegó a su límite de uso y no puede trabajar por ahora.', '') + ' Cuando se restablezca, toca Volver a intentar. Lo que ya elegiste se conserva.'
    return c[2] + ' ' + c[3]


def _marcar_error(texto, mensaje):
    """Pone el reel (o los que estaban trabajando) en Error con el mensaje, para que la página lo muestre."""
    try:
        x = json.loads(texto) if texto else {}
    except Exception:
        x = {}
    if x.get('accion') == 'marca' or x.get('marca'):
        for m in db_list('marcas'):
            if m.get('estado') == 'Creando' and (not x.get('marca') or m['id'] == x.get('marca')):
                db_escribir('merge', 'marcas/' + m['id'], {'estado': 'Error', 'progreso': mensaje})
        return
    trabajando = ('Por analizar', 'Analizando', 'Editando', 'En cola', 'Preparando corte', 'Preparando aperturas', 'Preparando storyboard')
    for r in db_list('reels'):
        if (x.get('reel') and r['id'] == x['reel']) or (not x.get('reel') and r.get('estado') in trabajando):
            if r.get('estado') in trabajando or r['id'] == x.get('reel'):
                db_escribir('merge', 'reels/' + r['id'], {'estado': 'Error', 'progreso': mensaje, 'paso': None, 'porcentaje': None})


def cancelar_corrida():
    """Detiene a Claude si est\u00e1 trabajando y vac\u00eda la fila de pedidos. Devuelve True si detuvo algo."""
    with CANDADO_CORRIDA:
        CORRIDA['pendientes'].clear()
    proc = CORRIDA.get('proc')
    if proc and proc.poll() is None:
        CORRIDA['cancelada'] = True
        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/F', '/T', '/PID', str(proc.pid)], capture_output=True)
            else:
                proc.terminate()
                try:
                    proc.wait(3)
                except Exception:
                    proc.kill()
        except Exception:
            pass
        return True
    return False


def _correr(texto):
    est, _ = rutas()
    if texto is None:
        for _ in range(10):      # la página despierta en cuanto tocas el botón; su cambio puede tardar un instante en guardarse
            texto = pedido_pendiente()
            if texto:
                break
            time.sleep(0.5)
        if texto is None:
            return               # nada espera: no se gasta a Claude en averiguarlo
    try:
        _x = json.loads(texto)
        CORRIDA.setdefault('lanzados', set()).add('%s:%s' % (_x.get('reel'), _x.get('accion')))
    except Exception:
        pass
    claude = buscar_claude()
    log = os.path.join(est, '.the-edit-lab', 'registros', time.strftime('%Y-%m-%d_%H-%M-%S') + '.log')
    CORRIDA['activa'] = {'desde': time.time(), 'pedido': texto, 'registro': log}
    try:
        if not licencia.estado().get('ok'):
            with open(log, 'w') as f:
                f.write('Esta copia de The Edit Lab no tiene licencia activa. Actívala en la página.\n')
            _incidente('Sin licencia activa: no se pudo trabajar.', ('licencia', 'error', 'Tu licencia no está activa',
                       'The Edit Lab no puede editar porque la licencia no está activa.', 'Actívala en la página con tu correo y tu clave.'))
            _marcar_error(texto, 'Tu licencia no está activa. Actívala en la página y toca Volver a intentar.')
            return
        if not claude:
            with open(log, 'w') as f:
                f.write('No encuentro Claude Code (el comando claude). Instálalo desde claude.com/claude-code.\n')
            _incidente('No se encontró el comando claude.', ('sinclaude', 'error', 'No encuentro Claude Code',
                       'The Edit Lab necesita Claude Code instalado en tu Mac para editar y no lo encuentra.',
                       'Instálalo desde claude.com/claude-code, abre la Terminal, escribe claude e inicia sesión. Después toca Volver a intentar.'))
            _marcar_error(texto, 'No encuentro Claude Code en tu Mac. Instálalo desde claude.com/claude-code y toca Volver a intentar.')
            return
        env = dict(os.environ)
        env['PATH'] = os.pathsep.join([os.path.expanduser('~/.cvs-motor/bin'), os.path.expanduser('~/.local/bin'),
                                       '/opt/homebrew/bin', '/usr/local/bin', env.get('PATH', '')])
        env['EDIT_LAB_ESTUDIO'] = est
        env['PYTHONUTF8'] = '1'
        env['EDIT_LAB_PLUGIN'] = PLUG
        env['EDIT_LAB_LOCAL'] = '1'
        env.setdefault('BASH_DEFAULT_TIMEOUT_MS', '600000')
        env.setdefault('BASH_MAX_TIMEOUT_MS', '600000')
        lic = licencia.estado()
        if lic.get('ok'):
            env['EDIT_LAB_LICENCIA'] = f"The Edit Lab · licencia #{lic.get('n')} · {lic.get('correo')}"
        if os.name == 'nt':
            env['PATH'] = os.path.expanduser('~/.cvs-motor/venv/Scripts') + os.pathsep + env['PATH']
            for gb in (r'C:\Program Files\Git\bin\bash.exe', os.path.expandvars(r'%LOCALAPPDATA%\Programs\Git\bin\bash.exe')):
                if os.path.isfile(gb) and 'CLAUDE_CODE_GIT_BASH_PATH' not in env:
                    env['CLAUDE_CODE_GIT_BASH_PATH'] = gb
        for k in ('VIRTUAL_ENV', 'PYTHONHOME', 'PYTHONPATH'):
            env.pop(k, None)
        cmd = [claude, '-p', prompt_editor(texto), '--permission-mode', 'acceptEdits',
               '--allowedTools', 'Bash', 'Read', 'Write', 'Edit', 'Glob', 'Grep', 'TodoWrite']
        if _accion_de(texto) in ('corte', 'limpiar', 'multiplicar') and not os.environ.get('EDIT_LAB_MODELO_FIJO'):
            cmd += ['--model', 'sonnet']      # pasos mecánicos: el modelo rápido gasta menos uso y basta
        with open(log, 'w') as f:
            f.write('PEDIDO: ' + (texto or '(revisar pendientes)') + '\n\n')
            f.flush()
            t0 = time.time()
            CORRIDA['cancelada'] = False
            proc = subprocess.Popen(cmd, cwd=est, env=env, stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            CORRIDA['proc'] = proc
            proc.wait()
            CORRIDA['proc'] = None
            if CORRIDA.get('cancelada'):
                f.write('\n\nCANCELADO por ti.\n')
            seg = round(time.time() - t0)
            f.write('\n\nTERMIN\u00d3 en %d s\n' % seg)
        try:  # ¿Claude no pudo trabajar? (límite, sesión, saturación): se lo decimos en la página
            with open(log, encoding='utf-8', errors='replace') as f2:
                salida = f2.read().split('\n\n', 1)[-1]
            msg = _error_claude(salida) if len(salida.strip()) < 700 else None
            if CORRIDA.get('cancelada'): msg = None  # un error real es corto; una respuesta larga no es un aviso
            if msg:
                _marcar_error(texto, msg)
                c = _clasificar(salida)
                try:
                    rid = (json.loads(texto) if texto else {}).get('reel')
                except Exception:
                    rid = None
                _incidente('Claude no pudo trabajar (%s): %s' % (c[0], c[2]), (c[0], 'error', c[1], c[2], c[3], None))
                _aviso_quitar(('atorado',))  # la causa real ya está explicada arriba
            elif not CORRIDA.get('cancelada'):
                _aviso_quitar(('limite', 'sesion', 'saturado', 'internet', 'licencia', 'sinclaude', 'atorado'))  # si funcionó, esos problemas ya pasaron
        except Exception:
            pass
        try:  # cu\u00e1nto tard\u00f3 cada fase (para saber qu\u00e9 conviene acelerar)
            x = json.loads(texto) if texto else {}
            with open(os.path.join(os.path.dirname(log), 'tiempos.jsonl'), 'a') as t:
                t.write(json.dumps({'cuando': time.strftime('%Y-%m-%d %H:%M:%S'), 'accion': x.get('accion'), 'reel': x.get('reel'), 'segundos': seg}) + '\n')
        except Exception:
            pass
    finally:
        try:
            _x2 = json.loads(texto) if texto else {}
            _k2 = '%s:%s' % (_x2.get('reel') or _x2.get('marca'), _x2.get('accion')) if (_x2.get('reel') or _x2.get('marca')) else None
        except Exception:
            _k2 = None
        CORRIDA['ultima'] = dict(CORRIDA['activa'] or {}, hasta=time.time(), clave=_k2)
        CORRIDA['activa'] = None


ESPERANDO = ('En cola', 'Editando', 'Por analizar', 'Analizando')


AVISOS_LOCK = threading.Lock()


def _ruta_avisos():
    d = os.path.join(estudio(), '.the-edit-lab', 'registros')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'avisos.json')


def avisos_leer():
    try:
        with open(_ruta_avisos(), encoding='utf-8') as f:
            x = json.load(f)
        return x if isinstance(x, list) else []
    except Exception:
        return []


def _avisos_guardar(lista):
    try:
        with open(_ruta_avisos(), 'w', encoding='utf-8') as f:
            json.dump(lista[-20:], f, ensure_ascii=False)
    except Exception:
        pass


def _aviso(clave, nivel, titulo, que, hacer, reel=None):
    """Aviso visible para la clienta en la página: qué pasó y qué hacer. Mismo problema = un solo aviso (se actualiza)."""
    with AVISOS_LOCK:
        lista = [a for a in avisos_leer() if a.get('clave') != clave or a.get('reel') != reel]
        lista.append({'id': '%s-%d' % (clave, int(time.time() * 1000)), 'clave': clave, 'nivel': nivel, 'titulo': titulo,
                      'que': que, 'hacer': hacer, 'reel': reel, 'cuando': time.strftime('%H:%M'), 'ts': time.time()})
        _avisos_guardar(lista)


def _aviso_quitar(claves=None, reel=None):
    """Quita avisos que ya no aplican (el problema se resolvió). claves=None quita todos los de ese reel."""
    with AVISOS_LOCK:
        lista = avisos_leer()
        nueva = [a for a in lista if not ((claves is None or a.get('clave') in claves) and (reel is None or a.get('reel') == reel))]
        if len(nueva) != len(lista):
            _avisos_guardar(nueva)


def _incidente(msg, aviso=None):
    """Deja anotado en registros/incidentes.log lo raro que pasó y, si se pasa `aviso`
    (clave, nivel, titulo, que, hacer[, reel]), también se lo muestra a la clienta en la página."""
    try:
        d = os.path.join(estudio(), '.the-edit-lab', 'registros')
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, 'incidentes.log'), 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S') + '  ' + msg + '\n')
    except Exception:
        pass
    if aviso:
        try:
            _aviso(*aviso)
        except Exception:
            pass


def _recuperable(forzar=False):
    """Devuelve el pedido de un reel que espera a Claude (o None). El trabajo siempre sale del ESTADO real del reel,
    nunca de un pedido viejo en la fila, así no se gasta a Claude en pasos que ya pasaron.
    Solo cuenta como «atorado» cuando el MISMO paso del MISMO reel ya corrió completo y el reel sigue esperándolo
    (Claude terminó sin avanzarlo): se reintenta hasta 2 veces y después queda en «Error» con el motivo."""
    try:
        ped = pedido_pendiente()
        if not ped:
            return None
        x = json.loads(ped)
        k = (x.get('reel') or x.get('marca') or '') + ':' + x['accion']
        R = CORRIDA.setdefault('reintentos', {})
        if forzar:
            R[k] = 0
            return ped
        ult = CORRIDA.get('ultima') or {}
        if ult.get('clave') != k:
            return ped           # su turno normal: no es un atorón y no se avisa nada
        n = R.get(k, 0)
        if n < 2:
            R[k] = n + 1
            _incidente('Reel %s (%s): el paso terminó sin avanzar el Reel; se repite solo (intento %d de 2).' % (x['reel'], x['accion'], n + 1))
            return ped
        _incidente('Reel %s (%s) no avanzó ni con 2 reintentos: se marca con error.' % (x['reel'], x['accion']),
                   ('atorado', 'error', 'Un paso de tu Reel no logró terminar', 'Lo intenté 3 veces y el Reel no avanzó.',
                    'Toca Volver a intentar en ese Reel. Si vuelve a pasar, cierra The Edit Lab y ábrelo otra vez. Lo que ya elegiste se conserva.', x['reel']))
        if x.get('marca'):
            db_escribir('merge', 'marcas/' + x['marca'], {'estado': 'Error', 'progreso': 'No se pudo crear tu marca. Toca Crear otra vez; tus respuestas se conservan.'})
        else:
            db_escribir('merge', 'reels/' + x['reel'], {'estado': 'Error', 'progreso': 'Este paso terminó 3 veces sin avanzar tu Reel. Toca Volver a intentar; lo que ya elegiste se conserva.', 'paso': None, 'porcentaje': None})
        R[k] = 0
    except Exception:
        pass
    return None


def recuperar_al_inicio():
    """Al abrir The Edit Lab: si un reel se quedó esperando de antes, se retoma."""
    ped = _recuperable()
    if ped:
        despertar(ped)


def _version():
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', '.claude-plugin', 'plugin.json'), encoding='utf-8') as f:
            return json.load(f).get('version', '')
    except Exception:
        return ''



# ---------- campanita: avisos de versión nueva y noticias (como el Engine: solo anuncios, nunca lo del día a día) ----------
def _notif_archivo():
    return os.path.join(estudio(), '.the-edit-lab', 'datos', 'notificaciones.json')


def _cambios_de(ver):
    """Las líneas de CAMBIOS.md de esa versión, en texto sencillo."""
    try:
        t = open(os.path.join(PLUG, 'CAMBIOS.md'), encoding='utf-8').read()
    except Exception:
        return []
    m = re.search(r'^## ' + re.escape(ver) + r'\s*$(.*?)(?=^## |\Z)', t, re.M | re.S)
    if not m:
        return []
    out = []
    for ln in m.group(1).splitlines():
        ln = ln.strip()
        if ln.startswith('- '):
            out.append(re.sub(r'\*\*(.+?)\*\*', r'\1', ln[2:]))
    return out


_NOTI_RED = {'en': 0, 'items': []}


def _noticias_remotas():
    """Si en plugin.json hay "noticias_url", lee de ahí las noticias (una vez por hora, sin trabar nada si no hay internet)."""
    try:
        url = json.load(open(os.path.join(PLUG, '.claude-plugin', 'plugin.json'), encoding='utf-8')).get('noticias_url') or ''
    except Exception:
        url = ''
    if not url:
        return []
    if time.time() - _NOTI_RED['en'] < 3600:
        return _NOTI_RED['items']
    _NOTI_RED['en'] = time.time()
    try:
        import urllib.request
        with urllib.request.urlopen(url, timeout=4) as r_:
            j = json.loads(r_.read().decode('utf-8'))
        _NOTI_RED['items'] = [x for x in (j.get('noticias') if isinstance(j, dict) else j) or [] if isinstance(x, dict) and x.get('id')]
    except Exception:
        pass
    return _NOTI_RED['items']


def notificaciones():
    f = _notif_archivo()
    try:
        d = json.load(open(f, encoding='utf-8'))
    except Exception:
        d = {}
    vistos = set(d.get('vistos') or [])
    ver = _version()
    items = []
    if ver:
        if not d.get('primera'):            # al instalar por primera vez no se presume nada: solo desde la siguiente versión
            d['primera'] = ver
        if ver != d.get('primera'):
            items.append({'id': 'v-' + ver, 'tipo': 'version', 'titulo': 'Ya tienes The Edit Lab ' + ver, 'puntos': _cambios_de(ver)})
    try:
        loc = json.load(open(os.path.join(PLUG, 'noticias.json'), encoding='utf-8'))
        loc = loc.get('noticias') if isinstance(loc, dict) else loc
    except Exception:
        loc = []
    for x in list(loc or []) + _noticias_remotas():
        if isinstance(x, dict) and x.get('id'):
            items.append({'id': 'n-' + str(x['id']), 'tipo': 'noticia', 'titulo': x.get('titulo', ''), 'texto': x.get('texto', ''), 'fecha': x.get('fecha', ''),
                          'enlace': x.get('enlace', ''), 'titulo_en': x.get('titulo_en', ''), 'texto_en': x.get('texto_en', '')})
    try:
        u = buscar_actualizacion()
    except Exception:
        u = None
    if u:
        items.append({'id': 'act-' + str(u['version']), 'tipo': 'actualizacion', 'titulo': 'Hay una versión nueva: The Edit Lab ' + str(u['version']),
                      'puntos': [str(x) for x in (u.get('notas') or [])][:12], 'version': u['version']})
    try:
        rs = json.load(open(os.path.join(estudio(), '.the-edit-lab', 'datos', 'restaurado.json'), encoding='utf-8'))
        items.append({'id': 'rest-' + rs.get('en', ''), 'tipo': 'noticia', 'titulo': 'Puse tu The Edit Lab original otra vez',
                      'texto': 'Encontré cambios en los archivos del programa y volví a poner la versión original, para que todo funcione bien. Tus Reels, tu Brand Kit y tus instrucciones no se tocaron.'})
    except Exception:
        pass
    for r_ in reportes_por_enviar():
        items.append({'id': 'rep-' + r_['archivo'], 'tipo': 'reporte', 'titulo': 'Envía este problema a The Edit Lab', 'archivo': r_['archivo'],
                      'texto': 'Claude revisó tu reporte: esto lo tiene que arreglar The Edit Lab en una versión nueva. Envíalo con un clic.', 'resumen': r_.get('resumen', ''),
                      'correo': _correo_soporte(), 'version': _version()})
    for it in items:
        it['visto'] = it['id'] in vistos
    try:
        os.makedirs(os.path.dirname(f), exist_ok=True)
        json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception:
        pass
    return items


def notificaciones_vistas(ids):
    f = _notif_archivo()
    try:
        d = json.load(open(f, encoding='utf-8'))
    except Exception:
        d = {}
    v = set(d.get('vistos') or [])
    v.update(ids or [i['id'] for i in notificaciones()])
    d['vistos'] = sorted(v)
    json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False)


# ---------- reportar un problema: junta en UN archivo lo que pasó, para que Claude lo revise ----------
def _cola(path, n=120):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            return ''.join(f.readlines()[-n:])
    except Exception:
        return ''


def hacer_reporte(x):
    import platform
    est = estudio()
    d = os.path.join(est, '.the-edit-lab', 'reportes')
    os.makedirs(d, exist_ok=True)
    nombre = 'reporte-' + time.strftime('%Y-%m-%d_%H-%M-%S') + '.md'
    regs = os.path.join(est, '.the-edit-lab', 'registros')
    logs = sorted([q for q in glob.glob(os.path.join(regs, '*.log')) if not q.endswith('incidentes.log')], key=os.path.getmtime)[-2:]
    rid = x.get('reel') or ''
    r = db_get('reels/' + rid) if rid else None
    resumen = {}
    if r:
        for k in ('nombre', 'estado', 'aviso', 'paso', 'porcentaje', 'accionPendiente', 'formato', 'actualizado', 'cancelado'):
            if k in r: resumen[k] = r[k]
    partes = ['# Reporte de The Edit Lab', '',
              '- Fecha: ' + time.strftime('%Y-%m-%d %H:%M:%S'),
              '- Versión: ' + (_version() or '?') + ((' (hay una más nueva: ' + str((buscar_actualizacion(forzar=True) or {}).get('version')) + ')') if buscar_actualizacion() else ''),
              '- Compu: ' + platform.platform(),
              '- Pantalla en la que estaba: ' + str(x.get('vista') or ''),
              '', '## Lo que pasó (en sus palabras)', '', (x.get('texto') or '(no escribió nada)').strip(), '',
              '## Reel', '', '```json', json.dumps(resumen, ensure_ascii=False, indent=1), '```', '',
              '## Errores de la página', '', '```', '\n'.join(str(e) for e in (x.get('errores') or [])[-40:]) or '(ninguno)', '```', '',
              '## Lo que está corriendo', '', '```json', json.dumps({'activa': CORRIDA.get('activa'), 'ultima': CORRIDA.get('ultima'), 'en_fila': len(CORRIDA.get('pendientes') or [])}, ensure_ascii=False, default=str, indent=1), '```', '',
              '## Avisos', '', '```json', json.dumps(avisos_leer(), ensure_ascii=False, indent=1)[:6000], '```', '',
              '## Incidentes (últimos)', '', '```', _cola(os.path.join(regs, 'incidentes.log'), 60), '```']
    for q in logs:
        partes += ['', '## Registro ' + os.path.basename(q), '', '```', _cola(q, 150), '```']
    ruta = os.path.join(d, nombre)
    with open(ruta, 'w', encoding='utf-8') as f:
        f.write('\n'.join(partes))
    return {'ok': True, 'archivo': os.path.relpath(ruta, est), 'nombre': nombre}


# ---------- versiones nuevas desde internet (como el Engine): se buscan solas, se instalan con un clic y con respaldo ----------
ACT = {'estado': None, 'error': None, 'en': 0}


def _url_actualizaciones():
    try:
        return json.load(open(os.path.join(PLUG, '.claude-plugin', 'plugin.json'), encoding='utf-8')).get('actualizaciones_url') or ''
    except Exception:
        return ''


def _ver_tupla(v):
    try:
        return tuple(int(x) for x in str(v).strip().lstrip('v').split('.'))
    except Exception:
        return (0,)


def buscar_actualizacion(forzar=False):
    """Lee ultima.json de su GitHub (una vez cada 6 horas). Devuelve {version, notas, archivo, sha256} si es más nueva."""
    url = _url_actualizaciones()
    if not url:
        return None
    f = os.path.join(estudio(), '.the-edit-lab', 'datos', 'actualizacion.json')
    try:
        d = json.load(open(f, encoding='utf-8'))
    except Exception:
        d = {}
    if forzar or time.time() - d.get('revisado', 0) > 6 * 3600:
        try:
            import urllib.request
            req = urllib.request.Request(url + ('&' if '?' in url else '?') + 't=%d' % int(time.time()), headers={'Cache-Control': 'no-cache', 'User-Agent': 'the-edit-lab'})
            with urllib.request.urlopen(req, timeout=6) as r_:
                j = json.loads(r_.read().decode('utf-8'))
            if isinstance(j, dict) and j.get('version') and j.get('archivo') and j.get('sha256'):
                d = {'revisado': time.time(), 'ultima': j}
                os.makedirs(os.path.dirname(f), exist_ok=True)
                json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False)
        except Exception:
            d['revisado'] = time.time() - 5 * 3600   # sin internet: se vuelve a intentar en una hora
    u = d.get('ultima')
    if u and _ver_tupla(u.get('version')) > _ver_tupla(_version()):
        return u
    return None


def _instalar_actualizacion(u):
    import hashlib, tarfile, urllib.request
    est = estudio()
    tmp = os.path.join(est, '.the-edit-lab', 'datos', 'descargas')
    os.makedirs(tmp, exist_ok=True)
    arch = os.path.join(tmp, 'actualizacion-%s.tgz' % u['version'])
    ACT.update(estado='Descargando', error=None)
    req = urllib.request.Request(u['archivo'], headers={'User-Agent': 'the-edit-lab'})
    with urllib.request.urlopen(req, timeout=120) as r_, open(arch + '.part', 'wb') as w_:
        shutil.copyfileobj(r_, w_)
    h = hashlib.sha256(open(arch + '.part', 'rb').read()).hexdigest()
    if h.lower() != str(u['sha256']).lower():
        os.remove(arch + '.part')
        raise RuntimeError('El archivo que llegó no es el original (no coincide su huella). No se instaló nada.')
    os.replace(arch + '.part', arch)
    ACT.update(estado='Revisando')
    with tarfile.open(arch, 'r:gz') as t:
        miembros = t.getmembers()
        for m in miembros:   # solo se aceptan archivos del lab: nada fuera de su carpeta, ni enlaces raros
            n = m.name[2:] if m.name.startswith('./') else m.name
            if n in ('', '.') or n == 'Abrir The Edit Lab.command' or n == '.the-edit-lab' or n.startswith('.the-edit-lab/plugin'):
                if m.issym() or m.islnk() or '..' in n.split('/') or n.startswith('/'):
                    raise RuntimeError('El paquete trae algo que no debería. No se instaló nada.')
                continue
            raise RuntimeError('El paquete trae archivos fuera del lab. No se instaló nada.')
        ACT.update(estado='Respaldando')
        resp = os.path.join(est, '.the-edit-lab', 'respaldos')
        os.makedirs(resp, exist_ok=True)
        with tarfile.open(os.path.join(resp, 'plugin-%s-%s.tgz' % (_version() or 'antes', time.strftime('%Y%m%d-%H%M%S'))), 'w:gz') as b_:
            b_.add(PLUG, arcname='plugin')
        ACT.update(estado='Instalando')
        try:
            t.extractall(est, members=miembros, filter='tar')
        except TypeError:
            t.extractall(est, members=miembros)
    # lo que Claude lee en su carpeta (habilidades e instrucciones) también se pone al día
    dst = os.path.join(est, '.claude', 'skills')
    os.makedirs(dst, exist_ok=True)
    for s_ in ('editar-video', 'ajustar-video', 'crear-efecto', 'crear-mi-estilo', 'preparar-estudio', 'reportar-problema'):
        src = os.path.join(PLUG, 'skills', s_)
        if os.path.isdir(src):
            shutil.rmtree(os.path.join(dst, s_), ignore_errors=True)
            shutil.copytree(src, os.path.join(dst, s_), ignore=shutil.ignore_patterns('__pycache__'))
    pm = os.path.join(PLUG, 'skills', 'instalar-the-edit-lab', 'assets', 'PROCESADOR.md')
    if os.path.exists(pm) and os.path.isdir(os.path.join(est, '.claude')):
        shutil.copy(pm, os.path.join(est, '.claude', 'PROCESADOR.md'))
    _incidente('Se instaló la versión %s (respaldo de la anterior en .the-edit-lab/respaldos).' % u['version'])
    ACT.update(estado='Reiniciando')


def _actualizar_solo_activo():
    try:
        return bool(json.load(open(os.path.join(PLUG, '.claude-plugin', 'plugin.json'), encoding='utf-8')).get('actualizar_solo'))
    except Exception:
        return False


def _vigilar_actualizaciones():
    """Como pidió su dueña: muy automático. Cada 6 horas busca una versión nueva y, si Claude no está trabajando en
    ningún Reel, la instala sola (con respaldo) y se reinicia. La campanita le cuenta qué cambió."""
    time.sleep(20)
    vuelta = 0
    while True:
        try:
            bajar_canceladas()
            if vuelta % 12 == 0:      # al abrir y cada 6 horas: ¿sigue siendo el original?
                revisar_original()
        except Exception:
            pass
        vuelta += 1
        try:
            u = buscar_actualizacion()
            if u and _actualizar_solo_activo() and not (CORRIDA.get('activa') or CORRIDA.get('hilo') or CORRIDA.get('pendientes')):
                _incidente('Versión nueva %s encontrada: se instala sola.' % u.get('version'))
                actualizar_ahora()
        except Exception:
            pass
        time.sleep(30 * 60)


def actualizar_ahora():
    if CORRIDA.get('activa') or CORRIDA.get('hilo'):
        return {'ok': False, 'error': 'Claude está trabajando en un Reel. Actualiza cuando termine.'}
    u = buscar_actualizacion(forzar=True)
    if not u:
        return {'ok': False, 'error': 'Ya tienes la versión más nueva.'}
    if ACT.get('estado') in ('Descargando', 'Revisando', 'Respaldando', 'Instalando'):
        return {'ok': True, 'estado': ACT['estado']}

    def _hilo():
        try:
            _instalar_actualizacion(u)
            time.sleep(1.5)
            os.execv(sys.executable, [sys.executable, os.path.abspath(__file__), 'servir', '--no-abrir', '--puerto', str(ACT.get('puerto') or 4791)])
        except Exception as e:
            ACT.update(estado='Error', error=str(e))
    threading.Thread(target=_hilo, daemon=True).start()
    return {'ok': True, 'estado': 'Descargando'}


# ---------- protección: licencias canceladas y copia original (sin cambios) ----------
def _base_url():
    u = _url_actualizaciones()
    return u.rsplit('/', 1)[0] + '/' if u else ''


def _bajar_json(url, timeout=6):
    import urllib.request
    req = urllib.request.Request(url + ('&' if '?' in url else '?') + 't=%d' % int(time.time()), headers={'Cache-Control': 'no-cache', 'User-Agent': 'the-edit-lab'})
    with urllib.request.urlopen(req, timeout=timeout) as r_:
        return json.loads(r_.read().decode('utf-8'))


def bajar_canceladas():
    """La lista de licencias canceladas vive en su GitHub (canceladas.json). Se guarda para que funcione sin internet."""
    b = _base_url()
    if not b:
        return
    try:
        j = _bajar_json(b + 'canceladas.json')
        if isinstance(j, dict):
            d = os.path.join(estudio(), '.the-edit-lab', 'datos')
            os.makedirs(d, exist_ok=True)
            json.dump(j, open(os.path.join(d, 'licencias-canceladas.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception:
        pass


def _huellas_plugin():
    import hashlib
    out = {}
    for raiz, dirs, archivos in os.walk(PLUG):
        dirs[:] = [d_ for d_ in dirs if d_ not in ('__pycache__', 'node_modules', '.git')]
        for a_ in archivos:
            if a_ in ('.DS_Store',) or a_.endswith('.pyc'):
                continue
            ruta = os.path.join(raiz, a_)
            rel = os.path.relpath(ruta, PLUG).replace(os.sep, '/')
            try:
                out[rel] = hashlib.sha256(open(ruta, 'rb').read()).hexdigest()
            except Exception:
                pass
    return out


def revisar_original():
    """Compara el programa con el original publicado (manifiesto de huellas en su GitHub). Si alguien cambió o borró
    archivos del programa, guarda esa copia como respaldo y vuelve a poner el original. Reels, Brand Kit e
    instrucciones no son parte del programa y nunca se tocan."""
    b = _base_url()
    ver = _version()
    if not b or not ver or CORRIDA.get('activa') or CORRIDA.get('hilo'):
        return None
    try:
        man = _bajar_json(b + 'manifiestos/%s.json' % ver)
    except Exception:
        return None
    esperado = man.get('archivos') or {}
    if not esperado:
        return None
    tengo = _huellas_plugin()
    cambiados = sorted(k for k, h in esperado.items() if tengo.get(k) != h)
    if not cambiados:
        return []
    _incidente('El programa tenía %d archivo(s) distinto(s) al original (%s): se restaura el original.' % (len(cambiados), ', '.join(cambiados[:6])))
    try:
        u = _bajar_json(b + 'ultima.json')
        if _ver_tupla(u.get('version')) < _ver_tupla(ver):
            return cambiados
        f = os.path.join(estudio(), '.the-edit-lab', 'datos', 'restaurado.json')
        json.dump({'en': time.strftime('%Y-%m-%d %H:%M'), 'archivos': cambiados[:50]}, open(f, 'w', encoding='utf-8'), ensure_ascii=False)
        _instalar_actualizacion(u)
        time.sleep(1.0)
        os.execv(sys.executable, [sys.executable, os.path.abspath(__file__), 'servir', '--no-abrir', '--puerto', str(ACT.get('puerto') or 4791)])
    except Exception as e:
        _incidente('No se pudo restaurar el original: %s' % e)
    return cambiados


# ---------- reportes que le llegan a la dueña de The Edit Lab (solo los que le toca arreglar) ----------
def _correo_soporte():
    try:
        return json.load(open(os.path.join(PLUG, '.claude-plugin', 'plugin.json'), encoding='utf-8')).get('correo_soporte') or ''
    except Exception:
        return ''


def reporte_para_enviar(x):
    d = os.path.join(estudio(), '.the-edit-lab', 'reportes')
    nombre = os.path.basename(x.get('archivo') or '')
    if not nombre:
        L = sorted(glob.glob(os.path.join(d, 'reporte-*.md')), key=os.path.getmtime)
        nombre = os.path.basename(L[-1]) if L else ''
    if not nombre or not os.path.exists(os.path.join(d, nombre)):
        return {'ok': False, 'error': 'No encontré ese reporte.'}
    u = buscar_actualizacion(forzar=True)
    if u:
        return {'ok': False, 'error': 'Hay una versión más nueva (%s). Actualiza primero y prueba otra vez: muchas veces ya viene arreglado.' % u.get('version'), 'actualizar': True}
    f = os.path.join(estudio(), '.the-edit-lab', 'datos', 'reportes-por-enviar.json')
    try:
        L = json.load(open(f, encoding='utf-8'))
    except Exception:
        L = []
    L = [r_ for r_ in L if r_.get('archivo') != nombre] + [{'archivo': nombre, 'resumen': (x.get('resumen') or '').strip()[:1200], 'en': time.strftime('%Y-%m-%d %H:%M')}]
    json.dump(L[-10:], open(f, 'w', encoding='utf-8'), ensure_ascii=False)
    return {'ok': True}


def reportes_por_enviar():
    f = os.path.join(estudio(), '.the-edit-lab', 'datos', 'reportes-por-enviar.json')
    try:
        return json.load(open(f, encoding='utf-8'))
    except Exception:
        return []


def mostrar_reporte(nombre):
    p = os.path.join(estudio(), '.the-edit-lab', 'reportes', os.path.basename(nombre or ''))
    if not os.path.exists(p):
        return False
    try:
        if sys.platform == 'darwin':
            subprocess.Popen(['open', '-R', p])
        elif os.name == 'nt':
            subprocess.Popen(['explorer', '/select,', p])
        else:
            subprocess.Popen(['xdg-open', os.path.dirname(p)])
        return True
    except Exception:
        return False

def _obsoleto(texto):
    """Un pedido con reel y acci\u00f3n que ya no coincide con lo que ese reel espera (p. ej. pide 'aperturas' pero ya espera el storyboard) no vale la pena gastar a Claude."""
    try:
        x = json.loads(texto) if texto else None
        if not x or not x.get('reel') or not x.get('accion'):
            return False
        r = db_get('reels/' + x['reel'])
        if x['accion'] in ACCIONES_REEL:
            return _accion_que_espera(r) != x['accion']
        return bool(r.get('cancelado'))
    except Exception:
        return False


def _trabajador():
    """Una sola corrida a la vez. Lo que llega a la fila son solo «despiertas»: el pedido real se decide aquí, con el
    estado del reel en ese momento. Pedidos repetidos o viejos se descartan sin gastar a Claude."""
    while True:
        with CANDADO_CORRIDA:
            fila = CORRIDA['pendientes'][:]
            CORRIDA['pendientes'].clear()
        extra = []
        for t in fila:   # un pedido sin reel (de la página o del chat) se respeta tal cual, una sola vez
            try:
                x = json.loads(t) if t else None
            except Exception:
                x = None
            if t and (not isinstance(x, dict) or (not x.get('reel') and x.get('accion') not in (None, ''))) and t not in extra:
                extra.append(t)
        for t in extra:
            _correr(t)
        ped = None
        for _ in range(10 if fila else 1):   # la página despierta en cuanto tocas; su cambio puede tardar un instante en guardarse
            ped = _recuperable()
            if ped:
                break
            if fila:
                time.sleep(0.5)
        if ped is None:
            with CANDADO_CORRIDA:
                if CORRIDA['pendientes']:
                    continue
                CORRIDA['hilo'] = None
                return
        _correr(ped)


def despertar(texto=None):
    """Pone un pedido en la fila. Una sola corrida a la vez; los pedidos esperan su turno."""
    with CANDADO_CORRIDA:
        if texto in CORRIDA['pendientes']:
            return
        CORRIDA['pendientes'].append(texto)
        if not CORRIDA.get('hilo'):
            CORRIDA['hilo'] = threading.Thread(target=_trabajador, daemon=True)
            CORRIDA['hilo'].start()


GRUPOS_MEDIA = [  # lo que ella puede poner en una parte del video: (id, nombre, prefijo de su carpeta en Brand Assets)
    ('stickers', 'Stickers y gráficos', '04'), ('fondos', 'Fondos', '03'),
    ('contenido', 'Mi contenido', '06'), ('broll', 'B-roll', '08'), ('logos', 'Logo', '01'),
]
EXT_MEDIA = ('.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg', '.mp4', '.mov', '.m4v', '.webm', '.wav', '.mp3', '.m4a', '.aac', '.aif', '.aiff', '.ogg')


def media_lista():
    """Lee sus archivos de Brand Assets en vivo (si agregó algo hace un minuto, ya aparece)."""
    est, _ = rutas()
    base = os.path.join(est, 'Brand Assets')
    grupos = []
    if os.path.isdir(base):
        subs = sorted(n for n in os.listdir(base) if os.path.isdir(os.path.join(base, n)) and not n.startswith('.'))
        for gid, nombre, pre in GRUPOS_MEDIA:
            carpeta = next((n for n in subs if n.startswith(pre)), None)
            if not carpeta:
                continue
            d = os.path.join(base, carpeta)
            arch = [{'n': f, 'r': carpeta + '/' + f, 'v': f.lower().endswith(('.mp4', '.mov', '.m4v', '.webm'))}
                    for f in sorted(os.listdir(d))
                    if not f.startswith('.') and f.lower().endswith(EXT_MEDIA) and os.path.isfile(os.path.join(d, f))]
            grupos.append({'id': gid, 'nombre': nombre, 'carpeta': carpeta, 'archivos': arch[:300]})
    return grupos


def media_ruta(rel):
    """Ruta real de un archivo de Brand Assets; nunca sale de esa carpeta."""
    est, _ = rutas()
    base = os.path.realpath(os.path.join(est, 'Brand Assets'))
    p = os.path.realpath(os.path.join(base, rel))
    if not p.startswith(base + os.sep) or not os.path.isfile(p) or not p.lower().endswith(EXT_MEDIA):
        return None
    return p


PROMEDIO_BASE = {'analizar': 600, 'corte': 300, 'aperturas': 500, 'storyboard': 420, 'editar': 900, 'multiplicar': 600, 'limpiar': 60}


def _promedios():
    """Cuánto ha tardado cada fase en ESTA compu (mediana de las últimas corridas reales): con eso la página
    calcula el avance sin gastar a Claude en reportarlo."""
    out = dict(PROMEDIO_BASE)
    try:
        por = {}
        with open(os.path.join(estudio(), '.the-edit-lab', 'registros', 'tiempos.jsonl'), encoding='utf-8') as f:
            for ln in f.read().splitlines()[-200:]:
                try:
                    x = json.loads(ln)
                except Exception:
                    continue
                if x.get('accion') and (x.get('segundos') or 0) >= 90:
                    por.setdefault(x['accion'], []).append(x['segundos'])
        for k, v in por.items():
            v = sorted(v[-7:])
            out[k] = v[len(v) // 2]
    except Exception:
        pass
    return out


def _mini(p):
    """Miniatura chica (y guardada) de una imagen o video de Brand Assets, para que la página no cargue los archivos completos."""
    try:
        if p.lower().endswith('.svg'):
            return p
        import hashlib
        d = os.path.join(estudio(), '.the-edit-lab', 'datos', 'minis')
        os.makedirs(d, exist_ok=True)
        st = os.stat(p)
        ext = '.png' if p.lower().endswith(('.png', '.webp', '.gif')) else '.jpg'
        out = os.path.join(d, hashlib.sha1(('%s|%s|%s' % (p, st.st_mtime_ns, st.st_size)).encode()).hexdigest()[:20] + ext)
        if not os.path.isfile(out):
            env = dict(os.environ)
            env['PATH'] = os.pathsep.join([os.path.expanduser('~/.cvs-motor/bin'), '/opt/homebrew/bin', '/usr/local/bin', env.get('PATH', '')])
            ff = shutil.which('ffmpeg', path=env['PATH'])
            if not ff:
                return p if st.st_size < 3 * 1048576 and not p.lower().endswith(VIDEO_EXT + ('.webm',)) else None
            tmp = out + '.tmp' + ext
            subprocess.run([ff, '-nostdin', '-v', 'error', '-y', '-i', p, '-frames:v', '1', '-vf', "scale='min(160,iw)':-2", tmp],
                           env=env, timeout=40, capture_output=True)
            if os.path.isfile(tmp) and os.path.getsize(tmp) > 0:
                os.replace(tmp, out)
            else:
                return p if st.st_size < 3 * 1048576 and not p.lower().endswith(VIDEO_EXT + ('.webm',)) else None
        return out
    except Exception:
        return None


def colores_de_carpeta(base=None):
    """Lee los colores de su marca de un archivo de texto (.txt, .rtf, .md, .doc, .docx) dentro de su carpeta de colores
    (Brand Assets/02 …): códigos HEX (#FED9EA) y, si no hay, ternas RGB (254, 217, 234). En el orden en que aparecen."""
    est, _ = rutas()
    base = base or os.path.join(est, 'Brand Assets')
    try:
        car = next((n for n in sorted(os.listdir(base)) if n.startswith('02') and os.path.isdir(os.path.join(base, n))), None)
    except Exception:
        car = None
    if not car:
        return {'colores': [], 'archivo': None, 'carpeta': None}
    d = os.path.join(base, car)
    cols, usado = [], None
    for f in sorted(os.listdir(d)):
        fp = os.path.join(d, f)
        if f.startswith(('.', '~')) or not os.path.isfile(fp) or not f.lower().endswith(('.txt', '.rtf', '.md', '.doc', '.docx')):
            continue
        try:
            raw = open(fp, 'rb').read(4 * 1048576)
            textos = []
            if f.lower().endswith('.docx'):
                import zipfile
                with zipfile.ZipFile(fp) as z:
                    textos.append(re.sub(r'<[^>]+>', '', z.read('word/document.xml').decode('utf-8', 'ignore')))
            else:
                textos.append(raw.decode('utf-8', 'ignore'))
                textos.append(raw.decode('latin-1', 'ignore'))
                if f.lower().endswith('.doc'):
                    textos.append(raw.decode('utf-16-le', 'ignore'))
            enc = []
            for t in textos:
                enc = ['#' + m.upper() for m in re.findall(r'#([0-9A-Fa-f]{6})(?![0-9A-Fa-f])', t)]
                if not enc and not f.lower().endswith(('.rtf', '.doc')):
                    for a, b, c in re.findall(r'(?<![\d.])(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})(?![\d.])', t):
                        if max(int(a), int(b), int(c)) <= 255:
                            enc.append('#%02X%02X%02X' % (int(a), int(b), int(c)))
                if enc:
                    break
            for c in enc:
                if c not in cols:
                    cols.append(c)
            if enc and not usado:
                usado = f
        except Exception:
            continue
    return {'colores': cols[:24], 'archivo': usado, 'carpeta': car}


# ---------- vista previa real del editor (el mismo Main.tsx del video final, en @remotion/player) ----------
MOTOR = os.path.expanduser('~/.cvs-motor/remotion')
PLAYER = {'instalando': False, 'error': None}


def _motor_listo():
    return os.path.isdir(os.path.join(MOTOR, 'node_modules', '@remotion', 'player')) and os.path.isdir(os.path.join(MOTOR, 'node_modules', 'esbuild'))


def _instalar_player():
    if PLAYER['instalando'] or _motor_listo():
        return
    PLAYER['instalando'] = True; PLAYER['error'] = None
    def _go():
        try:
            ver = '4.0.540'
            try:
                ver = json.load(open(os.path.join(MOTOR, 'node_modules', 'remotion', 'package.json')))['version']
            except Exception:
                pass
            npm = 'npm.cmd' if os.name == 'nt' else 'npm'
            env = dict(os.environ); env['PATH'] = os.pathsep.join(['/opt/homebrew/bin', '/usr/local/bin', env.get('PATH', '')])
            p = subprocess.run([npm, 'install', '--no-audit', '--no-fund', '--loglevel=error', '@remotion/player@' + ver, 'esbuild'], cwd=MOTOR,
                               capture_output=True, text=True, timeout=900, env=env)
            if p.returncode != 0:
                PLAYER['error'] = (p.stderr or p.stdout)[-300:]
        except Exception as ex:
            PLAYER['error'] = str(ex)[:300]
        PLAYER['instalando'] = False
    threading.Thread(target=_go, daemon=True).start()


def _player_bundle(rid):
    """Arma (o reusa) la vista previa para el estilo de ese reel: Main.tsx + sus efectos propios. Devuelve la ruta del .js."""
    import hashlib
    est, _ = rutas()
    plant = os.path.join(PLUG, 'skills', 'editar-video', 'remotion-template')
    props_dir = os.path.join(est, 'Proyectos', rid, 'estilo', 'efectos-propios')
    if not os.path.isdir(props_dir):
        props_dir = os.path.join(est, 'efectos-propios')
    h = hashlib.sha1()
    for f in ('src/Main.tsx', 'src/player-entry.tsx', 'build-player.mjs'):
        h.update(open(os.path.join(plant, f), 'rb').read())
    props = sorted(glob.glob(os.path.join(props_dir, '*.tsx'))) if os.path.isdir(props_dir) else []
    for f in props:
        h.update(os.path.basename(f).encode()); h.update(open(f, 'rb').read())
    k = h.hexdigest()[:16]
    d = os.path.join(est, '.the-edit-lab', 'datos', 'player'); os.makedirs(d, exist_ok=True)
    out = os.path.join(d, k + '.js')
    if os.path.exists(out):
        return out, k
    b = os.path.join(d, 'src_' + k); shutil.rmtree(b, ignore_errors=True); os.makedirs(os.path.join(b, 'propios'))
    for f in ('Main.tsx', 'player-entry.tsx'):
        shutil.copy(os.path.join(plant, 'src', f), os.path.join(b, f))
    kinds = []
    for f in props:
        n = os.path.splitext(os.path.basename(f))[0]
        if re.fullmatch(r'[a-z][a-z0-9_]*', n):
            shutil.copy(f, os.path.join(b, 'propios', n + '.tsx')); kinds.append(n)
    with open(os.path.join(b, 'propios', 'index.ts'), 'w') as fh:
        fh.write(''.join("import %s from './%s';\n" % (n, n) for n in kinds))
        fh.write('export const PROPIOS: Record<string, any> = {' + ', '.join(kinds) + '};\n')
    for j in ('timeline.json', 'cues.json', 'cara.json', 'estilo.json'):
        open(os.path.join(b, j), 'w').write('{}')
    node = shutil.which('node') or '/opt/homebrew/bin/node'
    p = subprocess.run([node, os.path.join(plant, 'build-player.mjs'), b, out], cwd=MOTOR, capture_output=True, text=True, timeout=300)
    shutil.rmtree(b, ignore_errors=True)
    if p.returncode != 0 or not os.path.exists(out):
        raise RuntimeError((p.stderr or p.stdout)[-400:])
    return out, k


def _player_datos(rid, x):
    """Calcula los efectos EXACTOS de la versión final para el plan y los cortes que ella tiene en el editor (cues.py)."""
    import tempfile
    est, _ = rutas()
    P = os.path.join(est, 'Proyectos', rid); TR = os.path.join(P, 'trabajo')
    estp = os.path.join(P, 'estilo', 'estilo.json')
    if not os.path.exists(estp) or not os.path.exists(os.path.join(TR, 'timeline.json')):
        return {'error': 'Este Reel ya no tiene sus archivos de edición; la vista previa exacta no está disponible.'}
    tl0 = json.load(open(os.path.join(TR, 'timeline.json'), encoding='utf-8'))
    segs = x.get('segs') or []
    # Si sus cortes son los mismos con los que se hizo su video, la vista usa SU corte real (base.mp4, con las orillas
    # afinadas por el sonido y las uniones fundidas) y sus tiempos reales: queda idéntica al final, cuadro por cuadro.
    def _k(L):
        return [(round(float(q.get('d', 0)), 3), round(float(q.get('h', 0)), 3), float(q.get('vel') or 1), q.get('zoom') or '') for q in (L or [])]
    r = db_get('reels/' + rid) or {}
    usa_base = bool(segs) and os.path.exists(os.path.join(TR, 'base.mp4')) and _k(segs) == _k(r.get('segmentosEditados'))
    if usa_base:
        segs = []; x = dict(x); x['words'] = None
    acc, clips = 0.0, []
    for s_ in segs:
        v = float(s_.get('vel') or 1); L = (float(s_['h']) - float(s_['d'])) / v
        clips.append({'archivo': 1, 'in': s_['d'], 'out': s_['h'], 't0': round(acc, 4), 't0_real': round(acc, 4), 'frames': max(1, round(L * 30))}); acc += L
    words = [{'w': w.get('t') or w.get('w'), 's': w['s'], 'e': w['e']} for w in (x.get('words') or [])]
    tl = {'clips': clips or tl0.get('clips', []), 'words': words if x.get('words') is not None else tl0.get('words', []),
          'duration': round(acc, 4) if clips else tl0.get('duration_real'), 'duration_real': round(acc, 4) if clips else tl0.get('duration_real')}
    plan = x.get('plan') or {'efectos': [], 'acercamientos': []}
    def _cues(tl_, plan_):
        t_ = tempfile.mkdtemp(prefix='tel_')
        try:
            if os.path.exists(os.path.join(TR, 'cara.json')): shutil.copy(os.path.join(TR, 'cara.json'), os.path.join(t_, 'cara.json'))
            json.dump(tl_, open(os.path.join(t_, 'timeline.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            json.dump(plan_, open(os.path.join(t_, 'plan.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            emoji_ = os.path.join(MOTOR, 'node_modules', 'emoji-datasource-google', 'img', 'google', '64')
            p_ = subprocess.run([_python_motor(), os.path.join(PLUG, 'skills', 'editar-video', 'scripts', 'cues.py'), t_, '--estilo', estp, '--emoji', emoji_,
                                 '--publico', os.path.join(MOTOR, 'public')], capture_output=True, text=True, timeout=120)
            c_ = json.load(open(os.path.join(t_, 'cues.json'), encoding='utf-8')) if os.path.exists(os.path.join(t_, 'cues.json')) else None
            return c_, p_
        finally:
            shutil.rmtree(t_, ignore_errors=True)
    tmp = tempfile.mkdtemp(prefix='tel_')
    try:
        for f in ('cara.json',):
            if os.path.exists(os.path.join(TR, f)): shutil.copy(os.path.join(TR, f), os.path.join(tmp, f))
        json.dump(tl, open(os.path.join(tmp, 'timeline.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        json.dump(x.get('plan') or {'efectos': [], 'acercamientos': []}, open(os.path.join(tmp, 'plan.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        emoji = os.path.join(MOTOR, 'node_modules', 'emoji-datasource-google', 'img', 'google', '64')
        p = subprocess.run([_python_motor(), os.path.join(PLUG, 'skills', 'editar-video', 'scripts', 'cues.py'), tmp, '--estilo', estp, '--emoji', emoji,
                            '--publico', os.path.join(MOTOR, 'public')], capture_output=True, text=True, timeout=120)
        if not os.path.exists(os.path.join(tmp, 'cues.json')):
            return {'error': ((p.stdout or '') + (p.stderr or ''))[-400:]}
        cues = json.load(open(os.path.join(tmp, 'cues.json'), encoding='utf-8'))
        cues = _con_ajustes(TR, tl0, cues, _cues)
        probl = [l.strip()[2:] for l in (p.stdout or '').splitlines() if l.strip().startswith('- ')]
        movidos = [l.split(': ', 1)[-1] for l in (p.stdout or '').splitlines() if l.startswith('MOVÍ')]
        cara = json.load(open(os.path.join(tmp, 'cara.json'), encoding='utf-8')) if os.path.exists(os.path.join(tmp, 'cara.json')) else {}
        voz, sin_sfx = None, False
        if usa_base:   # base.mp4 no trae sonido: su voz cortada (y los efectos en vivo), o la mezcla final completa
            import wave
            def _dur(f):
                try:
                    with wave.open(f) as w_: return w_.getnframes() / float(w_.getframerate())
                except Exception: return -1
            D = float(tl.get('duration_real') or 0)
            for f in ('_voz_limpia.wav', 'voz.wav', 'a1_dn.wav', 'a1.wav'):
                if os.path.exists(os.path.join(TR, f)) and abs(_dur(os.path.join(TR, f)) - D) < 0.5:
                    voz = f; break
            if not voz:
                for f in ('mezcla.wav', '_final16.wav'):
                    if os.path.exists(os.path.join(TR, f)):
                        voz, sin_sfx = f, True; break
        return {'tl': tl, 'cues': cues, 'cara': cara, 'estilo': json.load(open(estp, encoding='utf-8')), 'problemas': probl, 'movidos': movidos, 'base': usa_base,
                'voz': voz, 'sinSfx': sin_sfx}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _llave_ov(o):
    """Qué es un efecto sin importar cuándo sale: para reconocer el mismo efecto aunque se haya movido en el tiempo."""
    q = {k: v for k, v in o.items() if k not in ('t0', 't1')}
    return json.dumps(q, sort_keys=True, ensure_ascii=False)


def _con_ajustes(TR, tl0, cues, calc):
    """Después de armar su video, Claude a veces ajusta a mano algún efecto en cues.json (posición, tamaño, tiempos).
    Esos ajustes no están en el plan. Aquí se reconocen (lo que el plan daba vs lo que quedó en su video) y se vuelven a
    poner en cada efecto que ella no cambió, para que el editor muestre su video tal cual es."""
    fin_p, plan_p = os.path.join(TR, 'cues.json'), os.path.join(TR, 'plan.json')
    if not (os.path.exists(fin_p) and os.path.exists(plan_p)):
        return cues
    try:
        fin = json.load(open(fin_p, encoding='utf-8'))
        cache = os.path.join(TR, '.cues_del_plan.json')
        firma = '%s:%s:%s' % (os.path.getmtime(plan_p), os.path.getmtime(fin_p), os.path.getmtime(os.path.join(TR, 'timeline.json')))
        c0 = None
        if os.path.exists(cache):
            j = json.load(open(cache, encoding='utf-8'))
            if j.get('firma') == firma: c0 = j['cues']
        if c0 is None:
            c0, _p = calc(tl0, json.load(open(plan_p, encoding='utf-8')))
            if not c0: return cues
            json.dump({'firma': firma, 'cues': c0}, open(cache, 'w', encoding='utf-8'), ensure_ascii=False)
        A, F = c0.get('overlays') or [], fin.get('overlays') or []
        if len(A) != len(F):
            return cues
        mapa = {}
        for a_, f_ in zip(A, F):
            if a_ != f_: mapa.setdefault(_llave_ov(a_), (a_, f_))
        out = []
        for o in cues.get('overlays') or []:
            m = mapa.get(_llave_ov(o))
            if m:
                a_, f_ = m; d = float(o.get('t0', 0)) - float(a_.get('t0', 0))
                n = dict(f_)
                for k in ('t0', 't1'):
                    if k in n: n[k] = round(float(n[k]) + d, 4)
                o = n
            out.append(o)
        cues = dict(cues); cues['overlays'] = out
        for k in fin:   # partes del video que no dependen del plan (p. ej. sonidos ajustados): si el plan daba lo mismo, se toman del video
            if k != 'overlays' and c0.get(k) == cues.get(k): cues[k] = fin[k]
    except Exception:
        pass
    return cues


def _player_archivo(rid, rel):
    """Los archivos que pide la vista previa (video, fuentes, stickers, sonidos, imágenes): solo de sus carpetas."""
    est, _ = rutas()
    rel = rel.replace('\\', '/').lstrip('/')
    if '..' in rel.split('/'):
        return None
    if rel == 'fuente.mp4':
        r = db_get('reels/' + rid) or {}
        return asset_ruta(r['fuenteId']) if r.get('fuenteId') else None
    P = os.path.join(est, 'Proyectos', rid); BA = os.path.join(est, 'Brand Assets'); nom = os.path.basename(rel)
    cands = []
    if rel.startswith('fonts/'):
        cands += [os.path.join(MOTOR, 'public', rel), os.path.expanduser('~/.cvs-motor/fuentes/' + nom)] + glob.glob(os.path.join(BA, '*', nom)) + glob.glob(os.path.join(est, 'Fuentes', nom))
    elif rel.startswith('sfx/'):
        for d in ([os.path.join(BA, n) for n in sorted(os.listdir(BA)) if n.startswith(('07', '09'))] if os.path.isdir(BA) else []) + [os.path.join(est, 'Efectos de sonido'), os.path.join(est, 'Mis efectos')]:
            cands.append(os.path.join(d, nom))
    elif rel.startswith('mis/'):
        cands += [os.path.join(est, '.motor', 'mis', nom), os.path.join(MOTOR, 'public', rel)]
    cands += [os.path.join(P, rel), os.path.join(P, 'trabajo', rel), os.path.join(P, 'crudo', rel), os.path.join(P, 'apoyo', rel), os.path.join(MOTOR, 'public', rel)]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return None


# ---------- servidor ----------
class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _cuerpo(self):
        n = int(self.headers.get('Content-Length') or 0)
        return self.rfile.read(n) if n else b''

    def _local(self):
        h = (self.headers.get('Host') or '').split(':')[0]
        return h in ('localhost', '127.0.0.1')

    def _archivo(self, p, tipo, cache=False):
        tam = os.path.getsize(p)
        rango = self.headers.get('Range')
        ini, fin = 0, tam - 1
        if rango and rango.startswith('bytes='):
            a, _, b2 = rango[6:].partition('-')
            ini = int(a) if a else 0
            fin = int(b2) if b2 else tam - 1
            self.send_response(206)
            self.send_header('Content-Range', f'bytes {ini}-{fin}/{tam}')
        else:
            self.send_response(200)
        self.send_header('Content-Type', tipo)
        self.send_header('Accept-Ranges', 'bytes')
        if cache:
            self.send_header('Cache-Control', 'max-age=300')
        self.send_header('Content-Length', str(fin - ini + 1))
        self.end_headers()
        with open(p, 'rb') as f:
            f.seek(ini)
            falta = fin - ini + 1
            while falta > 0:
                trozo = f.read(min(1 << 20, falta))
                if not trozo:
                    break
                try:
                    self.wfile.write(trozo)
                except (BrokenPipeError, ConnectionResetError):
                    return
                falta -= len(trozo)

    def do_GET(self):
        if not self._local():
            return self._json({'error': 'solo local'}, 403)
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path in ('/', '/index.html'):
            with open(PAGINA, encoding='utf-8') as f:
                html = f.read()
            with open(SHIM, encoding='utf-8') as f:
                shim = f.read()
            html = html.replace('<head>', '<head><script>' + shim + '</script>', 1)
            b = html.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(b)))
            self.end_headers()
            return self.wfile.write(b)
        if u.path == '/api/player/preparar':
            rid = (q.get('reel') or [''])[0]
            if not _motor_listo():
                _instalar_player()
                return self._json({'estado': 'instalando', 'error': PLAYER.get('error')})
            try:
                _, k = _player_bundle(rid)
                pf = os.path.join(estudio(), 'Proyectos', rid, 'trabajo', 'plan.json')
                plan = None
                try:
                    plan = json.load(open(pf, encoding='utf-8')) if os.path.exists(pf) else None
                except Exception:
                    plan = None
                return self._json({'estado': 'listo', 'js': '/api/player/js?k=' + k, 'plan': plan})
            except Exception as ex:
                return self._json({'estado': 'error', 'error': str(ex)[:400]})
        if u.path == '/api/player/js':
            k = re.sub(r'[^0-9a-f]', '', (q.get('k') or [''])[0])
            pth = os.path.join(estudio(), '.the-edit-lab', 'datos', 'player', k + '.js')
            if not k or not os.path.exists(pth):
                return self._json({'error': 'no existe'}, 404)
            return self._archivo(pth, 'text/javascript', True)
        if u.path.startswith('/player/'):
            partes = u.path.split('/', 4)     # ['', 'player', <reel>, 'f', <ruta>]
            if len(partes) == 5 and partes[3] == 'f':
                pth = _player_archivo(partes[2], unquote(partes[4]))
                if pth:
                    return self._archivo(pth, mimetypes.guess_type(pth)[0] or 'application/octet-stream', True)
            return self._json({'error': 'no existe'}, 404)
        if u.path in ('/api/hooks/lista', '/api/hooks/video'):
            est, _ = rutas()
            r = db_get('reels/' + (q.get('reel') or [''])[0]) or {}
            carp = os.path.basename(str(r.get('carpeta') or '').strip('/'))
            hd = os.path.join(est, 'Reels', carp, 'Hooks') if carp else ''
            if u.path == '/api/hooks/lista':
                L = []
                if hd and os.path.isdir(hd):
                    for f in sorted(os.listdir(hd)):
                        fp = os.path.join(hd, f)
                        if f.lower().endswith(VIDEO_EXT) and not f.startswith('.') and os.path.isfile(fp):
                            L.append({'nombre': f, 'mb': round(os.path.getsize(fp) / 1048576, 1), 'mtime': int(os.path.getmtime(fp))})
                return self._json({'carpeta': hd, 'existe': bool(hd and os.path.isdir(hd)), 'clips': L})
            n = os.path.basename((q.get('n') or [''])[0])
            fp = os.path.join(hd, n) if hd else ''
            if not n or not os.path.isfile(fp):
                return self._json({'error': 'no existe'}, 404)
            return self._archivo(fp, mimetypes.guess_type(fp)[0] or 'video/mp4', True)
        if u.path == '/api/brand/lista':
            return self._json({'grupos': media_lista()})
        if u.path == '/api/brand/archivo':
            p = media_ruta((q.get('r') or [''])[0])
            if not p:
                return self._json({'error': 'no existe'}, 404)
            return self._archivo(p, mimetypes.guess_type(p)[0] or 'application/octet-stream', True)
        if u.path.startswith('/_blob/'):
            aid = os.path.basename(u.path)
            p = asset_ruta(aid)
            if not os.path.isfile(p):
                return self._json({'error': 'no existe'}, 404)
            tipo = asset_meta().get(aid, {}).get('tipo') or 'application/octet-stream'
            return self._archivo(p, tipo)
            return
        if u.path == '/api/db/doc':
            d = db_get(q['path'][0])
            return self._json({'exists': d is not None, 'data': d, 'v': db_version()})
        if u.path == '/api/db/col':
            return self._json({'docs': db_list(q['col'][0]), 'v': db_version()})
        if u.path == '/api/db/v':
            return self._json({'v': db_version()})
        if u.path == '/api/assets':
            m = asset_meta()
            lista, total = [], 0
            for aid, x in m.items():
                p = asset_ruta(aid)
                if os.path.isfile(p):
                    t = os.path.getsize(p)
                    total += t
                    lista.append({'id': aid, 'contentType': x.get('tipo'), 'sizeBytes': t, 'name': x.get('nombre')})
            return self._json({'assets': lista, 'usage': {'bytes': total, 'maxBytes': 1 << 40}})
        if u.path == '/api/licencia':
            return self._json(licencia.estado())
        if u.path == '/api/quien':
            return self._json({'app': 'the-edit-lab', 'estudio': estudio(), 'version': _version()})
        if u.path == '/api/avisos':
            return self._json({'avisos': avisos_leer()})
        if u.path == '/api/actualizar/estado':
            return self._json(dict(ACT, version=_version()))
        if u.path == '/api/notificaciones':
            return self._json({'items': notificaciones(), 'version': _version()})
        if u.path == '/api/estado':
            return self._json({'activa': CORRIDA['activa'], 'ultima': CORRIDA['ultima'], 'en_fila': len(CORRIDA['pendientes']), 'version': _version(),
                               'ahora': time.time(), 'promedios': _promedios()})
        if u.path == '/api/brand/mini':
            p = media_ruta((q.get('r') or [''])[0])
            m = _mini(p) if p else None
            if not m:
                return self._json({'error': 'no existe'}, 404)
            return self._archivo(m, mimetypes.guess_type(m)[0] or 'image/jpeg', True)
        if u.path == '/api/brand/colores':
            return self._json(colores_de_carpeta())
        if u.path == '/api/marca/archivos':
            return self._json(marca_archivos((q.get('c') or ['Brand Assets'])[0], (q.get('propia') or [''])[0] == '1'))
        if u.path == '/api/marca/fuente-editor':
            n = (q.get('n') or [''])[0]
            if n not in ('Inter-Bold.ttf', 'Anton-Regular.ttf', 'InstrumentSerif-Regular.ttf', 'Caveat-Bold.ttf'):
                return self._json({'error': 'no existe'}, 404)
            fp = os.path.join(os.path.expanduser('~/.cvs-motor'), 'fuentes', n)
            if not os.path.isfile(fp):
                return self._json({'error': 'no existe'}, 404)
            return self._archivo(fp, 'font/ttf', True)
        if u.path in ('/api/marca/mini', '/api/marca/archivo'):
            p = _ruta_marca((q.get('r') or [''])[0])
            if not p or not os.path.isfile(p):
                return self._json({'error': 'no existe'}, 404)
            if u.path == '/api/marca/mini':
                m = _mini(p) if p.lower().endswith(EXT_MEDIA) else None
                if not m:
                    return self._json({'error': 'no existe'}, 404)
                return self._archivo(m, mimetypes.guess_type(m)[0] or 'image/jpeg', True)
            return self._archivo(p, mimetypes.guess_type(p)[0] or 'application/octet-stream', True)
        return self._json({'error': 'no existe'}, 404)

    def do_POST(self):
        if not self._local():
            return self._json({'error': 'solo local'}, 403)
        u = urlparse(self.path)
        try:
            if u.path == '/api/db':
                x = json.loads(self._cuerpo() or b'{}')
                path = db_escribir(x['op'], x['path'], x.get('data'))
                return self._json({'ok': True, 'path': path, 'id': path.split('/')[-1]})
            if u.path == '/api/assets':
                aid = uuid.uuid4().hex
                n = int(self.headers.get('Content-Length') or 0)
                with open(asset_ruta(aid), 'wb') as f:
                    falta = n
                    while falta > 0:
                        trozo = self.rfile.read(min(1 << 20, falta))
                        if not trozo:
                            break
                        f.write(trozo)
                        falta -= len(trozo)
                tipo = self.headers.get('X-Tipo') or 'application/octet-stream'
                nombre = unquote(self.headers.get('X-Nombre') or '')
                with Bloqueo():
                    m = asset_meta()
                    m[aid] = {'tipo': tipo, 'nombre': nombre, 'creado': time.time()}
                    asset_guardar_meta(m)
                return self._json({'id': aid, 'contentType': tipo, 'sizeBytes': n, 'url': '/_blob/' + aid})
            if u.path == '/api/assets/borrar':
                x = json.loads(self._cuerpo() or b'{}')
                aid = os.path.basename(x.get('id', ''))
                try:
                    os.remove(asset_ruta(aid))
                except FileNotFoundError:
                    pass
                with Bloqueo():
                    m = asset_meta()
                    m.pop(aid, None)
                    asset_guardar_meta(m)
                return self._json({'ok': True})
            if u.path == '/api/player/datos':
                x = json.loads(self._cuerpo() or b'{}')
                rid = str(x.get('reel') or '')
                if not re.fullmatch(r'[0-9A-Za-z]{2,40}', rid):
                    return self._json({'error': 'no existe'}, 404)
                return self._json(_player_datos(rid, x))
            if u.path == '/api/capcut':
                x = json.loads(self._cuerpo() or b'{}')
                rid = str(x.get('reel') or '')
                r = db_get('reels/' + rid) if re.fullmatch(r'[0-9A-Za-z]{8,40}', rid) else None
                if not r:
                    return self._json({'error': 'no existe'}, 404)
                est, _ = rutas()
                P = os.path.join(est, 'Proyectos', rid)
                if not os.path.exists(os.path.join(P, 'trabajo', 'timeline.json')):
                    return self._json({'ok': False, 'error': 'Este Reel ya no tiene sus archivos de edición (se limpiaron). Vuelve a editarlo para exportarlo a CapCut.'})
                _cc_abierto = False
                try:
                    if sys.platform == 'darwin':
                        _cc_abierto = subprocess.run(['pgrep', '-x', 'CapCut'], capture_output=True).returncode == 0
                    elif os.name == 'nt':
                        _cc_abierto = 'CapCut.exe' in subprocess.run(['tasklist', '/FI', 'IMAGENAME eq CapCut.exe'], capture_output=True, text=True).stdout
                except Exception:
                    pass
                if _cc_abierto:
                    return self._json({'ok': False, 'abierto': True, 'error': 'Cierra CapCut (en Mac Cmd+Q; en Windows ciérralo por completo) y vuelve a tocar Exportar: si está abierto, borra lo que se agrega.'})
                db_escribir('merge', 'reels/' + rid, {'capcut': {'estado': 'Exportando', 'en': time.time()}})
                def _exportar():
                    args = [_python_motor(), os.path.join(PLUG, 'skills', 'editar-video', 'scripts', 'capcut.py'), P, '--estudio', est,
                            '--carpeta', os.path.basename(str(r.get('carpeta') or '').strip('/')), '--nombre', r.get('nombre') or 'Reel']
                    try:
                        p = subprocess.run(args, capture_output=True, text=True, timeout=3600)
                        lin = [l for l in (p.stdout or '').splitlines() if l.startswith('CAPCUT ')]
                        if lin:
                            res = json.loads(lin[-1][7:])
                            db_escribir('merge', 'reels/' + rid, {'capcut': dict(res, estado='Listo', en=time.time())})
                        else:
                            msg = 'Cierra CapCut y vuelve a intentar.' if 'CAPCUT_ABIERTO' in (p.stdout or '') else ((p.stderr or p.stdout or '').strip().splitlines() or ['No se pudo exportar.'])[-1][:300]
                            db_escribir('merge', 'reels/' + rid, {'capcut': {'estado': 'Error', 'error': msg, 'en': time.time()}})
                            _incidente('Exportar a CapCut falló (%s): %s' % (r.get('nombre'), (p.stderr or '')[-600:]))
                    except Exception as ex:
                        db_escribir('merge', 'reels/' + rid, {'capcut': {'estado': 'Error', 'error': str(ex)[:300], 'en': time.time()}})
                threading.Thread(target=_exportar, daemon=True).start()
                return self._json({'ok': True})
            if u.path == '/api/reel/limpiar':
                # Al quitar un Reel: borra su carpeta de trabajo y su análisis. Nunca toca el original,
                # Resultado final (antes, después, Multiplica) ni Hooks.
                x = json.loads(self._cuerpo() or b'{}')
                est, _ = rutas()
                rid = str(x.get('id') or '')
                hechos = []
                if re.fullmatch(r'[0-9A-Za-z]{8,40}', rid):
                    pr = os.path.join(est, 'Proyectos')
                    if os.path.isdir(pr):
                        for n in os.listdir(pr):
                            if n == rid or n.startswith(rid + '_'):
                                shutil.rmtree(os.path.join(pr, n), ignore_errors=True)
                                hechos.append('Proyectos/' + n)
                carp = os.path.basename(str(x.get('carpeta') or '').strip('/'))
                if carp and carp not in ('.', '..'):
                    st = os.path.join(est, 'Reels', carp, '.studio')
                    if os.path.isdir(st) and not os.path.islink(st):
                        shutil.rmtree(st, ignore_errors=True)
                        hechos.append('Reels/' + carp + '/.studio')
                return self._json({'ok': True, 'borrado': hechos})
            if u.path == '/api/licencia':
                x = json.loads(self._cuerpo() or b'{}')
                return self._json(licencia.activar(x.get('correo', ''), x.get('clave', '')))
            if u.path == '/api/marca/borrar':
                x = json.loads(self._cuerpo() or b'{}')
                return self._json(marca_borrar(x.get('carpeta')))
            if u.path == '/api/marca/carpeta':
                x = json.loads(self._cuerpo() or b'{}')
                return self._json({'ok': True, 'carpeta': marca_carpeta(x.get('nombre'))})
            if u.path == '/api/brand/refrescar':
                preparar_brand_kit()
                return self._json({'ok': True})
            if u.path == '/api/reels/refrescar':
                listar_reels()
                db_escribir('merge', 'studio/config', {'carpetaEstado': 'Conectada'})
                return self._json({'ok': True})
            if u.path == '/api/notificaciones/vistas':
                notificaciones_vistas(json.loads(self._cuerpo() or b'{}').get('ids'))
                return self._json({'ok': True})
            if u.path == '/api/actualizar':
                return self._json(actualizar_ahora())
            if u.path == '/api/reporte/enviar':
                return self._json(reporte_para_enviar(json.loads(self._cuerpo() or b'{}')))
            if u.path == '/api/reporte/mostrar':
                return self._json({'ok': mostrar_reporte(json.loads(self._cuerpo() or b'{}').get('archivo'))})
            if u.path == '/api/reporte/enviado':
                n_ = json.loads(self._cuerpo() or b'{}').get('archivo')
                f_ = os.path.join(estudio(), '.the-edit-lab', 'datos', 'reportes-por-enviar.json')
                json.dump([r_ for r_ in reportes_por_enviar() if r_.get('archivo') != n_], open(f_, 'w', encoding='utf-8'), ensure_ascii=False)
                return self._json({'ok': True})
            if u.path == '/api/reporte':
                return self._json(hacer_reporte(json.loads(self._cuerpo() or b'{}')))
            if u.path == '/api/avisos/cerrar':
                x = json.loads(self._cuerpo() or b'{}')
                with AVISOS_LOCK:
                    _avisos_guardar([a for a in avisos_leer() if x.get('id') and a.get('id') != x['id']] if x.get('id') else [])
                return self._json({'ok': True})
            if u.path == '/api/retomar':
                if CORRIDA.get('activa') or CORRIDA.get('hilo'):
                    return self._json({'ok': True, 'retomado': True, 'yaTrabajando': True})
                ped = _recuperable(forzar=True)
                if ped:
                    despertar(ped)
                return self._json({'ok': True, 'retomado': bool(ped)})
            if u.path == '/api/claude/cancelar':
                return self._json({'ok': True, 'detenido': cancelar_corrida()})
            if u.path == '/api/claude':
                if not licencia.estado().get('ok'):
                    return self._json({'error': 'Activa tu licencia de The Edit Lab para editar.', 'code': 'licencia'}, 403)
                x = json.loads(self._cuerpo() or b'{}')
                despertar(x.get('text'))
                return self._json({'ok': True, 'payload': {'ok': True}})
        except KeyError as e:
            return self._json({'error': str(e), 'code': 'not_found'}, 404)
        except Exception as e:
            return self._json({'error': str(e)}, 500)
        return self._json({'error': 'no existe'}, 404)


VIDEO_EXT = ('.mp4', '.mov', '.m4v')


def listar_reels():
    """Lee sus carpetas de Reels directo del disco (en la nube esto lo hacía la editora; aquí es instantáneo)."""
    est, _ = rutas()
    raiz = os.path.join(est, 'Reels')
    carpetas = []
    if os.path.isdir(raiz):
        for n in sorted(os.listdir(raiz)):
            d = os.path.join(raiz, n)
            if n.startswith('.') or not os.path.isdir(d):
                continue
            vids = [{'nombre': f, 'mb': round(os.path.getsize(os.path.join(d, f)) / 1048576)}
                    for f in sorted(os.listdir(d)) if f.lower().endswith(VIDEO_EXT) and os.path.isfile(os.path.join(d, f))]
            rf = os.path.join(d, 'Resultado final')
            term = len([f for f in os.listdir(rf) if f.lower().endswith(VIDEO_EXT)]) if os.path.isdir(rf) else 0
            if vids:
                carpetas.append({'nombre': n, 'videos': vids, 'terminados': term})
    actual = db_get('studio/compu') or {}
    if actual.get('carpetas') != carpetas:
        db_escribir('set', 'studio/compu', {'raiz': 'Reels', 'carpetas': carpetas, 'revisadoEn': int(time.time() * 1000)})


def _vigilar_reels():
    while True:
        try:
            listar_reels()
        except Exception:
            pass
        try:
            if not CORRIDA.get('activa'):
                escuchar_reels()
        except Exception:
            pass
        time.sleep(4)


BRAND_KIT = {  # documento de la página → carpeta de Brand Assets que empieza con ese número
    'tipografias': '01', 'logos': '01', 'colores': '02', 'fondos': '03', 'stickers': '04',
    'referencias': '05', 'contenido': '06', 'sonidos': '07', 'broll': '08', 'musica': '09',
}
EXT_KIT = {
    'tipografias': ('.ttf', '.otf', '.woff', '.woff2'), 'logos': ('.png', '.svg', '.jpg', '.jpeg', '.webp'),
    'sonidos': ('.wav', '.mp3', '.m4a', '.aif', '.aiff'), 'musica': ('.wav', '.mp3', '.m4a', '.aif', '.aiff'),
}


SUB_MARCA = ['01 LOGO & FONTS', '02 COLORS', '03 BACKGROUNDS', '04 STICKERS & GRAPHICS', '05 EDITING REFERENCES',
             '06 MY CONTENT', '07 SOUNDS EFFECTS', '08 B-ROLL', '09 MUSIC']
CAT_MARCA = {  # categoría de la pregunta → (número de su subcarpeta, extensiones)
    'logos': ('01', ('.png', '.svg', '.jpg', '.jpeg', '.webp')), 'fuentes': ('01', ('.ttf', '.otf', '.woff', '.woff2')),
    'fondos': ('03', ('.png', '.jpg', '.jpeg', '.webp', '.gif', '.mp4', '.mov')), 'graficos': ('04', ('.png', '.svg', '.webp', '.gif', '.mp4', '.mov', '.webm')),
    'referencias': ('05', ('.mp4', '.mov', '.m4v', '.jpg', '.jpeg', '.png')), 'sonidos': ('07', ('.wav', '.mp3', '.m4a', '.aac', '.aif', '.aiff', '.ogg')),
    'musica': ('09', ('.wav', '.mp3', '.m4a', '.aac', '.aif', '.aiff', '.ogg')),
}
RAICES_MARCA = ('Brand Assets', 'Marcas', 'Mis efectos')


def _nombre_seguro(n):
    n = re.sub(r'[\\/:*?"<>|\x00-\x1f]', '', str(n or '')).strip().strip('.')
    return n[:60] or 'Mi marca'


def marca_carpeta(nombre):
    """Crea Marcas/<nombre>/ con las mismas 9 subcarpetas que Brand Assets (no borra ni cambia nada que ya exista)."""
    est, _ = rutas()
    rel = 'Marcas/' + _nombre_seguro(nombre)
    for s in SUB_MARCA:
        os.makedirs(os.path.join(est, rel, s), exist_ok=True)
    return rel


def _ruta_marca(rel):
    """Ruta real dentro de Brand Assets, Marcas o Mis efectos; nunca sale de ahí."""
    est, _ = rutas()
    p = os.path.realpath(os.path.join(est, rel or ''))
    for r in RAICES_MARCA:
        b = os.path.realpath(os.path.join(est, r))
        if p == b or p.startswith(b + os.sep):
            return p
    return None


def marca_borrar(rel):
    """Quita la carpeta de una marca de cliente (solo dentro de Marcas/). En Mac va a la Papelera; si no se puede, se borra."""
    est, _ = rutas()
    base = os.path.realpath(os.path.join(est, 'Marcas'))
    p = os.path.realpath(os.path.join(est, rel or ''))
    if not p.startswith(base + os.sep) or os.path.dirname(p) != base or not os.path.isdir(p):
        return {'ok': False, 'error': 'Esa carpeta no es de una marca de cliente.'}
    papelera = os.path.expanduser('~/.Trash')
    if sys.platform == 'darwin' and os.path.isdir(papelera):
        destino = os.path.join(papelera, os.path.basename(p))
        n = 2
        while os.path.exists(destino):
            destino = os.path.join(papelera, '%s %d' % (os.path.basename(p), n))
            n += 1
        try:
            shutil.move(p, destino)
            return {'ok': True, 'papelera': True}
        except Exception:
            pass
    shutil.rmtree(p, ignore_errors=True)
    return {'ok': not os.path.exists(p), 'papelera': False}


def marca_archivos(rel, propia=False):
    """Lo que hay en la carpeta de una marca, por categoría (para que el cuestionario muestre SUS archivos primero)."""
    base = _ruta_marca(rel)
    out = {k: [] for k in CAT_MARCA}
    out['carpetas'] = {}
    if not base or not os.path.isdir(base):
        return out
    subs = sorted(n for n in os.listdir(base) if os.path.isdir(os.path.join(base, n)) and not n.startswith('.'))
    for k, (num, ext) in CAT_MARCA.items():
        car = next((n for n in subs if n.startswith(num)), None)
        if not car:
            continue
        out['carpetas'][k] = car
        d = os.path.join(base, car)
        for raiz, dirs, files in os.walk(d):
            dirs[:] = [x for x in dirs if not x.startswith('.')]
            for f in sorted(files):
                if f.startswith('.') or not f.lower().endswith(ext):
                    continue
                r = os.path.relpath(os.path.join(raiz, f), _ruta_marca('.') if False else os.path.join(estudio()))
                out[k].append({'n': f, 'r': r.replace(os.sep, '/')})
            if len(out[k]) > 200:
                break
    if propia:
        me = _ruta_marca('Mis efectos')
        if me and os.path.isdir(me):
            for f in sorted(os.listdir(me)):
                if not f.startswith('.') and f.lower().endswith(CAT_MARCA['graficos'][1]):
                    out['graficos'].append({'n': f, 'r': 'Mis efectos/' + f})
    try:
        out['colores'] = colores_de_carpeta(base)
    except Exception:
        out['colores'] = {'colores': []}
    return out


def preparar_brand_kit():
    """Si un tipo de su Brand Kit no tiene carpeta elegida, usa la de Brand Assets con su número (no cambia lo que ella eligió)."""
    est, _ = rutas()
    base = os.path.join(est, 'Brand Assets')
    if not os.path.isdir(base):
        return
    subs = sorted(n for n in os.listdir(base) if os.path.isdir(os.path.join(base, n)) and not n.startswith('.'))
    for clave, num in BRAND_KIT.items():
        ya = db_get('assetsCompu/' + clave)
        if ya and not (ya.get('auto') or (not ya.get('thumbs') and ya.get('carpeta') in subs)):
            continue             # la eligió ella desde la página: no se toca
        carpeta = next((n for n in subs if n.startswith(num)), None)
        if not carpeta:
            continue
        d = os.path.join(base, carpeta)
        ext = EXT_KIT.get(clave)
        arch = [{'n': f, 'r': f, 'kb': round(os.path.getsize(os.path.join(d, f)) / 1024)}
                for f in sorted(os.listdir(d))
                if os.path.isfile(os.path.join(d, f)) and not f.startswith('.') and (not ext or f.lower().endswith(ext))]
        if ya and ya.get('carpeta') == carpeta and [x.get('n') for x in ya.get('archivos') or []] == [x['n'] for x in arch] and ya.get('auto'):
            continue
        db_escribir('set', 'assetsCompu/' + clave, {'carpeta': carpeta, 'archivos': arch, 'thumbs': {}, 'auto': True, 'revisadoEn': int(time.time() * 1000)})


def preparar_config():
    """La página necesita saber que el editor está listo: en modo local el 'editor' es Claude Code en esta Mac."""
    est, _ = rutas()
    try:
        os.makedirs(os.path.join(est, 'Marcas'), exist_ok=True)   # aquí van las carpetas de las marcas de sus clientes
    except Exception:
        pass
    c = db_get('studio/config') or {}
    m = dict(c.get('motor') or {})
    cambios = {}
    if m.get('tareaCompu') != 'local':
        m['tareaCompu'] = 'local'
        cambios['motor'] = m
    if c.get('carpeta') != os.path.join(est, 'Reels'):
        cambios.update({'carpeta': os.path.join(est, 'Reels'), 'carpetaAssets': os.path.join(est, 'Brand Assets'), 'carpetaEstado': 'Conectada'})
    if cambios:
        db_escribir('merge', 'studio/config', cambios)


def servir(puerto=4791, abrir=True):
    preparar_config()
    preparar_brand_kit()
    threading.Thread(target=_vigilar_reels, daemon=True).start()
    threading.Thread(target=fluir_fuentes, daemon=True).start()
    srv = None
    for p in range(puerto, puerto + 10):
        try:
            srv = ThreadingHTTPServer(('127.0.0.1', p), H)
            puerto = p
            break
        except OSError:
            continue
    if not srv:
        sys.exit('No encontré un puerto libre.')
    ACT['puerto'] = puerto
    url = f'http://localhost:{puerto}'
    est, _ = rutas()
    with open(os.path.join(est, '.the-edit-lab', 'puerto'), 'w') as f:
        f.write(str(puerto))
    print(f'✦ The Edit Lab está abierto en {url}  (deja esta ventana abierta mientras editas; ciérrala para apagarlo)', flush=True)
    if abrir:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        threading.Timer(4.0, recuperar_al_inicio).start()
        threading.Thread(target=_vigilar_actualizaciones, daemon=True).start()
        srv.serve_forever()
    except KeyboardInterrupt:
        pass



# ---------- video ligero fluido ----------
def _fuente_fluida(ruta):
    """True si el video tiene un cuadro de salto seguido (saltar a un clip es instantáneo). Sin ffprobe: no toca nada."""
    try:
        o = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v', '-show_entries', 'packet=flags', '-of', 'csv=p=0', ruta],
                           capture_output=True, text=True, timeout=120).stdout.split()
        if not o:
            return True
        return len(o) / max(1, sum('K' in x for x in o)) <= 12
    except Exception:
        return True


def fluir_fuentes():
    """Re-codifica los videos ligeros del editor con un cuadro de salto cada 0.25 s: así cada clip arranca al instante."""
    try:
        for r in db_list('reels'):
            fid = (r or {}).get('fuenteId')
            if not fid:
                continue
            ruta = asset_ruta(fid)
            if not os.path.exists(ruta) or _fuente_fluida(ruta):
                continue
            tmp = ruta + '.fluido.mp4'
            p = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', ruta, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '27',
                                '-g', '6', '-keyint_min', '6', '-sc_threshold', '0', '-bf', '0', '-pix_fmt', 'yuv420p', '-c:a', 'copy',
                                '-movflags', '+faststart', tmp], capture_output=True, text=True)
            if p.returncode == 0 and os.path.getsize(tmp) > 1000:
                os.replace(tmp, ruta)
                _incidente('Video del editor regenerado para que no se pause: ' + str(r.get('nombre')))
            elif os.path.exists(tmp):
                os.remove(tmp)
    except Exception:
        pass

SONIDO_VERSION = 2
_SONIDO_FALLO = {}


def _python_motor():
    for c in (os.path.expanduser('~/.cvs-motor/bin/python3'), os.path.expanduser('~/.cvs-motor/venv/Scripts/python.exe'), sys.executable):
        if c and os.path.exists(c):
            return c
    return sys.executable


def escuchar_reels():
    """Escucha cada reel una vez (sonido.py): arranques en falso que la transcripción no vio y pausas escondidas.
    Corre en tu compu, sin gastar uso de Claude. Si el reel todavía no tiene cortes aprobados, los arranques salen ya tachados."""
    script = os.path.join(PLUG, 'skills', 'editar-video', 'scripts', 'sonido.py')
    if not os.path.exists(script):
        return
    for r in db_list('reels'):
        try:
            if not r or not r.get('fuenteId') or not r.get('palabras') or (r.get('sonido') or {}).get('version') == SONIDO_VERSION:
                continue
            if r.get('estado') in ('Por analizar', 'Analizando') or _SONIDO_FALLO.get(r['id'], 0) >= 2:
                continue
            ruta = asset_ruta(r['fuenteId'])
            if not os.path.exists(ruta):
                continue
            tmp = os.path.join(estudio(), '.the-edit-lab', 'datos', '_palabras_%s.json' % r['id'])
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump([{'t': w.get('t'), 's': w.get('s'), 'e': w.get('e')} for w in r['palabras']], f)
            p = subprocess.run([_python_motor(), script, ruta, tmp], capture_output=True, text=True, timeout=300)
            # la última toma gana: intentos fallidos y frases repetidas en la transcripción (repetidas.py, siempre igual)
            rep = []
            try:
                q = subprocess.run([_python_motor(), os.path.join(os.path.dirname(script), 'repetidas.py'), tmp], capture_output=True, text=True, timeout=60)
                if q.returncode == 0:
                    rep = json.loads(q.stdout.strip().splitlines()[-1]).get('cortar', [])
            except Exception:
                rep = []
            try:
                os.remove(tmp)
            except Exception:
                pass
            if p.returncode != 0:
                _SONIDO_FALLO[r['id']] = _SONIDO_FALLO.get(r['id'], 0) + 1
                continue
            res = json.loads(p.stdout.strip().splitlines()[-1])
            actual = db_get('reels/' + r['id']) or {}
            if len(actual.get('palabras') or []) != len(r['palabras']):
                continue          # las palabras cambiaron mientras escuchaba: se vuelve a escuchar en la próxima vuelta
            patch = {'sonido': {'version': SONIDO_VERSION, 'arranques': res.get('arranques', []), 'pausas': res.get('pausas', []),
                                'repetidas': rep, 'en': time.time()}}
            sin_cortes = not actual.get('segmentosEditados') and not actual.get('corteAprobado') and actual.get('estado') not in (
                'Analizando', 'Por analizar', 'Editando', 'En cola', 'Terminado')
            if sin_cortes and (res.get('arranques') or rep):
                W = actual['palabras']; C = actual.get('cortes')
                for i in res.get('arranques', []):
                    if 0 <= i < len(W):
                        W[i]['auto'] = True; W[i]['arranque'] = True
                        if isinstance(C, list) and i < len(C):
                            C[i] = True
                for x in rep:
                    i = x.get('i', -1)
                    if 0 <= i < len(W):
                        W[i]['auto'] = True; W[i]['repetida'] = x.get('motivo', 'toma repetida')
                        if isinstance(C, list) and i < len(C):
                            C[i] = True
                patch['palabras'] = W
                if isinstance(C, list):
                    patch['cortes'] = C
            db_escribir('merge', 'reels/' + r['id'], patch)
            if res.get('arranques') or rep:
                _incidente('Escuché %s: %d arranque(s) en falso, %d palabra(s) de tomas repetidas y %d pausa(s) escondida(s).' % (r.get('nombre'), len(res.get('arranques', [])), len(rep), len(res.get('pausas', []))))
        except Exception:
            _SONIDO_FALLO[r.get('id')] = _SONIDO_FALLO.get(r.get('id'), 0) + 1


def main(a):
    if not a or a[0] in ('-h', '--help'):
        print(__doc__)
        return
    if a[0] == 'fluir':
        return fluir_fuentes()
    if a[0] == 'servir':
        puerto = int(a[a.index('--puerto') + 1]) if '--puerto' in a else 4791
        return servir(puerto, '--no-abrir' not in a)
    if a[0] == 'db':
        op, path = a[1], a[2]
        if op == 'get':
            return print(json.dumps(db_get(path) or {}, ensure_ascii=False, indent=1))
        if op == 'list':
            return print(json.dumps(db_list(path), ensure_ascii=False, indent=1))
        data = json.loads(a[3]) if len(a) > 3 else None
        r = db_escribir(op, path, data)
        return print(json.dumps({'ok': True, 'path': r}))
    if a[0] == 'asset':
        if a[1] == 'add':
            aid = asset_add_desde(a[2], a[3] if len(a) > 3 else None)
            return print(json.dumps({'id': aid, 'ruta': asset_ruta(aid)}))
        if a[1] == 'ruta':
            return print(asset_ruta(a[2]))
    if a[0] == 'licencia':
        return print(json.dumps(licencia.estado(), ensure_ascii=False))
    if a[0] == 'estado':
        return print(json.dumps(CORRIDA, default=str))
    sys.exit('Comando no reconocido. Usa: python3 lab.py --help')


if __name__ == '__main__':
    main(sys.argv[1:])
