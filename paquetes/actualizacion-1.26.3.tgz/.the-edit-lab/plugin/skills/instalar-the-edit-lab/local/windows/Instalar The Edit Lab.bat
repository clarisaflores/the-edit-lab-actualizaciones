@echo off
rem The Edit Lab - instalacion en Windows (doble clic). Es seguro repetirla: no borra nada tuyo.
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".the-edit-lab" cd ..
title The Edit Lab - instalacion
set "GB="
if exist "%ProgramFiles%\Git\bin\bash.exe" set "GB=%ProgramFiles%\Git\bin\bash.exe"
if not defined GB if exist "%LOCALAPPDATA%\Programs\Git\bin\bash.exe" set "GB=%LOCALAPPDATA%\Programs\Git\bin\bash.exe"
if not defined GB (
  echo Primero instalo Git para Windows, lo necesita The Edit Lab.
  echo Si Windows pregunta si permites cambios, di que Si.
  winget install -e --id Git.Git --silent --accept-source-agreements --accept-package-agreements
  if exist "%ProgramFiles%\Git\bin\bash.exe" set "GB=%ProgramFiles%\Git\bin\bash.exe"
  if not defined GB if exist "%LOCALAPPDATA%\Programs\Git\bin\bash.exe" set "GB=%LOCALAPPDATA%\Programs\Git\bin\bash.exe"
)
if not defined GB (
  echo.
  echo No pude instalar Git para Windows. Instalalo desde git-scm.com y vuelve a abrir este instalador.
  pause
  exit /b 1
)
"%GB%" -c "cd \"$(cygpath -u '%CD%')\" && bash .the-edit-lab/plugin/skills/instalar-the-edit-lab/local/instalar-local.sh \"$(pwd)\""
echo.
pause
