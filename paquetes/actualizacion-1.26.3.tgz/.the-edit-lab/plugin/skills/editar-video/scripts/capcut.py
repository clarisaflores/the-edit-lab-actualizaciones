"""Exporta un Reel editado a un PROYECTO DE CAPCUT donde todo es editable.

Uso: python3 capcut.py <proyecto> --estudio <EST> --carpeta "<Reel N>" [--nombre "Reel N"] [--motor ~/.cvs-motor/remotion]
                       [--capcut "<carpeta de proyectos de CapCut>"] [--salida <carpeta>] [--sin-capas] [--sin-silueta]

Qué queda en CapCut (cada cosa en su propia capa):
- Tu video: cada corte es su propio clip, desde tus ORIGINALES en calidad completa, con su sonido. Velocidad por parte
  y zooms (los de la edición y los de cada parte) como keyframes que puedes mover.
- Subtítulos: cada palabra o grupo es un texto con tu fuente, tu color y tu posición.
- Títulos, palabras, tachados, cierres y las escenas «editorial»: cada texto, caja de color, post-it, flecha, cursor,
  imagen o clip es su propio elemento, con sus entradas y movimientos como keyframes.
- Texto detrás de tu cabeza: el texto va editable y encima una capa con tu silueta recortada (solo en ese momento).
- Efectos dibujados con código que CapCut no puede construir (ventanas tipo Finder, línea de tiempo animada, escribir
  letra por letra…): cada uno va como su propia capa de video transparente (la mueves, la recortas o la quitas).
- Cada sonido en su propio clip de audio; la música en su pista.

CapCut tiene que estar CERRADO: lo que se escribe con CapCut abierto se pierde en su siguiente guardado.
Nunca reemplaza un proyecto que ya tengas: si el nombre existe, se guarda como la versión siguiente (Reel 8 1.2…).
El formato se toma de TU CapCut (de tu proyecto más reciente), así sigue funcionando cuando CapCut se actualiza.
"""
import argparse, copy, glob, json, os, re, shutil, struct, subprocess, sys, time, uuid, zlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
W, H, FPS = 1080, 1920, 30
PX_POR_TAMANO = 4.6          # px de alto de letra por cada punto de tamaño de texto en CapCut (lienzo 1080x1920)
TIPOS_NATIVOS = {'texto', 'color', 'postit', 'img', 'clip', 'flecha', 'cursor', 'curvo'}
CLAVES_EDITORIAL = {'kind', 'text', 't0', 't1', 'elementos', 'fondo', 'oculta_subs', 'subs', 'y'}
LINEAS = {'gancho', 'palabra', 'cierre', 'cierre_alto', 'tachado'}


def us(t):
    return int(round(float(t) * 1_000_000))


def uid():
    return str(uuid.uuid4()).upper()


def hexrgb(c, d=(1.0, 1.0, 1.0)):
    m = re.fullmatch(r'#?([0-9a-fA-F]{6})', str(c or '').strip())
    if not m:
        return d
    v = m.group(1)
    return tuple(int(v[i:i + 2], 16) / 255 for i in (0, 2, 4))


def nx(px):   # px del lienzo → unidades de CapCut (medio lienzo; derecha positivo)
    return (float(px) - W / 2) / (W / 2)


def ny(py):   # arriba positivo
    return -(float(py) - H / 2) / (H / 2)


# ---------- PNG sin dependencias ----------
def png(ruta, rgba):
    h, w = rgba.shape[:2]
    raw = b''.join(b'\x00' + rgba[y].tobytes() for y in range(h))
    def ch(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    with open(ruta, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + ch(b'IDAT', zlib.compress(raw, 6)) + ch(b'IEND', b''))


def caja_png(ruta, w, h, color, radio=0, borde=None, grosor=0):
    w, h = max(2, int(round(w))), max(2, int(round(h)))
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32) + 0.5
    r = min(float(radio or 0), w / 2, h / 2)
    dx = np.maximum(np.maximum(r - xx, xx - (w - r)), 0); dy = np.maximum(np.maximum(r - yy, yy - (h - r)), 0)
    dist = np.sqrt(dx ** 2 + dy ** 2) - r if r > 0 else np.maximum(dx, dy) - 0
    a = np.clip(0.5 - dist, 0, 1)
    img = np.zeros((h, w, 4), np.uint8)
    rgb = [int(c * 255) for c in hexrgb(color, (1, 1, 1))]
    img[..., :3] = rgb
    if borde and grosor:
        dentro = np.clip(0.5 - (dist + grosor), 0, 1)
        bc = [int(c * 255) for c in hexrgb(borde, (1, 1, 1))]
        for k in range(3):
            img[..., k] = (img[..., k] * dentro + bc[k] * (1 - dentro)).astype(np.uint8)
    img[..., 3] = (a * 255).astype(np.uint8)
    png(ruta, img)
    return w, h


def flecha_png(ruta, largo, color):
    L = max(40, int(largo)); g = max(6, L // 14); w, h = L, g * 5
    img = np.zeros((h, w, 4), np.uint8); rgb = [int(c * 255) for c in hexrgb(color, (0.81, 0.5, 0.6))]
    yy, xx = np.mgrid[0:h, 0:w]
    cy = h / 2; punta = g * 3
    cuerpo = (xx < w - punta) & (np.abs(yy - cy) <= g / 2)
    cabeza = (xx >= w - punta) & (np.abs(yy - cy) <= (w - xx) * (h / 2) / punta)
    m = cuerpo | cabeza
    img[m, :3] = rgb; img[m, 3] = 255
    png(ruta, img)
    return w, h


def cursor_png(ruta):
    s = 64; img = np.zeros((s, s, 4), np.uint8)
    yy, xx = np.mgrid[0:s, 0:s]
    tri = (xx >= 6) & (yy >= 4) & (xx - 6 <= (yy - 4) * 0.62) & (yy <= 52)
    borde = (xx >= 3) & (yy >= 1) & (xx - 3 <= (yy - 1) * 0.66 + 3) & (yy <= 56)
    img[borde] = [255, 255, 255, 255]; img[tri] = [0, 0, 0, 255]
    png(ruta, img)
    return s, s


# ---------- medios ----------
def sonda(path):
    try:
        out = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', path], capture_output=True, text=True, timeout=60).stdout
        j = json.loads(out)
        v = next((s for s in j.get('streams', []) if s.get('codec_type') == 'video'), None)
        a = next((s for s in j.get('streams', []) if s.get('codec_type') == 'audio'), None)
        dur = float(j.get('format', {}).get('duration') or 0)
        w, h = (int(v['width']), int(v['height'])) if v else (0, 0)
        rot = 0
        for sd in (v or {}).get('side_data_list', []) or []:
            if 'rotation' in sd: rot = int(sd['rotation'])
        if v and 'rotate' in (v.get('tags') or {}): rot = -int(v['tags']['rotate'])
        if abs(rot) % 180 == 90: w, h = h, w
        return {'dur': dur, 'w': w, 'h': h, 'audio': a is not None}
    except Exception:
        return {'dur': 0, 'w': 0, 'h': 0, 'audio': False}


class Borrador:
    def __init__(self, T, plataforma):
        self.T = T
        self.d = copy.deepcopy(T['draft'])
        self.d['id'] = uid()
        self.d['canvas_config'] = {'ratio': 'original', 'width': W, 'height': H, 'background': None}
        self.d['platform'] = copy.deepcopy(plataforma); self.d['last_modified_platform'] = copy.deepcopy(plataforma)
        self.d['tracks'] = []
        self.M = self.d['materials']
        self.pistas = {}
        self.medios = []          # (ruta, tipo, dur, w, h) para draft_meta_info
        self.render = {'video': 0, 'texto': 14000, 'capa': 1, 'audio': 0}

    PLANT = {'videos': 'mat_video', 'texts': 'mat_text', 'audios': 'mat_audio'}

    def mat(self, clave, extra=None):
        m = copy.deepcopy(self.T[self.PLANT.get(clave, 'mat_' + clave)]); m['id'] = uid()
        if extra: m.update(extra)
        self.M.setdefault(clave, []).append(m)
        return m['id']

    def pista(self, tipo, nombre, flag=0):
        if nombre in self.pistas:
            return self.pistas[nombre]
        t = copy.deepcopy(self.T['track']); t.update({'id': uid(), 'type': tipo, 'flag': flag, 'segments': [], 'name': '', 'is_default_name': True})
        self.d['tracks'].append(t); self.pistas[nombre] = t
        return t

    def pista_libre(self, tipo, base, t0, t1, flag):
        """Una pista donde ese tramo no choque con otro clip (como CapCut: lo que se encima va en otra pista)."""
        k = 0
        while True:
            t = self.pista(tipo, f'{base}{k}', flag)
            if all(s['target_timerange']['start'] + s['target_timerange']['duration'] <= us(t0) or s['target_timerange']['start'] >= us(t1) for s in t['segments']):
                return t
            k += 1

    def _kfs(self, kfs):
        out = []
        for prop, pts in (kfs or {}).items():
            if not pts: continue
            out.append({'id': uid(), 'keyframe_list': [{'curveType': 'Line', 'graphID': '', 'left_control': {'x': 0.0, 'y': 0.0}, 'right_control': {'x': 0.0, 'y': 0.0},
                                                       'id': uid(), 'time_offset': int(max(0, o)), 'values': [float(v)]} for o, v in sorted(pts)],
                        'material_id': '', 'property_type': prop})
        return out

    def video(self, pista, ruta, info, src0, dur_src, t0, vel=1.0, x=0.0, y=0.0, escala=1.0, rot=0.0, vol=1.0, kfs=None, foto=False, render=None):
        tipo = 'photo' if foto else 'video'
        mid = self.mat('videos', {'type': tipo, 'path': ruta, 'duration': 10800000000 if foto else us(info['dur']), 'width': info['w'], 'height': info['h'],
                                  'has_audio': bool(info.get('audio')) and not foto, 'material_name': os.path.basename(ruta)})
        refs = [self.mat('speeds', {'speed': float(vel)}), self.mat('placeholder_infos'), self.mat('canvases'), self.mat('sound_channel_mappings'),
                self.mat('material_colors'), self.mat('vocal_separations')]
        dur_dest = dur_src / vel
        s = copy.deepcopy(self.T['seg_video'])
        s.update({'id': uid(), 'material_id': mid, 'extra_material_refs': refs, 'speed': float(vel), 'volume': float(vol), 'last_nonzero_volume': 1.0,
                  'source_timerange': {'start': us(src0), 'duration': us(dur_src)}, 'target_timerange': {'start': us(t0), 'duration': us(dur_dest)},
                  'clip': {'scale': {'x': float(escala), 'y': float(escala)}, 'rotation': float(rot), 'transform': {'x': float(x), 'y': float(y)},
                           'flip': {'vertical': False, 'horizontal': False}, 'alpha': 1.0},
                  'uniform_scale': {'on': True, 'value': 1.0}, 'common_keyframes': self._kfs(kfs), 'keyframe_refs': [],
                  'render_index': render if render is not None else self.render['video'], 'track_render_index': 0})
        pista['segments'].append(s); self.medios.append((ruta, 'photo' if foto else 'video', info))
        return s

    def audio(self, pista, ruta, dur_src, t0, vol=1.0, nombre=''):
        m = copy.deepcopy(self.T['mat_audio']); m.update({'id': uid(), 'name': nombre or os.path.basename(ruta), 'path': ruta, 'duration': us(dur_src), 'type': 'extract_music',
                                                          'local_material_id': '', 'music_id': ''})
        self.M.setdefault('audios', []).append(m)
        refs = [self.mat('speeds'), self.mat('placeholder_infos'), self.mat('beats'), self.mat('sound_channel_mappings'), self.mat('vocal_separations')]
        s = copy.deepcopy(self.T['seg_audio'])
        s.update({'id': uid(), 'material_id': m['id'], 'extra_material_refs': refs, 'volume': float(vol), 'last_nonzero_volume': 1.0,
                  'source_timerange': {'start': 0, 'duration': us(dur_src)}, 'target_timerange': {'start': us(t0), 'duration': us(dur_src)}, 'common_keyframes': []})
        pista['segments'].append(s); self.medios.append((ruta, 'audio', {'dur': dur_src, 'w': 0, 'h': 0}))
        return s

    def texto(self, pista, txt, t0, t1, fuente, color, px, x, y, kfs=None, ancho=0.86, alinea=1, sombra=False, caja=None):
        tam = round(max(3.0, float(px) / PX_POR_TAMANO), 1)
        n16 = len(txt.encode('utf-16-le')) // 2
        rgb = list(hexrgb(color))
        estilo = {'fill': {'alpha': 1.0, 'content': {'render_type': 'solid', 'solid': {'alpha': 1.0, 'color': rgb}}},
                  'font': {'id': '', 'path': fuente or ''}, 'range': [0, n16], 'size': tam}
        cont = json.dumps({'styles': [estilo], 'text': txt}, ensure_ascii=False)
        extra = {'content': cont, 'base_content': cont, 'type': 'text', 'text_color': '#%02X%02X%02X' % tuple(int(c * 255) for c in rgb),
                 'font_path': fuente or '', 'font_name': os.path.splitext(os.path.basename(fuente or ''))[0], 'alignment': alinea,
                 'line_max_width': float(ancho), 'text_size': int(round(tam * 3)), 'has_shadow': bool(sombra), 'name': txt[:40]}
        if caja:
            extra.update({'background_color': caja, 'background_alpha': 1.0, 'background_style': 1, 'background_round_radius': 0.25})
        mid = self.mat('texts', extra)
        anim = self.mat('material_animations')
        s = copy.deepcopy(self.T['seg_text'])
        s.update({'id': uid(), 'material_id': mid, 'extra_material_refs': [anim], 'source_timerange': None,
                  'target_timerange': {'start': us(t0), 'duration': max(us(0.05), us(t1) - us(t0))},
                  'clip': {'scale': {'x': 1.0, 'y': 1.0}, 'rotation': 0.0, 'transform': {'x': float(x), 'y': float(y)}, 'flip': {'vertical': False, 'horizontal': False}, 'alpha': 1.0},
                  'uniform_scale': {'on': True, 'value': 1.0}, 'common_keyframes': self._kfs(kfs), 'render_index': self.render['texto']})
        self.render['texto'] += 1
        pista['segments'].append(s)
        return s

    def cerrar(self):
        dur = 0
        for t in self.d['tracks']:
            t['segments'].sort(key=lambda s: s['target_timerange']['start'])
            for s in t['segments']:
                dur = max(dur, s['target_timerange']['start'] + s['target_timerange']['duration'])
        self.d['duration'] = dur
        # el orden de las pistas: video principal, capas de video, textos, audio
        orden = {'video': 0, 'text': 1, 'audio': 2}
        self.d['tracks'].sort(key=lambda t: (orden.get(t['type'], 3), 0 if t.get('flag') == 0 else 1))
        self.d['tracks'] = [t for t in self.d['tracks'] if t['segments']]
        return dur


def envolver(txt, px, ancho_px, negrita=True):
    """Parte el texto en renglones como lo hace la edición (CapCut centra mejor con renglones fijos)."""
    cw = float(px) * (0.56 if negrita else 0.5)
    maxc = max(1, int(ancho_px / max(1.0, cw)))
    out = []
    for par in str(txt).split('\n'):
        ln = ''
        for w in par.split(' '):
            if ln and len(ln) + 1 + len(w) > maxc:
                out.append(ln); ln = w
            else:
                ln = (ln + ' ' + w).strip()
        out.append(ln)
    return '\n'.join(out)


def entrada_kfs(kind_entra, x, y, dur_ent=0.3, sale=None, largo=None, escala=1.0, mueve=None):
    """Entradas y salidas como keyframes (posición / escala / giro) que ella puede mover en CapCut."""
    k = {}
    e = us(dur_ent)
    if kind_entra in ('izquierda', 'derecha', 'arriba', 'abajo'):
        dx = {'izquierda': -0.35, 'derecha': 0.35}.get(kind_entra, 0.0); dy = {'arriba': 0.25, 'abajo': -0.25}.get(kind_entra, 0.0)
        if dx: k['KFTypePositionX'] = [(0, x + dx), (e, x)]
        if dy: k['KFTypePositionY'] = [(0, y + dy), (e, y)]
    elif kind_entra in ('crece', 'zoom', 'pop', None, ''):
        k['KFTypeScaleX'] = [(0, escala * (0.6 if kind_entra in ('crece', 'zoom', 'pop') else 0.85)), (e, escala)]
    if mueve:
        a0 = us(mueve['en']); a1 = a0 + us(0.45)
        if 'x' in mueve:
            k.setdefault('KFTypePositionX', [(0, x)]); k['KFTypePositionX'] += [(a0, x), (a1, nx(mueve['x']))]
        if 'y' in mueve:
            k.setdefault('KFTypePositionY', [(0, y)]); k['KFTypePositionY'] += [(a0, y), (a1, ny(mueve['y']))]
        if mueve.get('esc'):
            k.setdefault('KFTypeScaleX', [(0, escala)]); k['KFTypeScaleX'] += [(a0, escala), (a1, escala * float(mueve['esc']))]
    if sale is not None and largo is not None and largo > 0.4:
        s0 = us(max(0.0, largo - 0.25))
        k.setdefault('KFTypeScaleX', [(0, escala)]); k['KFTypeScaleX'] += [(s0, escala), (us(largo), escala * 0.6)]
    return k


def carpeta_capcut():
    """Dónde guarda CapCut sus proyectos en esta compu (Mac o Windows)."""
    cands = [os.path.expanduser('~/Movies/CapCut/User Data/Projects/com.lveditor.draft')]
    la = os.environ.get('LOCALAPPDATA')
    if la:
        cands += [os.path.join(la, 'CapCut', 'User Data', 'Projects', 'com.lveditor.draft'), os.path.join(la, 'CapCut Drafts')]
    for c in cands:
        if os.path.isdir(c):
            return c
    return cands[0]


def capcut_abierto():
    try:
        if sys.platform == 'darwin':
            return subprocess.run(['pgrep', '-x', 'CapCut'], capture_output=True).returncode == 0
        if os.name == 'nt':
            out = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq CapCut.exe'], capture_output=True, text=True).stdout
            return 'CapCut.exe' in out
    except Exception:
        pass
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('proyecto'); ap.add_argument('--estudio', required=True); ap.add_argument('--carpeta', default='')
    ap.add_argument('--nombre', default=''); ap.add_argument('--motor', default=os.path.expanduser('~/.cvs-motor/remotion'))
    ap.add_argument('--capcut', default=carpeta_capcut())
    ap.add_argument('--salida', help='armar el proyecto aquí (sin instalarlo en CapCut)')
    ap.add_argument('--sin-capas', action='store_true'); ap.add_argument('--sin-silueta', action='store_true')
    ap.add_argument('--mapa', action='append', default=[], help='DESDE=HASTA: reescribe rutas (cuando se arma desde otra máquina que ve las mismas carpetas)')
    ap.add_argument('--no-revisar-capcut', action='store_true')
    a = ap.parse_args()
    P = os.path.abspath(a.proyecto); TR = os.path.join(P, 'trabajo'); EST = os.path.abspath(a.estudio)
    T = json.load(open(os.path.join(AQUI, 'capcut_plantilla.json'), encoding='utf-8'))
    tl = json.load(open(os.path.join(TR, 'timeline.json'), encoding='utf-8'))
    cues = json.load(open(os.path.join(TR, 'cues.json'), encoding='utf-8'))
    fuentes = {f['n']: f for f in json.load(open(os.path.join(TR, 'fuentes.json'), encoding='utf-8'))}
    estp = os.path.join(P, 'estilo', 'estilo.json')
    est = json.load(open(estp if os.path.exists(estp) else os.path.join(EST, 'estilo.json'), encoding='utf-8'))
    cara = json.load(open(os.path.join(TR, 'cara.json'), encoding='utf-8')) if os.path.exists(os.path.join(TR, 'cara.json')) else {}
    nombre = a.nombre or a.carpeta or os.path.basename(P)
    avisos = []

    # ---- CapCut cerrado (si no, pierde lo que se escriba) ----
    if not a.salida and not a.no_revisar_capcut:
        if capcut_abierto():
            print('CAPCUT_ABIERTO: cierra CapCut (Cmd+Q) y vuelve a exportar.'); sys.exit(4)

    # ---- formato de SU CapCut: el de su proyecto más reciente ----
    plataforma = dict(T['platform_def'])
    if os.name == 'nt': plataforma['os'] = 'windows'
    try:
        recientes = sorted(glob.glob(os.path.join(a.capcut, '*', 'draft_info.json')), key=os.path.getmtime, reverse=True)
        for r in recientes[:3]:
            j = json.load(open(r, encoding='utf-8'))
            if j.get('platform'):
                plataforma = j['platform']
                for k in ('version', 'new_version'):
                    if j.get(k): T['draft'][k] = j[k]
                break
    except Exception:
        pass
    B = Borrador(T, plataforma)

    # ---- su carpeta del borrador ----
    destino_base = os.path.abspath(a.salida) if a.salida else a.capcut
    os.makedirs(destino_base, exist_ok=True)
    v = 1
    while os.path.exists(os.path.join(destino_base, f'{nombre} 1.{v}')): v += 1
    nombre_draft = f'{nombre} 1.{v}'
    D = os.path.join(destino_base, nombre_draft)
    tmpD = os.path.join(destino_base, '.' + nombre_draft + '.armando')
    shutil.rmtree(tmpD, ignore_errors=True); os.makedirs(os.path.join(tmpD, 'assets'))
    ASSET = lambda n: os.path.join(D, 'assets', n)        # ruta final (CapCut la lee desde ahí)
    ASSET_TMP = lambda n: os.path.join(tmpD, 'assets', n)

    # ---- fuentes y archivos de su Brand Assets ----
    BA = os.path.join(EST, 'Brand Assets')
    def busca(nombre_arch, extra=()):
        if not nombre_arch: return None
        if os.path.isabs(nombre_arch) and os.path.exists(nombre_arch): return nombre_arch
        cands = [os.path.join(P, nombre_arch), os.path.join(P, 'crudo', nombre_arch), os.path.join(P, 'apoyo', nombre_arch),
                 os.path.join(EST, '.motor', 'mis', nombre_arch), os.path.join(os.path.expanduser('~/.cvs-motor/fuentes'), nombre_arch),
                 os.path.join(a.motor, 'public', nombre_arch), os.path.join(a.motor, 'public', 'fonts', nombre_arch)] + list(extra)
        for c in cands:
            if os.path.exists(c): return c
        for g in glob.glob(os.path.join(BA, '*', '**', os.path.basename(nombre_arch)), recursive=True):
            return g
        for g in glob.glob(os.path.join(EST, '**', os.path.basename(nombre_arch)), recursive=True):
            if '/.the-edit-lab/' not in g: return g
        return None
    F = est.get('fuentes', {})
    f_tit = busca(F.get('titulos')) or busca(F.get('respaldo_titulos')); f_sub = busca(F.get('subtitulos')) or busca(F.get('respaldo_subtitulos'))
    f_sec = busca(F.get('secundaria')) or f_tit
    if not f_tit: avisos.append('no encontré tu fuente de títulos; CapCut usará la suya (cámbiala en el texto)')
    col = est.get('colores', {})

    # ---- 1) tu video: cada corte, desde tus originales ----
    originales = []
    if a.carpeta:
        cr = os.path.join(EST, 'Reels', a.carpeta)
        if os.path.isdir(cr):
            originales = sorted(os.path.join(cr, f) for f in os.listdir(cr)
                                if f.lower().endswith(('.mp4', '.mov', '.m4v')) and not f.startswith('.') and os.path.isfile(os.path.join(cr, f)))
    fuente_de = {}
    for n, f in fuentes.items():
        crudo = os.path.join(P, 'crudo', f['archivo']); ic = sonda(crudo)
        elegido, info = crudo, ic
        if len(originales) == len(fuentes) and 0 < n <= len(originales):
            io = sonda(originales[n - 1])
            if io['dur'] and ic['dur'] and abs(io['dur'] - ic['dur']) < 0.6:
                elegido, info = originales[n - 1], io
        fuente_de[n] = (elegido, info, bool(f.get('girar')))
    if any(e == os.path.join(P, 'crudo', fuentes[n]['archivo']) for n, (e, _, _) in fuente_de.items()):
        avisos.append('usé la copia de trabajo de tu video (no encontré el original igual en tu carpeta del Reel)')

    esc_mov = float(est.get('movimiento', {}).get('escala', 1.25) or 1.25)
    zooms = cues.get('zooms', [])
    def zoom_en(t):
        for z in zooms:
            if z['t0'] <= t < z['t1']: return z
        return None
    pv = B.pista('video', 'principal', 0)
    t_acc = 0.0
    tramos_principal = []
    for c in tl['clips']:
        ruta, info, girar = fuente_de.get(c['archivo'], (None, None, False))
        if not ruta: continue
        vel = float(c.get('vel') or 1)
        dur_src = (c['frames'] / FPS) * vel
        t0 = c.get('t0_real', t_acc)
        # tamaño para llenar el lienzo vertical (CapCut lo encaja primero completo dentro del lienzo)
        mw, mh = info['w'] or 1080, info['h'] or 1920
        fit = min(W / mw, H / mh); fw, fh = mw * fit, mh * fit
        rw, rh = (fh, fw) if girar else (fw, fh)
        base = max(W / rw, H / rh)
        rot = 90.0 if girar else 0.0
        d_dest = dur_src / vel
        kf = {}
        if c.get('zoom') in ('in', 'out'):
            z0, z1 = (1.0, 1.15) if c['zoom'] == 'in' else (1.15, 1.0)
            kf['KFTypeScaleX'] = [(0, base * z0), (us(d_dest), base * z1)]
        else:
            pts = []
            for z in zooms:
                a0, a1 = max(z['t0'], t0), min(z['t1'], t0 + d_dest)
                if a1 <= a0: continue
                r0, r1 = us(a0 - t0), us(a1 - t0)
                if z.get('cut'):
                    pts += [(max(0, r0 - 1), base), (r0, base * esc_mov), (r1 - 1, base * esc_mov), (r1, base)]
                else:
                    sub = min(us(0.3), (r1 - r0) // 3)
                    pts += [(r0, base), (r0 + sub, base * esc_mov ** 0.5), (r1 - sub, base * esc_mov ** 0.5), (r1, base)]
            if pts:
                kf['KFTypeScaleX'] = sorted(pts)
        seg = B.video(pv, ruta, info, c['in'], dur_src, t0, vel=vel, escala=base, rot=rot, kfs=kf)
        tramos_principal.append((t0, t0 + d_dest, base, kf.get('KFTypeScaleX')))
        t_acc = t0 + d_dest

    # ---- 2) efectos ----
    O = cues.get('overlays', [])
    ocultar = [(o['t0'], o['t1']) for o in O if o.get('oculta_subs')]
    subs_override = [(o['t0'], o['t1'], o['subs']) for o in O if o.get('subs')]
    capas = []        # efectos que van como capa de video transparente
    silueta = []      # tramos con texto detrás de su cabeza
    n_txt = n_img = 0

    def lineas(o):
        L = o.get('lineas') or [{'text': o.get('text', ''), 'size': est.get('titulos', {}).get('tamano', 84), 'y': o.get('y', 300), 't': o['t0']}]
        pt = B.pista_libre('text', 'titulos', o['t0'], o['t1'], 1)
        n = 0
        for i, l in enumerate(L):
            t_in = l.get('t', o['t0'] + float(l.get('dt', 0)) if 'dt' in l else o['t0'])
            if t_in >= o['t1']: continue
            x, y = nx(l.get('x', 540)), ny(l.get('y', 300))
            kf = entrada_kfs('crece' if i == 0 else 'abajo', x, y)
            B.texto(pt, l.get('text', ''), t_in, o['t1'], f_tit, o.get('color') or col.get('texto', '#FFFFFF'), l.get('size', 84), x, y, kfs=kf, ancho=0.96)
            n += 1
        if o['kind'] == 'tachado' and o.get('tacha'):
            ruta = ASSET_TMP(f'tacha_{uid()[:8]}.png'); w_, h_ = caja_png(ruta, 820, 14, col.get('resaltado') or col.get('caja_texto') or '#111111', radio=7)
            l0 = L[0]
            B.video(B.pista_libre('video', 'capas', o['tacha'], o['t1'], 2), ASSET(os.path.basename(ruta)), {'dur': 0, 'w': w_, 'h': h_}, 0, o['t1'] - o['tacha'], o['tacha'],
                    x=nx(540), y=ny(l0.get('y', 300)), escala=1.0, foto=True, render=10, kfs={'KFTypeScaleX': [(0, 0.05), (us(0.25), 1.0)]})
        if o.get('detras'):
            silueta.append((o['t0'], o['t1']))
        return n

    for o in O:
        k = o['kind']
        nativo = k in LINEAS or k == 'curvo' or (k == 'editorial' and set(o.keys()) <= CLAVES_EDITORIAL and
                                                   all((e.get('tipo') in TIPOS_NATIVOS) for e in (o.get('elementos') or [])))
        if not nativo:
            capas.append(o); continue
        if k in LINEAS:
            n_txt += lineas(o); continue
        if k == 'curvo':
            pt = B.pista_libre('text', 'titulos', o['t0'], o['t1'], 1); x, y = nx(540), ny(o.get('y', 300))
            B.texto(pt, o.get('text', ''), o['t0'], o['t1'], f_tit, col.get('texto', '#FFFFFF'), 70, x, y, kfs=entrada_kfs('crece', x, y)); n_txt += 1
            continue
        # editorial: fondo + cada elemento en su capa
        if o.get('fondo') and o['fondo'] not in ('transparent', 'none', ''):
            ruta = ASSET_TMP(f'fondo_{uid()[:8]}.png'); caja_png(ruta, 108, 192, o['fondo'])
            B.video(B.pista_libre('video', 'capas', o['t0'], o['t1'], 2), ASSET(os.path.basename(ruta)), {'dur': 0, 'w': 108, 'h': 192}, 0, o['t1'] - o['t0'], o['t0'],
                    escala=1.0, foto=True, render=2); n_img += 1
        for e in o.get('elementos') or []:
            tp = e.get('tipo'); t_in = o['t0'] + float(e.get('en', 0) or 0)
            t_out = o['t0'] + float(e['sale']) if e.get('sale') is not None else o['t1']
            if t_out - t_in < 0.04: continue
            x, y = nx(e.get('x', 540)), ny(e.get('y', 960)); largo = t_out - t_in
            mueve = dict(e['mueve']) if isinstance(e.get('mueve'), dict) else None
            if mueve and 'en' in mueve: mueve['en'] = float(mueve['en']) - float(e.get('en', 0) or 0)
            if mueve and 'w' in mueve and e.get('w'): mueve['esc'] = float(mueve['w']) / float(e['w'])
            kf = entrada_kfs(e.get('entra'), x, y, sale=e.get('sale'), largo=largo, mueve=mueve)
            if e.get('rot'): kf.setdefault('KFTypeRotation', [(0, float(e['rot']))])
            if tp in ('texto', 'curvo'):
                f = f_sec if e.get('fuente') == 'secundaria' else (f_sub if e.get('fuente') == 'subtitulos' else f_tit)
                sz = float(e.get('size', 80)); neg = e.get('fuente') not in ('secundaria', 'subtitulos')
                txt = envolver(e.get('text', ''), sz, float(e.get('w', 900)), neg)
                al = e.get('alinea')
                if al in ('left', 'izquierda', 'right', 'derecha'):
                    larga = max(len(r) for r in txt.split('\n')) * sz * (0.56 if neg else 0.5)
                    x = nx(float(e.get('x', 540)) - float(e.get('w', larga)) / 2 + larga / 2) if al in ('left', 'izquierda') else nx(float(e.get('x', 540)) + float(e.get('w', larga)) / 2 - larga / 2)
                    kf = entrada_kfs(e.get('entra'), x, y, sale=e.get('sale'), largo=largo, mueve=mueve)
                B.texto(B.pista_libre('text', 'titulos', t_in, t_out, 1), txt, t_in, t_out, f, e.get('color') or col.get('texto', '#FFFFFF'),
                        sz, x, y, kfs=kf, ancho=0.96); n_txt += 1
            elif tp in ('color', 'postit'):
                ruta = ASSET_TMP(f'caja_{uid()[:8]}.png')
                w_, h_ = caja_png(ruta, e.get('w', 200), e.get('h', 200), e.get('fondo') or e.get('color') or col.get('caja') or '#FFFFFF', radio=e.get('radio', 18 if tp == 'postit' else 0),
                                  borde=e.get('borde'), grosor=4 if e.get('borde') else 0)
                B.video(B.pista_libre('video', 'capas', t_in, t_out, 2), ASSET(os.path.basename(ruta)), {'dur': 0, 'w': w_, 'h': h_}, 0, largo, t_in,
                        x=x, y=y, escala=1.0, foto=True, kfs=kf, render=5); n_img += 1
                if e.get('text'):
                    f = f_sec if e.get('fuente') == 'secundaria' else f_tit
                    B.texto(B.pista_libre('text', 'titulos', t_in, t_out, 1), envolver(e['text'], float(e.get('size', 48)), float(e.get('w', 400)) * 0.9), t_in, t_out, f,
                            e.get('color') if tp == 'postit' else (e.get('color') or '#000000'), e.get('size', 48), x, y, kfs=kf, ancho=0.96); n_txt += 1
            elif tp == 'flecha':
                ruta = ASSET_TMP(f'flecha_{uid()[:8]}.png'); w_, h_ = flecha_png(ruta, e.get('largo', 150), e.get('color') or col.get('resaltado') or col.get('caja_texto') or '#111111')
                kf.setdefault('KFTypeRotation', [(0, float(e.get('rot', 0)) - 90)])
                B.video(B.pista_libre('video', 'capas', t_in, t_out, 2), ASSET(os.path.basename(ruta)), {'dur': 0, 'w': w_, 'h': h_}, 0, largo, t_in,
                        x=x, y=y, escala=1.0, rot=float(e.get('rot', 0)) - 90, foto=True, kfs=kf, render=6); n_img += 1
            elif tp == 'cursor':
                ruta = ASSET_TMP('cursor.png')
                if not os.path.exists(ruta): cursor_png(ruta)
                B.video(B.pista_libre('video', 'capas', t_in, t_out, 2), ASSET('cursor.png'), {'dur': 0, 'w': 64, 'h': 64}, 0, largo, t_in, x=x, y=y, foto=True, render=7); n_img += 1
            elif tp in ('img', 'clip'):
                src = busca(e.get('img'))
                if not src:
                    avisos.append(f'no encontré «{e.get("img")}»; ese elemento no va'); continue
                info = sonda(src); foto = tp == 'img' and not src.lower().endswith(('.mp4', '.mov', '.m4v', '.gif'))
                mw, mh = info['w'] or 1000, info['h'] or 1000
                fit = min(W / mw, H / mh); esc = float(e.get('w', 400)) / (mw * fit)
                kf2 = entrada_kfs(e.get('entra'), x, y, sale=e.get('sale'), largo=largo, escala=esc, mueve=mueve)
                if e.get('rot'): kf2.setdefault('KFTypeRotation', [(0, float(e['rot']))])
                desde = float(e.get('desde', 0) or 0)
                if not foto and info['dur'] and desde + largo > info['dur']: largo = max(0.1, info['dur'] - desde)
                B.video(B.pista_libre('video', 'capas', t_in, t_in + largo, 2), src, info, 0 if foto else desde, largo, t_in, x=x, y=y, escala=esc,
                        rot=float(e.get('rot', 0)), vol=0.0, foto=foto, kfs=kf2, render=4); n_img += 1

    # ---- 3) subtítulos: cada palabra (o grupo) es su texto ----
    sb = est.get('subtitulos', {})
    nmax = int(sb.get('palabras_max', 3) or 3)
    words = [w for w in tl.get('words', []) if w.get('s') is not None]
    grupos, g = [], []
    for w in words:
        corte = g and (len(g) >= nmax or w['s'] - g[-1]['e'] > 0.4 or str(g[-1]['w']).rstrip().endswith(('.', '?', '!')))
        if corte: grupos.append(g); g = []
        g.append(w)
    if g: grupos.append(g)
    ps = B.pista('text', 'subtitulos', 1)
    n_sub = 0
    for i, g in enumerate(grupos):
        t0 = g[0]['s']; t1 = grupos[i + 1][0]['s'] if i + 1 < len(grupos) and grupos[i + 1][0]['s'] - g[-1]['e'] < 0.5 else g[-1]['e'] + 0.15
        if any(a0 <= t0 < a1 for a0, a1 in ocultar): continue
        txt = ' '.join(str(w['w']) for w in g)
        if sb.get('mayusculas'): txt = txt.upper()
        sx, sy, scol, ssz = sb.get('x', 0.5) * W, sb.get('y', 0.75) * H, col.get('subtitulo', '#FFFFFF'), sb.get('tamano', 52)
        for a0, a1, so in subs_override:
            if a0 <= t0 < a1:
                sx, sy, scol, ssz = so.get('x', sx), so.get('y', sy), so.get('color', scol), so.get('size', ssz)
        B.texto(ps, txt, t0, t1, f_sub, scol, ssz, nx(sx), ny(sy), ancho=float(sb.get('ancho', 0.8)), sombra=bool(sb.get('sombra')))
        n_sub += 1

    # ---- 4) texto detrás de tu cabeza: tu silueta recortada encima, solo en esos momentos ----
    n_sil = 0
    if silueta and not a.sin_silueta:
        try:
            import detras as DET
            if not DET.disponible():
                raise RuntimeError('falta el recorte de silueta')
            seg = DET._Seg()
            base_mp4 = os.path.join(TR, 'base.mp4')
            for (s0, s1) in silueta:
                out = ASSET_TMP(f'silueta_{uid()[:8]}.mov')
                dec = subprocess.Popen(['ffmpeg', '-nostdin', '-v', 'error', '-ss', f'{s0:.3f}', '-i', base_mp4, '-t', f'{s1 - s0:.3f}', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
                enc = subprocess.Popen(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                                        '-c:v', 'prores_ks', '-profile:v', '4444', '-pix_fmt', 'yuva444p10le', '-q:v', '18', out], stdin=subprocess.PIPE)
                n = W * H * 3
                while True:
                    b = dec.stdout.read(n)
                    if len(b) < n: break
                    rgb = np.frombuffer(b, np.uint8).reshape(H, W, 3)
                    m = seg.mask(rgb)
                    rgba = np.dstack([rgb, (np.clip(m, 0, 1) * 255).astype(np.uint8)])
                    enc.stdin.write(rgba.tobytes())
                enc.stdin.close(); enc.wait(); dec.wait()
                # sigue los zooms del video principal para quedar exactamente encima de ti
                kf = None
                for (a0, a1, base, kfz) in tramos_principal:
                    if a0 <= s0 < a1 and kfz:
                        kf = {'KFTypeScaleX': [(o - us(s0 - a0), v_ / base) for o, v_ in kfz if us(s0 - a0) <= o <= us(s1 - a0)]}
                B.video(B.pista_libre('video', 'silueta', s0, s1, 2), ASSET(os.path.basename(out)), {'dur': s1 - s0, 'w': W, 'h': H, 'audio': False}, 0, s1 - s0, s0,
                        vol=0.0, kfs=kf, render=20000)
                n_sil += 1
            seg.close()
        except Exception as ex:
            avisos.append(f'el texto detrás de tu cabeza quedó delante ({str(ex)[:60]})')

    # ---- 5) efectos que CapCut no puede construir: cada uno como su capa transparente ----
    n_capa = 0
    if capas and not a.sin_capas:
        M_ = a.motor
        if not os.path.isdir(os.path.join(M_, 'src')):
            avisos.append('no encontré el motor de animación; los efectos especiales no van como capa')
        else:
            src_main = os.path.join(AQUI, '..', 'remotion-template', 'src', 'Main.tsx')
            if os.path.exists(src_main): shutil.copy(src_main, os.path.join(M_, 'src', 'Main.tsx'))
            r = subprocess.run([sys.executable, os.path.join(AQUI, 'final.py'), 'preparar', P, '--motor', M_, '--estilo', estp if os.path.exists(estp) else os.path.join(EST, 'estilo.json'),
                                '--fuentes', os.path.join(BA, next((d for d in sorted(os.listdir(BA)) if d.startswith('01')), '')) if os.path.isdir(BA) else EST],
                               capture_output=True, text=True)
            guarda = json.load(open(os.path.join(M_, 'src', 'cues.json'), encoding='utf-8'))
            npx = 'npx.cmd' if os.name == 'nt' else 'npx'
            try:
                for o in capas:
                    c2 = dict(guarda); c2['overlays'] = [o]; c2['capa'] = True
                    json.dump(c2, open(os.path.join(M_, 'src', 'cues.json'), 'w', encoding='utf-8'), ensure_ascii=False)
                    fa, fb = int(o['t0'] * FPS), max(int(o['t0'] * FPS), int(o['t1'] * FPS) - 1)
                    out = ASSET_TMP(f'efecto_{o["kind"]}_{uid()[:6]}.mov')
                    p = subprocess.run([npx, 'remotion', 'render', 'src/index.ts', 'Main', out, f'--frames={fa}-{fb}', '--codec=prores', '--prores-profile=4444',
                                        '--image-format=png', '--pixel-format=yuva444p10le', '--muted', '--log=error'], cwd=M_, capture_output=True, text=True)
                    if p.returncode != 0 or not os.path.exists(out):
                        avisos.append(f'no pude hacer la capa de «{o["kind"]}» ({(p.stderr or p.stdout)[-80:].strip()})'); continue
                    largo = (fb - fa + 1) / FPS
                    B.video(B.pista_libre('video', 'efectos', o['t0'], o['t0'] + largo, 2), ASSET(os.path.basename(out)), {'dur': largo, 'w': W, 'h': H, 'audio': False},
                            0, largo, o['t0'], vol=0.0, render=3000)
                    n_capa += 1
            finally:
                json.dump(guarda, open(os.path.join(M_, 'src', 'cues.json'), 'w', encoding='utf-8'), ensure_ascii=False)

    # ---- 6) sonidos y música: cada uno en su clip ----
    SND = [os.path.join(BA, d) for d in sorted(os.listdir(BA)) if d.startswith(('07', '09'))] if os.path.isdir(BA) else []
    SND += [os.path.join(EST, 'Efectos de sonido'), os.path.join(EST, 'Mis efectos')]
    n_snd = 0
    for sx in cues.get('sfx', []):
        f = sx.get('file')
        ruta = None
        for d in SND:
            c = os.path.join(d, f or '')
            if f and os.path.exists(c): ruta = c; break
        ruta = ruta or busca(f)
        if not ruta: avisos.append(f'no encontré el sonido «{f}»'); continue
        info = sonda(ruta); dur = float(sx.get('dur') or info['dur'] or 0.5)
        B.audio(B.pista_libre('audio', 'sonidos', sx['t'], sx['t'] + dur, 0), ruta, dur, sx['t'], vol=10 ** (float(sx.get('db', 0) or 0) / 20) * 0.7)
        n_snd += 1
    if cues.get('musica'):
        m = busca(cues['musica'])
        if m:
            info = sonda(m); total = B.cerrar() / 1e6
            B.audio(B.pista('audio', 'musica', 0), m, min(info['dur'] or total, total), 0, vol=0.25); n_snd += 1

    dur = B.cerrar()

    # ---- 7) escribir el proyecto ----
    B.d['name'] = ''
    def mapa(txt):
        for m in a.mapa:
            de, ha = m.split('=', 1)
            txt = txt.replace(json.dumps(de, ensure_ascii=False)[1:-1], json.dumps(ha, ensure_ascii=False)[1:-1])
        return txt
    js = json.dumps(B.d, ensure_ascii=False)
    js_final = mapa(js)
    with open(os.path.join(tmpD, 'draft_info.json'), 'w', encoding='utf-8') as fh: fh.write(js_final)
    tid = B.d['id']
    os.makedirs(os.path.join(tmpD, 'Timelines', tid), exist_ok=True)
    with open(os.path.join(tmpD, 'Timelines', tid, 'draft_info.json'), 'w', encoding='utf-8') as fh: fh.write(js_final)
    ahora = int(time.time() * 1_000_000)
    pj = copy.deepcopy(T['project']); pj.update({'id': uid(), 'main_timeline_id': tid, 'create_time': ahora, 'update_time': ahora})
    pj['timelines'] = [{'create_time': ahora, 'id': tid, 'is_marked_delete': False, 'name': 'Línea de tiempo 01', 'update_time': ahora}]
    json.dump(pj, open(os.path.join(tmpD, 'Timelines', 'project.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    lay = copy.deepcopy(T['layout']); lay['dockItems'][0]['timelineIds'] = [tid]
    json.dump(lay, open(os.path.join(tmpD, 'timeline_layout.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    meta = copy.deepcopy(T['meta'])
    did = uid()
    meta.update({'draft_fold_path': D, 'draft_id': did, 'draft_name': nombre_draft, 'draft_root_path': destino_base, 'tm_draft_create': ahora,
                 'tm_draft_modified': ahora, 'tm_duration': dur, 'draft_cover': 'draft_cover.jpg'})
    vistos = set()
    for ruta, tipo, info in B.medios:
        if ruta in vistos: continue
        vistos.add(ruta)
        slot = 0 if tipo != 'audio' else 6
        grupo = next((g for g in meta['draft_materials'] if g['type'] == slot), None)
        if grupo is None: continue
        grupo['value'].append({'ai_group_type': '', 'create_time': int(time.time()), 'duration': us(info.get('dur') or 0) if tipo != 'photo' else 5000000, 'enter_from': 0,
                               'extra_info': os.path.basename(ruta), 'file_Path': ruta, 'height': info.get('h', 0), 'id': str(uuid.uuid4()), 'import_time': int(time.time()),
                               'import_time_ms': ahora, 'item_source': 1, 'material_color_tag': '', 'md5': '', 'metetype': tipo if tipo != 'audio' else 'music',
                               'roughcut_time_range': {'duration': -1, 'start': -1}, 'sub_time_range': {'duration': -1, 'start': -1}, 'type': 0, 'width': info.get('w', 0)})
    open(os.path.join(tmpD, 'draft_meta_info.json'), 'w', encoding='utf-8').write(mapa(json.dumps(meta, ensure_ascii=False)))
    try:   # portada: un cuadro de su Reel
        subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', '1', '-i', os.path.join(TR, 'base.mp4'), '-frames:v', '1', '-vf', 'scale=360:-2',
                        os.path.join(tmpD, 'draft_cover.jpg')], capture_output=True, timeout=60)
    except Exception:
        pass
    os.replace(tmpD, D)

    # ---- 8) que CapCut lo vea en su lista (sin tocar sus otros proyectos; con respaldo) ----
    if not a.salida:
        rm = os.path.join(a.capcut, 'root_meta_info.json')
        try:
            root = json.load(open(rm, encoding='utf-8')) if os.path.exists(rm) else {'all_draft_store': [], 'draft_ids': 0, 'root_path': a.capcut}
            if os.path.exists(rm): shutil.copy(rm, rm + '.antes-de-the-edit-lab')
            e = copy.deepcopy(T['root_entry'])
            e.update({'draft_cover': os.path.join(D, 'draft_cover.jpg'), 'draft_fold_path': D, 'draft_id': did, 'draft_json_file': os.path.join(D, 'draft_info.json'),
                      'draft_name': nombre_draft, 'draft_root_path': a.capcut, 'tm_draft_create': ahora, 'tm_draft_modified': ahora, 'tm_duration': dur,
                      'draft_timeline_materials_size': 0})
            e = json.loads(mapa(json.dumps(e, ensure_ascii=False)))
            root['all_draft_store'].insert(0, e); root['draft_ids'] = int(root.get('draft_ids') or 0) + 1
            tmp = rm + '.tmp'; json.dump(root, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False); os.replace(tmp, rm)
        except Exception as ex:
            avisos.append(f'no pude agregarlo a la lista de CapCut ({ex}); ábrelo desde la carpeta')
    res = {'ok': True, 'proyecto': nombre_draft, 'carpeta': D, 'duracion': round(dur / 1e6, 2), 'clips': len(pv['segments']), 'subtitulos': n_sub,
           'textos': n_txt, 'imagenes': n_img, 'capas_especiales': n_capa, 'silueta': n_sil, 'sonidos': n_snd, 'avisos': avisos}
    print('CAPCUT ' + json.dumps(res, ensure_ascii=False))


if __name__ == '__main__':
    main()
