# THE EDIT LAB ✦

Tu editora de Reels dentro de Claude. Pones tu material en una carpeta, eliges el formato (hablando a cámara, tutorial, voiceover o montaje con textos) y lo editas desde **tu página The Edit Lab** en 5 fases, con tus aprobaciones. Antes, en **Mi marca**, contestas unas preguntas y Claude crea tu Brand Kit y tu Editing System (y los de cada cliente, si editas para otras marcas):

1. **Análisis y hooks**: 3 hooks textuales, una recomendación, materiales de apoyo y dirección creativa.
2. **3 aperturas reales** con tu video, tu voz y tu marca.
3. **Storyboard** con fotogramas de tu grabación.
4. **Edición completa**: cortes, audio limpio, subtítulos, títulos, efectos y sonidos.
5. **Entrega**: tu Reel en *Resultado final* (V1, V2…), con resumen y control de calidad.

> **Uso personal.** No está permitido revender, compartir ni redistribuir este plugin, y no recomendamos modificarlo. Lee **LICENCIA.md** antes de hacer cualquier cambio.

Todo sigue *THE EDIT METHOD* y la identidad de tu marca: tus fuentes, colores, sonidos, stickers y tu *YOUR EDITING SYSTEM*. Tus archivos son solo tuyos: nadie más los ve.

## Qué necesitas
- Un plan de pago de Claude y la **app de escritorio de Claude** (Mac o Windows).
- En Claude, **Configuración → Capacidades**: acceso a la red con *Todos los dominios*.
- Tu computadora prendida, con la app de Claude abierta, mientras se edita.

## Instalación
1. Sube `the-edit-lab.plugin` en la app de Claude (Personalizar → Plugins).
2. Crea en tu computadora una carpeta llamada **The Edit Lab** (por ejemplo en Documentos).
3. Abre un chat nuevo, toca **+ → Agregar carpeta**, elige *The Edit Lab* y escribe: **instala mi The Edit Lab**.

Claude crea tus carpetas, tu página y tu editor. Desde ahí, todo se hace en tu página.

**Tu licencia.** La primera vez que abras tu página te pide el correo con el que compraste y tu clave personal (te llega con tu compra). Se activa una sola vez y solo funciona con tu correo.

## Tus carpetas
| Carpeta | Para qué |
|---|---|
| Reels / Reel 1, Reel 2… | Una carpeta por Reel con tu grabación. El video terminado aparece en *Resultado final*. |
| Brand Assets / 01 LOGO & FONTS | Tu logo y tus fuentes (.ttf / .otf) |
| Brand Assets / 02 COLORS | Tu paleta de colores |
| Brand Assets / 03 BACKGROUNDS | Fondos y texturas |
| Brand Assets / 04 STICKERS & GRAPHICS | Stickers y gráficos |
| Brand Assets / 05 EDITING REFERENCES | Videos que te inspiran (solo se toman técnicas) |
| Brand Assets / 06 MY CONTENT | Fotos, capturas o contenido tuyo (solo real) |
| Brand Assets / 07 SOUNDS EFFECTS | Tus efectos de sonido |
| Brand Assets / 08 B-ROLL | Clips y fotos de apoyo (solo reales) |
| Brand Assets / 09 MUSIC | Tu música con licencia (solo se usa si el formato la lleva o tú la pides) |

## Actualizaciones
Cuando recibas una versión nueva: súbela en **Personalizar → Plugins** (reemplaza la anterior) y en un chat escribe **actualiza mi The Edit Lab**. Tu página conserva su link y no pierdes nada: Reels, marca, instrucciones ni receta. Las novedades de cada versión están en `CAMBIOS.md`.

## Bueno saber
- Si no subes fuentes o sonidos, el editor usa fuentes gratuitas y 6 sonidos básicos propios.
- Después de tu primer Reel aprobado, el editor guarda tu **receta**: los siguientes Reels parten de ese estilo.
- En un chat también puedes usar las habilidades del editor directamente ("edita mi video", "ajusta mi video", "crea un efecto").
