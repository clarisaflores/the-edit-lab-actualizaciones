# Novedades de The Edit Lab

## 1.27.3
- **Tu editor de cortes se ve igual que el video final:** los cortes se reproducen fluidos, sin saltos ni pausas entre clips.
- **Tus respuestas de «Mi marca» mandan:** si elegiste textos sin cajas, ninguna apertura ni texto del Reel sale en caja.

## 1.27.2
- **Cortes más precisos:** cuando repites una frase se queda solo tu última toma, y ya no quedan pausas.
- **Lo que ves en tus cortes es exactamente lo que se edita.**

## 1.27.1
- **Avisos más claros:** la página ya no muestra mensajes técnicos; si algo falla, te lo dice en palabras simples.

## 1.27.0
- **Tus referencias se usan de verdad:** se analizan en movimiento (ritmo, zooms y textos) y en la dirección creativa ves qué se tomó de cada una.
- **Nuevo: Referencia para este Reel.** Sube un video que guíe solo ese Reel.

## 1.26.9
- **Mejor calidad de imagen y de sonido** en tus videos, sin que tengas que hacer nada.
- **Storyboard más claro,** con fotos reales de tu Reel y comentarios por número.
- **Textos siempre bien acomodados** dentro de la pantalla.
- **Nuevo: tu portada** al terminar cada Reel.
- **Hooks y efectos más precisos,** y reglas que se guardan por marca.

## 1.26.8
- **Escribir en Mi marca ya no se interrumpe:** el cursor se queda donde estás aunque la página se actualice, y no pierdes lo que escribiste.
- **Siguiente te lleva al paso nuevo,** no hasta arriba de la página.
- **Letras nuevas del editor:** DM Sans, Montserrat y Playfair Display, además de Anton, Instrument Serif y Caveat. Los 3 estilos listos ahora usan estas letras.
- **Los materiales se agregan en el editor:** cuando a tu Reel le falta B-roll, una captura o una foto, aparece con **Agregar archivo** (se guarda en la carpeta de tu Reel) o **No lo tengo** (el editor sigue sin él). No tienes que escribir nada en ningún otro lado.

## 1.26.7
- **Estilos listos renovados:** Editorial suave ahora usa un acento cherry wine, y Minimal limpio es todavía más suave: todo en Inter Regular, con un acento café medio y cajas en gris cálido.

## 1.26.6
- **Tu contenido y tu B-roll, en una sola carpeta:** ahora todo tu material real va en **06 MY CONTENT & B-ROLL** (capturas y resultados, lo que ya publicaste, y clips o fotos de apoyo). Claude mira cada archivo y lo usa como prueba o como B-roll según lo que dices. Si ya tenías la carpeta 08 B-ROLL, sigue funcionando y no se mueve nada.

## 1.26.5
- **Tus colores se guardan solos en tu archivo:** lo que agregas, cambias o quitas en Mis colores se escribe en tu archivo de 02 COLORS. Si tu archivo era de Word o RTF, ahora se llama «Mis colores.txt» y el anterior se guarda aparte (no se borra).
- **Tus carpetas de Brand Assets ya no se cambian:** cada área usa siempre su carpeta (01 LOGO & FONTS… 09 MUSIC). Si una carpeta falta, se vuelve a crear sola, vacía. Nunca se borra ni se mueve nada.

## 1.26.4
- **Tus Brand Assets se cargan solos:** ya no eliges carpetas. Cada área muestra lo que hay en su carpeta de Brand Assets (01 LOGO & FONTS, 02 COLORS… 09 MUSIC). Cuando agregas algo nuevo, aparece solo en unos segundos (también puedes tocar **Revisar mis carpetas**), y Claude siempre usa lo último que hay en tus carpetas al editar.
- Qué letra y qué color va en cada lugar ahora se elige solo en **Mi marca**, para no tener dos lugares distintos.

## 1.26.3
- **Más claro dónde va cada cosa:** «Mi Brand Kit» ahora se llama **Mis Brand Assets**, porque ahí conectas tus archivos (logo, fuentes, sonidos, referencias). Tu Brand Kit y tu Editing System, los documentos de tu estilo, se crean en **Mi marca** y tu editor los usa solo: no tienes que subirlos en ningún lado.
- **Ya no hay que subir documentos:** quitamos «Archivos de contexto». Tu Brand Kit y tu Editing System se crean en Mi marca y tu editor los usa solo. Si ya habías subido documentos, siguen funcionando y los puedes quitar en Mis instrucciones.
- **Inicio con los pasos en orden:** llena tus Brand Assets, crea tu marca, escribe tus instrucciones y edita tu primer Reel.

## 1.26.2
- **Videos más ágiles, sin pausas:** ahora se quitan todas las pausas (solo queda la respiración mínima para que no suene cortado), siempre hay texto en pantalla desde el primer segundo, algo cambia en pantalla al menos cada 4 segundos y los zooms van siempre rectos al centro de tu cara.
- **Más ordenado:** los botones para instalar y abrir The Edit Lab ahora vienen en dos carpetas, **Mac** y **Windows**. Si ya tienes los de antes, siguen funcionando igual.

## 1.26.1
- **Quitar una marca ahora te pregunta qué hacer con su carpeta:** quitarla y borrar su carpeta (para que no ocupe espacio; en Mac se va a la Papelera) o quitarla y dejar su carpeta en tu compu. Tu marca propia y tu Brand Assets nunca se borran.

## 1.26.0
- **Mi marca, nueva sección:** contestas 12 pasos de preguntas sobre tu marca (colores, letras, títulos, subtítulos, ritmo, sonidos, lo que no quieres…) y Claude crea tu **Brand Kit** y tu **Editing System**. Las preguntas te muestran tus archivos de Brand Assets para que elijas, y si no sabes qué poner, tocas «No sé: usa la recomendada». Se guardan solos en tu carpeta como «Mi Brand Kit» y «Mi Editing System». Los revisas, los apruebas y tus Reels se editan con eso.
- **3 estilos listos para empezar:** Editorial suave, Bold y energético, y Minimal limpio. Tocas uno y se llenan todas tus respuestas (colores, letras, títulos, subtítulos, ritmo, sonidos); después solo cambias lo que quieras. También hay 3 paletas de colores y las letras que trae el editor, con su muestra.
- **Antes de crear, un resumen:** «Así se van a editar tus videos», en frases claras, para revisar que todo sea lo que quieres.
- **Varias marcas:** si editas para clientes, agrega cada uno como marca de cliente. Cada marca tiene su carpeta, que se crea sola (Marcas › nombre, con las mismas subcarpetas que Brand Assets), su Brand Kit y su Editing System, y al editar un Reel eliges para qué marca es. Nunca se mezclan colores, letras ni recursos.

## 1.25.0
- **Menos formatos, más claros:** ahora son cuatro: Hablando a cámara, Tutorial, Voiceover y Montaje con textos. Cada tarjeta te dice para qué es y cuándo elegirla. Lo que antes era Lista de consejos, Pantalla dividida y Mixto ahora va en Hablando a cámara; Vlog va en Voiceover, y Lifestyle en Montaje con textos. Tus Reels de antes siguen funcionando.
- **«Qué necesito» en cada formato:** al elegir el formato de tu video, cada tarjeta tiene un botón que te dice qué subir, dónde ponerlo y consejos para grabarlo.
- **Plantillas de notas por formato:** cada formato trae su plantilla (hook, tomas, ritmo, cierre…). En tu editor de cortes, en «Notas para la edición», toca «Usar mi plantilla» y llénala. Puedes cambiar cada plantilla a tu gusto desde «Qué necesito»: se guarda sola y la usas en tus próximos videos.
- **Carpeta «Mis efectos» desde el principio:** al instalar se crea sola, junto a Brand Assets y Reels, para que pongas ahí tus stickers, animaciones y sonidos.
- **Plantilla de instrucciones nueva:** «Usar la plantilla» en Mis instrucciones trae unas instrucciones generales para tu editor, listas para adaptar a tu estilo.
- **Tus colores en todo:** las flechas, los tachados y los post-its toman los colores de tu estilo.

## 1.24.2
- **Tus errores se cortan mejor: la última toma gana.** Cuando vuelves a empezar una frase («yo ya no paso, yo ya no paso tres horas de, yo ya no paso tres horas editando»), se cortan los intentos y se queda solo el último. Lo mismo con frases repetidas, frases que se quedan a medias y la misma palabra dos veces. Tus repeticiones a propósito («no, no, no») se quedan.
- **Efectos en una palabra exacta:** en tu storyboard, debajo de cada escena, toca una de tus palabras y elige un efecto del catálogo. Sale justo cuando dices esa palabra.
- **Escucha cada parte de tu video otra vez, por separado**, para que la transcripción no se «trague» las repeticiones (era la razón por la que algunas se quedaban).

## 1.24.1
- **Textos detrás de ti, con un corte limpio:** el recorte de tu silueta ahora sigue la orilla real de tu cabello y tu cara, sin el halo borroso que se veía donde el texto se cruza con tu cabeza. También mejora la silueta que se usa para llevar tu video a CapCut.

## 1.24.0
- **Catálogo de efectos:** una sección nueva con 148 efectos listos (títulos animados, subtítulos con estilo, transiciones, pantallas de chat y de apps, tarjetas de redes sociales, gráficas, mapas, confeti, destellos y más), cada uno con su vista previa. Guarda tus favoritos con el corazón.
- **Elige efectos por escena:** en tu storyboard, debajo de cada escena, toca «Del catálogo de efectos». Claude lo arma con tus fuentes, tus colores y tus palabras, y lo pone en tu video como una capa más.
- Los efectos son de HyperFrames (HeyGen, licencia Apache 2.0) y se instalan solos la primera vez que eliges uno.

## 1.23.1
- **Licencias nuevas, apagadas por ahora:** el sistema de claves está listo pero apagado mientras se hacen pruebas. Abajo a la izquierda dice «Modo de pruebas · licencias apagadas». Cuando se prenda, cada clienta pone su clave una sola vez.

## 1.23.0
- **Reportes que le llegan a The Edit Lab:** cuando Claude revisa tu reporte y ve que el problema es del programa (no de tu compu), primero se asegura de que tengas la versión más nueva. Si sigue pasando, en la campanita te aparece «Enviar por correo» con el correo ya escrito.
- **Tu copia siempre es la original:** The Edit Lab revisa solo que sus archivos no hayan cambiado y, si algo se modificó o se borró, vuelve a poner el original. Tus Reels, tu Brand Kit y tus instrucciones no se tocan.
- **Licencias canceladas:** una licencia compartida o revendida se puede cancelar y deja de funcionar.

## 1.22.0
- **Tu Edit Lab se actualiza solo:** busca versiones nuevas en internet y, cuando Claude no está editando, las instala solo, con una copia de respaldo de la versión anterior. La página se pone al día sola y la campanita te cuenta qué cambió. Si prefieres no esperar, en la campanita está «Actualizar ahora».
- **Reportar un problema** ahora también dice si hay una versión más nueva.
- **Noticias:** la campanita también muestra las novedades que publique The Edit Lab.

## 1.21.0
- **Tu Reel terminado se descarga o se termina en tu app:** ya no se edita dentro de The Edit Lab. CapCut y Edits aparecen como «Próximamente», con todo editable y en capas.
- **Piloto automático:** después de tu primer Reel terminado, eliges «Paso a paso» o «Piloto automático». En piloto, Claude edita de principio a fin sin pausas, como has aprobado tus Reels (tu formato más usado, el hook y la apertura que recomienda, tus reglas, tu estilo y tus ajustes), y al final te dice qué decidió.
- **Menú de cada palabra en tus cortes:** quitar o regresar, resaltar en los subtítulos, o dejarle una nota a Claude («Se corta el sonido», «Pausa incómoda», «Toma equivocada», «No se entiende» o la tuya).
- **Rampas de velocidad:** «Rápido, frenando a normal» y «Normal, acelerando», en un solo movimiento fluido.
- **Línea de tiempo más alta:** arrastra la barrita de arriba (doble clic la regresa). Al pasar el mouse por «Antes» o «Después» se sombrea lo que va a cortar.
- **Ajustes de tu video** en el storyboard: color (cinematográfico, cálido, frío, película, blanco y negro), subtítulos con barra y tapar caras (desenfoque, pixelado o emoji).
- **Campanita de notificaciones:** te avisa cuando tienes una versión nueva y sus novedades.
- **Reportar un problema:** un botón arriba junta todo en un archivo; en Claude escribe «revisa mi reporte» y lo arregla.
- **Español / English:** un interruptor como el modo nocturno cambia toda la página. Claude te escribe en tu idioma; los textos de tu video siguen en el idioma en que hablas.
- Arreglado: «No se pudo guardar … hooksHechos» en Multiplica.

## 1.20.1
- **El editor muestra tu video exacto, cuadro por cuadro:** al abrir un Reel terminado, el editor reproduce tu corte real (con las orillas afinadas por el sonido) y el plan con el que de verdad quedó tu video, incluidos los últimos ajustes. Los textos, tarjetas y escenas salen en el mismo segundo, lugar y tamaño que en tu video final. Si cambias un corte, la vista se rehace con tus cortes nuevos.
- **Toca un texto o efecto en el video** para editarlo en ese momento.
- **Llevar a CapCut: próximamente.** Lo estamos perfeccionando.
- El panel de elementos de las escenas ya respeta el modo nocturno.

## 1.20.0
- **Tu editor muestra el video tal cual va a quedar:** al abrir el editor de un Reel terminado, la vista ya no es una aproximación. Usa el mismo motor que arma tu video final, con tus fuentes, colores, escenas editorial, animaciones, stickers y sonidos. Cada cambio que haces (mover, borrar o agregar un texto, un acercamiento, un corte o la velocidad de una parte) se vuelve a dibujar en segundos, y si algo queda encima de tu cara, te avisa y lo mueve. La primera vez se prepara solo (1 a 3 minutos).
- **Exportar a CapCut en cualquier compu:** el exportador es código propio de The Edit Lab, no necesita ninguna librería extra, y ahora también funciona en Windows.

## 1.19.0
- **Exportar a CapCut, con todo editable:** en tu Reel terminado, «Exportar a CapCut» crea un proyecto en tu CapCut (CapCut cerrado). Cada corte es su propio clip desde tus videos ORIGINALES, con velocidad y zooms como keyframes; cada subtítulo y cada título es texto con tus fuentes y colores; cajas, post-its, flechas, cursores, imágenes y clips de las escenas editorial van cada uno en su capa con sus entradas como keyframes; el texto detrás de tu cabeza va editable con tu silueta recortada encima; cada sonido en su clip. Los efectos que CapCut no puede construir (Finder, línea de tiempo animada, escribir letra por letra, el círculo con tu cara) van cada uno como capa transparente que puedes mover, recortar o quitar. Nunca reemplaza un proyecto tuyo: cada exportación es una versión nueva (Reel 8 1.1, 1.2…). Lo arma tu compu, sin gastar uso de Claude.

## 1.18.0
Mejoras de edición:
- **Arranques en falso por el sonido:** compara cómo SUENA el comienzo de lo que dijiste antes de una pausa corta con lo que dices después; si empieza igual, la toma de antes se tacha. Encuentra los que la transcripción no ve («este check… este checklist»). Corre solo en tu compu, sin gastar uso.
- **Pausas escondidas:** mide en el sonido los silencios de más de 0.7 s que la transcripción no marca (una palabra estirada encima de una pausa) y los quita, dejando 0.12 s de respiro.
- **Revisión de cada unión:** después de unir, escucha cada corte buscando un clic o un hueco; esas uniones se funden más largo y se vuelven a escuchar.
- **Velocidad y zoom por parte** en el editor de cortes: Normal, 1.25×, 1.5× o 2×, y Acercar / Alejar poco a poco. La vista previa lo reproduce y el video final lo respeta.
- **Solo se rehace lo que cambió:** en una versión nueva solo se vuelven a animar los tramos de 15 s donde algo cambió.
- **Tu cara medida en todo el video** (cada segundo): los textos y stickers se revisan contra dónde estás EN ESE momento y, si te tapan, se pasan solos al lugar libre más cercano.
- **Enséñale tu estilo:** al terminar un Reel, te propone reglas sacadas de lo que pediste en ese Reel; marcas las que quieres guardar.
- **Música de fondo medida contra tu voz:** un nivel fijo, sin entrada gradual, con salida corta; opcional que suba un poco en tus pausas largas.
- **Escucha tus sonidos y tu música** en Mi Brand Kit con el botón ▶.

## 1.17.0
- **Modo nocturno de inicio** (el interruptor sigue en el menú para cambiarlo).
- **Las fases de tu Reel resaltan:** números grandes en círculo, unidos por una línea; la fase actual más grande.
- **Se acabó el «se quedó esperando y lo retomé»:** era una falsa alarma. El vigilante tomaba el paso siguiente como atorado y además relanzaba pedidos viejos que Claude rechazaba (unos 20 s de uso perdidos cada vez). Ahora el trabajo siempre sale del estado real del Reel, los pedidos repetidos se descartan y solo avisa si un paso de verdad termina sin avanzar.
- **Avisos con el mismo fondo que la página** (de día y de noche), con borde y punto rojo cuando es un error. La ventana de Brand Assets del storyboard también sigue el modo.
- **La barra de avance ya se mueve:** se calcula en tu compu con lo que suele tardar cada fase (sin gastar uso) y sube con cada paso. Si algo falla, la barra se queda roja donde se detuvo y el error sale justo debajo.
- **Materiales de apoyo de ESTE Reel:** cada material sale de una frase exacta de este video, con su momento.
- **Ediciones más rápidas:** los cortes se guardan con su huella y en una versión nueva solo se vuelven a cortar los que cambiaron; el video base no se rehace si los cortes no cambiaron. Multiplica usa el modelo rápido (gasta menos uso).
- **Brand Kit:** miniaturas chicas de tus imágenes; tus colores se toman de un archivo de texto (.txt, .rtf, .doc o .docx) en tu carpeta 02 COLORS y aquí los agregas, cambias o quitas; textos más claros.

## 1.16.0
Las mismas reglas de corte que un editor profesional por transcripción, en tu propio motor:
- **Cómo se arman los clips:** cada oración es su pieza, del arranque de su primera palabra al apagado de la última. Dentro de una oración solo se parte en pausas de más de 0.30 s; cualquier pausa de más de 0.6 s parte; oraciones pegadas sin pausa quedan en un solo clip. (Sustituye la regla de 0.4 / 0.5 s de la 1.15.0.)
- **Qué se quita solo:** toma repetida (se queda la última), fragmento de una frase más completa, arranque en falso, muletillas sueltas, calentamiento antes de la primera frase y palabras sueltas.
- **Orillas medidas en el sonido:** cada corte empieza 42 ms antes de que arranque tu voz y termina 60 ms después de que se apaga.
- **Uniones sin clic:** en cada unión el sonido del corte que sale sigue 6 ms y se funde con el que entra a potencia constante; ya no baja a silencio entre cortes. Solo el inicio y el final del video se desvanecen.
- **Tus orillas se respetan exactas:** lo que arrastras, divides o cortas a mano ya no lo vuelve a afinar el motor.
- **Editor de cortes:** una palabra se tacha solo cuando le quedan menos de 50 ms; Shift al arrastrar una orilla la mueve 10× más lento; una orilla no puede pasar de la parte vecina (nada se repite) ni salir más de 4 s; el cabezal se queda donde estaba al recortar; Q y W cortan lo de antes / después del cabezal; , y . avanzan un cuadro; el zoom llega hasta unos 400 px por segundo; la transcripción deja de seguir a la voz si tú la mueves y vuelve al dar play; aviso cuando quitas una palabra pegada a la de junto.

## 1.15.0
- **Fase 1 más limpia:** se quitó la ventana «Lo que Claude quitó». Ahora tu video va centrado y debajo tu línea de cortes con el botón para abrir el editor.
- **Zoom fluido con el trackpad** en la línea de tiempo: mientras pellizcas solo se estiran los bloques (60 cuadros por segundo) y al soltar se redibuja el detalle.
- **Tocar una palabra ya no te regresa arriba:** la transcripción y el panel de partes se quedan donde estabas.
- **Frase seguida = un solo clip:** ya no se corta en respiraciones cortas. Solo hay corte donde se quitó algo o hay una pausa real (más de ~0.4 s; 0.5 s entre oraciones).
- **Storyboard por escena:** cada escena con su foto y, justo debajo, tu comentario y tus Brand Assets (los storyboards nuevos traen una foto por escena).
- **Editar Reel siempre te deja elegir:** entra a la pantalla de tu carpeta y eliges el Reel; ya no se abre uno solo ni aparecen todos arriba. Solo se ve el que elegiste, con «Cambiar de Reel».
- **Aviso al quitar un Reel (×):** explica que se borra todo lo de ese Reel de tu compu menos el original, el antes, el después y Multiplica — y ahora sí borra su carpeta de trabajo.
- **Modo nocturno:** interruptor en el menú. Todo casi negro, botones beige y el rosa solo en acentos.

## 1.14.10
- **«Tus piezas» más pequeño:** la portada de cada pieza ya no ocupa toda la pantalla; caben 3 o más piezas en una fila.

## 1.14.9
- **Multiplica tu Reel más compacto:** las tarjetas de «Elige qué crear» y las vistas previas de tus clips de Hooks ahora son pequeñas, como en las otras secciones.

## 1.14.8
- **Multiplica tu Reel con tus clips de Hooks:** en «Hooks hablados» aparecen todos los clips de la carpeta Hooks del Reel (con vista previa). Marca los que quieras y se crea un video por cada clip: mismo video, misma edición, solo cambia el hook. «Actualizar lista» recarga la carpeta.

## 1.14.7
- **Multiplica tu Reel, otro hook:** al pedir más hooks hablados solo se crean los clips nuevos de la carpeta Hooks (Hook 3, Hook 4…), sin repetir los ya hechos.

## 1.14.6
- **La vista del video cortado en Hooks (y en Cortes) ya no se queda con una versión vieja:** se actualiza sola cuando cambian tus cortes o la transcripción (antes podía seguir mostrando una repetición ya corregida).

## 1.14.5
- **Se acabó la pausa al iniciar cada clip:** el video ligero del editor tenía un cuadro de salto cada ~10 s, así que cada clip obligaba a decodificar hasta 10 s antes de arrancar. Ahora se regenera con uno cada 0.25 s (automático al abrir The Edit Lab para tus reels anteriores; los reels nuevos ya salen así).

## 1.14.4
- **Repeticiones («misma, misma cámara»):** la transcripción se comía la palabra repetida. Ahora un paso nuevo (`repeticiones.py`) vuelve a escuchar los pedazos sospechosos y rescata las palabras repetidas; la toma anterior se corta como arranque en falso.

## 1.14.3
- **Pausa antes de cada clip:** la siguiente parte se precarga y arranca con 0.12 s de ventaja (en silencio) para entrar justo al cambiar; medido con video de prueba: sin ningún retraso entre partes.
- **Transcripción:** una palabra solo sale tachada si de verdad perdiste más de la mitad de ella; si quedó cortada a medias se ve en amarillo.

## 1.14.2
- **Todo es editable en «Escena animada»** y otros efectos compuestos: el inspector muestra cada elemento (textos, posición, tamaño, color, tiempos, listas con ＋ Agregar y ×) y la vista previa los dibuja en su lugar.
- Corregido un error que rompía el inspector de efectos en 1.14.1.

## 1.14.1
- **Zoom con el mousepad** en la línea de tiempo (pellizcar o Ctrl/⌘ + rueda), centrado donde tienes el cursor; hasta 40×.
- **Recorte exacto como CapCut:** al jalar el borde de una parte se pega al cabezal, lo de después se recorre en vivo, la línea de tiempo no salta y el cabezal queda justo en el corte.
- **Reproducción sin pausas** entre partes (doble video que se precarga) y cortes en cada silencio (pausa de 0.25 s, márgenes de 30 / 50 ms).
- **«Reproducir mis cortes»** abre el editor de cortes y reproduce.
- **Storyboard:** comentario y recursos de tus Brand Assets por escena (`sbComentarios`).
- **«Editorial» ya no sale a secas:** se llama «Escena animada», con los textos que escribe en la línea de tiempo y en el inspector.

## 1.14.0
- **Cortes exactos, sin silencio pegado:** cada inicio y cada final de corte se mide ahora con el sonido real (cada 5 milésimas de segundo) y se coloca justo donde la voz empieza (con 20 ms de colchón) y donde se apaga (con 40 ms). Se acabaron los 60–300 ms de silencio al inicio o final de cada frase que veíamos en tus videos.
- **Ya no se «pierde» el arranque ni el final de las palabras:** en tus dos últimos videos varios cortes caían unos milisegundos después de que la palabra empezaba (la consonante suave se oía bajito, como si no la dijeras) o antes de que terminara («gusta», «videos»). Ahora el corte retrocede al arranque real y espera a que la palabra termine.
- **Lo que tú cortas a mano se respeta:** si un corte cae a media palabra o entre voz pegada, no se mueve.
- Al pasar a cuadros, el final de la voz ya no se recorta por redondeo.

## 1.13.9
- **Avisos claros en pantalla:** cuando pasa algo (se acabó tu límite de uso de Claude, Claude Code no tiene la sesión iniciada, Claude está saturado, no hay internet, falta Claude Code, tu licencia no está activa, o un Reel no logra arrancar), arriba de la página aparece un aviso con **qué pasó** y **qué hacer**, en palabras simples. Lo puedes cerrar con la ✕ y se quita solo cuando el problema se resuelve. Además sigue quedando anotado en `incidentes.log`.
- **Arreglo importante:** cuando se acababa el límite de Claude, el Reel no se marcaba como «Error» (se quedaba en «Analizando» para siempre). Ahora sí se marca y te explica por qué.

## 1.13.8
- **Te avisa en pantalla cuando algo se atora:** si tu Reel dice que está trabajando pero nada está corriendo en tu Mac, aparece un aviso amarillo «Nada está trabajando…» con el botón **Retomar ahora**, y la página intenta retomarlo sola.
- **Si se retoma solo, te lo dice** («Se había quedado esperando sin arrancar y lo retomé automáticamente»). Si ni con 2 reintentos arranca, el Reel pasa a «Algo salió mal» con el motivo.
- **Bitácora de incidentes:** lo raro queda anotado en `.the-edit-lab/registros/incidentes.log` para poder revisarlo.
- **Un Reel terminado ya no se vuelve a editar por un pedido viejo** (Reel 5 se había quedado con su «editar» pendiente aunque ya estaba terminado).

## 1.13.7
- **Al abrir The Edit Lab siempre carga la versión nueva:** antes, si ya había una ventana abierta, «Abrir The Edit Lab.command» solo abría el navegador con la versión vieja y los arreglos no se activaban. Ahora compara la versión abierta con la instalada y, si son distintas, la reinicia sola (tu trabajo está guardado en tu compu).

## 1.13.6
- **Si tu edición se queda «En cola» sin arrancar, se retoma sola:** el auto-arranque de 1.13.5 también cubre los reels en cola, editando o analizando (antes solo «Preparando…»), y además se revisa al abrir The Edit Lab, así un reel que quedó esperando de antes se retoma al abrirlo.

## 1.13.5
- **Ya no se queda esperando sin avisar:** si elegías tu apertura justo cuando terminaba otro pedido, el storyboard podía quedarse en «Preparando» sin que nadie lo arrancara. Ahora, cuando The Edit Lab queda libre y algo sigue esperando, lo lanza solo (máximo 2 veces por reel). Y los pedidos repetidos que ya no corresponden (por ejemplo, «aperturas» cuando ya estás en el storyboard) se descartan sin gastar tu uso de Claude.

## 1.13.4
- **Subtítulos en su lugar:** la transcripción solía poner el inicio de varias palabras 0.2 a 0.7 s antes de que hables (dentro del silencio), y por eso los subtítulos se veían corridos. Ahora cada inicio busca el arranque real de tu voz (hasta 0.6 s adelante o 0.15 s atrás) y el editor coloca cada palabra dentro de la parte donde realmente cae, aunque haya quedado a medias.
- **Recorte como en CapCut:** si jalas el INICIO de una parte, se mueve el inicio y el final se queda donde está (antes parecía que se cortaba del final). Si jalas el final, se mueve el final.
- **Imán con el cursor:** al jalar la orilla de una parte, se pega al cursor de la línea del tiempo cuando pasa cerca, y el cursor se ilumina para avisarte que ahí quedó el corte exacto.

## 1.13.3
- **Al cortar, tus textos, subtítulos y efectos se recorren con el video:** si borras una parte, recortas su inicio o su final (arrastrando o con los botones), lo que pusiste o moviste a mano después de ese corte se mueve contigo y ya no se desfasa. Si lo que tenías estaba justo en la parte que borraste, se pega al punto del corte con la misma duración.

## 1.13.2
- **Puedes cancelar aunque Claude ya esté trabajando:** mientras tu reel se analiza o se edita aparece el botón **Cancelar**; detiene a Claude al momento (ya no sigue gastando tu uso) y tu reel regresa a elegir lo que quieras.

## 1.13.1
- **Ahora te muestra los errores de Claude:** si Claude no puede trabajar (se agotó tu límite de uso, no tiene la sesión iniciada, está saturado o no hay internet), tu reel pasa a "Algo salió mal" con el motivo en español y cuándo se restablece, y un botón **Volver a intentar**. Antes se quedaba en "Analizando" sin explicación.

## 1.13.0
- **Cortes más exactos:** la transcripción se equivoca 50–200 ms al decir dónde empieza y termina cada palabra, y por eso un corte a veces se comía la primera letra o dejaba la cola de la palabra anterior. Ahora, al terminar de transcribir, cada inicio y final se acomoda con el sonido real de tu voz (y, si dos palabras van pegadas, en el punto más silencioso entre ellas). Los cortes que tú arrastras a mano no se tocan.

## 1.12.1
- **Quitar un reel ahora lo oculta de verdad:** antes, si su carpeta seguía en Reels, el reel volvía a aparecer en la lista de tu compu. Ahora queda oculto, con un aviso "Reel quitado de esta lista · Mostrarlo otra vez".

## 1.12.0
- **Panel "Por parte del video" en el editor:** a la derecha de tu video aparece cada parte (corte) con su transcripción, un cuadro de notas y un botón **＋ De mis archivos**, para elegir de tus stickers, fondos, B-roll, contenido o logo lo que quieres que aparezca justo en esa parte. Funciona en la fase de cortes y en el editor de efectos. Claude lo cumple al editar, por encima de las reglas generales.

## 1.11.0
- **Más rápido y gasta menos de tu límite de uso:** cada fase ahora lee solo las instrucciones que necesita (hasta 80 % menos texto en cada edición), la página le dice a Claude qué reel y qué fase le toca en vez de que lo averigüe, y Claude hace menos vueltas (menos escrituras de avance, una sola foto por fase, respuestas cortas).
- **Tiempos por fase:** se guardan en `.the-edit-lab/registros/tiempos.jsonl` y cada registro termina con cuánto tardó.

## 1.10.2
- **"Actualizar mis Reels" ahora es instantáneo:** antes despertaba a Claude para revisar la carpeta y tardaba cerca de un minuto. Ahora la página la lee directo de tu computadora al momento.

## 1.10.1
- **Modo de pruebas (solo para quien instala y prueba):** si existe un archivo vacío llamado `sin-licencia` junto a `licencia.json` o dentro de la carpeta `local` del plugin, la página no pide clave. No se incluye en el paquete que se entrega; para volver a pedir licencia, se borra el archivo.

## 1.10.0
- **Quitar reels de la lista:** en *Mis Reels* cada Reel tiene una × para quitarlo (con confirmación) y un enlace para quitar todos los terminados. Solo se quita de la lista y se borran las copias que la página guardó; tus videos originales y tu carpeta Resultado final no se tocan.
- **Storyboard en video (opcional):** además de la hoja de imágenes, puedes pedir *Ver mi storyboard en video*: un clip corto por cada escena. Tarda más (calcula entre 5 y 15 minutos extra), por eso es opcional.
- **Antes y después:** al terminar, la página muestra tu video con solo cortes junto al Reel editado, y guarda el "ANTES" en Resultado final.

## 1.9.0
- **Editor de cortes tipo CapCut:** en la fase de cortes se abre una pantalla completa con tu video en miniaturas y la forma de onda de tu voz. Recortas arrastrando las orillas, divides con B, y quitas o regresas palabras tocándolas en tu transcripción (la palabra que suena se ilumina mientras reproduces).
- **Nuevo diseño:** colores de theclariedit.com. El negro solo en títulos y letras; botones beige con letras negras como en tu web; rosa para acentos y detalles; beige y amarillos para todo lo demás. Banner con degradado rosa a beige y editor en tonos claros. Sin azul ni café.
- **Claves automáticas:** las claves de licencia se pueden mandar solas desde tu tienda de Shopify.

## 1.8.0
- **Editor visual:** cuando tu Reel está listo, *Ajustar en el editor* abre una pantalla tipo CapCut: tu video, una línea de tiempo con tus textos, efectos, acercamientos y sonidos, y una vista previa. Mueve, alarga, recorta, divide (B), borra, agrega textos o acercamientos, deshaz (⌘Z) y presiona *Crear versión nueva*: Claude hace la versión respetando exacto lo que acomodaste. Tus cambios se guardan solos como borrador.
- **Tu licencia:** cada copia se activa una vez con el correo de compra y su clave personal; la página muestra a nombre de quién está y cada Reel guarda su número de licencia.
- La exportación sigue siendo MP4.

## 1.7.0
- **Windows:** The Edit Lab ahora también se instala y edita en Windows (doble clic en *Instalar The Edit Lab (Windows).bat* y luego *Abrir The Edit Lab (Windows).bat*).
- **Instalación para clientas:** el instalador crea solo sus carpetas (Reels y Brand Assets 01–09) y sus instrucciones para Claude Code.
- **Más estable:** el motor usa su propio Python, así no choca con otros programas de la computadora; la página local tiene su propia dirección (localhost:4791) y nunca se confunde con otras apps.

## 1.6.0
- **Modo local:** The Edit Lab se instala una vez en tu Mac (doble clic en *Instalar The Edit Lab.command*) y tu página se abre en tu Mac con *Abrir The Edit Lab.command* o escribiendo `the-edit-lab` en la terminal. Cada fase corre en tu Mac con Claude Code: sin subir ni bajar videos y sin reinstalar nada.

## 1.5.0
- *Multiplica tu Reel* ahora tiene **3 Trial Reels** y **Hooks hablados** (el carrusel y la story regresan más adelante).
- **Más rápido:** el editor ya no descarga los modelos de voz en cada fase, solo cuando los usa. Las aperturas y el storyboard tardan unos 6 minutos menos cada una, y la edición final casi 6 minutos menos.
- **Hooks hablados:** en *Multiplica tu Reel* hay una pieza nueva. Graba otros inicios para el mismo Reel, ponlos en la carpeta **Hooks** de tu Reel y Claude crea una versión completa por cada uno, reutilizando todo lo que ya aprobaste.
- **Video listo:** cuando tu Reel está terminado y ya no vas a pedir cambios, toca **Video listo ✓** y Claude borra los archivos de trabajo de ese Reel en tu compu. Tus originales y tus versiones terminadas no se tocan.
- **Tus efectos programados se guardan:** los efectos que Claude programa para ti (como el video encogido, los Reels flotando o los comentarios) quedan en una biblioteca de tu Brand Assets y se pueden usar en tus siguientes Reels.

## 1.4.0
- Dos formatos nuevos: **Vlog** y **Mixto u otro** (en Mixto escribes qué combinación necesitas). Ahora son 9 y *Hablando a cámara* va primero.
- Nueva plantilla de instrucciones con la **Fase 0** (elegir el formato) y reglas para videos con y sin voz. Si quieres usarla, toca **Usar la plantilla** en Mis instrucciones.

## 1.3.0
- **Formatos de video:** antes de analizar eliges qué tipo de video es: Hablando a cámara, Voiceover, Tutorial, Pantalla dividida, Lifestyle, Lista de consejos o Montaje visual. Claude adapta las 5 fases a ese formato. En Montaje visual escribes tu mensaje o tus textos en la página.
- **Nueva carpeta 09 MUSIC** en Brand Assets para tu música con licencia. Si actualizas, créala dentro de tu carpeta Brand Assets y elígela en **Mi Brand Kit → Música**.

## 1.2.0
- **Multiplica tu Reel** ahora funciona todo desde tu página: eliges un Reel terminado, qué crear (carrusel, story o 3 Trial Reels) y tocas **Crear**. Claude lo hace con tu Brand Kit, tus instrucciones y tus palabras reales, y tus piezas aparecen ahí mismo para descargarlas (y en *Resultado final → Multiplica* de tu Reel).

## 1.1.1
- Nueva plantilla de instrucciones en **Mis instrucciones**: el flujo completo de 5 fases (análisis y hooks, aperturas, storyboard, edición y entrega), basado en tu *YOUR EDITING SYSTEM* y *THE EDIT METHOD*. Si quieres usarla, toca **Usar la plantilla** y ajústala a tu gusto.

## 1.1.0
- Nueva orden **actualiza mi The Edit Lab**: cuando recibes una versión nueva del plugin, actualiza tu página y tu editor sin perder nada.

## 1.0.1
- Las carpetas de Brand Assets ahora son 01 LOGO & FONTS, 02 COLORS, 03 BACKGROUNDS, 04 STICKERS & GRAPHICS, 05 EDITING REFERENCES, 06 MY CONTENT, 07 SOUNDS EFFECTS y 08 B-ROLL.
- Mi Brand Kit tiene dos áreas nuevas: Colores y Mi contenido.

## 1.0.0
- Primera versión.
