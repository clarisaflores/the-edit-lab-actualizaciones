"""Analiza videos de referencia EN MOVIMIENTO (no solo fotos sueltas): ritmo de cortes, zooms, movimiento y textos.

Uso:
  python3 referencias.py <video o carpeta> [<video> ...] --salida <carpeta> [--max 3]

Para cada video (de una carpeta toma los más recientes, hasta --max) mide:
  - cortes: en qué segundo cambia el plano (detector de escena de ffmpeg) → cada cuánto corta (promedio y mediana);
  - zooms: entre cortes compara cuadros seguidos y detecta si la imagen se acerca o se aleja, cuánto y en cuánto tiempo;
  - movimiento: qué tan "vivo" se ve cada segundo (0 = quieto, 1 = mucho movimiento) y los momentos más activos;
  - textos: en qué partes de la pantalla aparece texto (arriba / centro / abajo) y cada cuánto entra uno nuevo
    (cambios de bordes finos de alto contraste; es una medida aproximada, no lee las letras);
  - una hoja de cuadros: un cuadro por plano (hasta 12) con su segundo escrito, para mirarla con Read.
Guarda <salida>/<nombre>.json y <nombre>_hoja.jpg, y un resumen.md legible con lo que se puede tomar de cada una.
Los resultados se guardan por huella del archivo: la segunda vez es instantáneo.
Solo mide técnica. Nunca copia su marca, colores, textos, música ni material.
"""
import argparse, glob, hashlib, json, os, re, shutil, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import save_json, load_json

VID = ('.mp4', '.mov', '.m4v', '.webm', '.mkv')
ap = argparse.ArgumentParser(); ap.add_argument('entradas', nargs='+'); ap.add_argument('--salida', required=True); ap.add_argument('--max', type=int, default=3)
a = ap.parse_args(); os.makedirs(a.salida, exist_ok=True)

vids = []
for e in a.entradas:
    if os.path.isdir(e):
        L = sorted([os.path.join(e, f) for f in os.listdir(e) if f.lower().endswith(VID) and not f.startswith('.')], key=os.path.getmtime, reverse=True)
        vids += L[:a.max]
    elif os.path.isfile(e) and e.lower().endswith(VID): vids.append(e)
if not vids: print('No encontré videos de referencia.'); sys.exit(0)

def huella(p):
    st = os.stat(p); return hashlib.sha1(f'{os.path.abspath(p)}|{st.st_size}|{st.st_mtime_ns}|v2'.encode()).hexdigest()[:12]

def dur(p):
    o = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', p], capture_output=True, text=True).stdout.strip()
    try: return float(o)
    except ValueError: return 0.0

def cortes(p):
    o = subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-i', p, '-vf', "scale=180:-2,select='gt(scene,0.32)',showinfo", '-an', '-f', 'null', '-'],
                       capture_output=True, text=True).stderr
    ts = [float(m) for m in re.findall(r'pts_time:([0-9.]+)', o)]
    out = []
    for t in ts:
        if not out or t - out[-1] > 0.25: out.append(round(t, 2))
    return out

import numpy as np, cv2

def cuadros(p, fps=6, w=180):
    cap = cv2.VideoCapture(p); vf = cap.get(cv2.CAP_PROP_FPS) or 30; paso = max(1, int(round(vf / fps))); F = []; i = 0
    while True:
        ok = cap.grab()
        if not ok: break
        if i % paso == 0:
            ok, im = cap.retrieve()
            if not ok: break
            h = int(im.shape[0] * w / im.shape[1]); F.append((i / vf, cv2.cvtColor(cv2.resize(im, (w, h)), cv2.COLOR_BGR2GRAY)))
        i += 1
    cap.release(); return F

def escala_entre(g0, g1):
    """Cuánto se agranda la imagen de g0 a g1 (>1 acerca, <1 aleja), con el flujo óptico desde el centro."""
    pts = cv2.goodFeaturesToTrack(g0, 80, 0.01, 6)
    if pts is None or len(pts) < 12: return 1.0
    p1, st, _ = cv2.calcOpticalFlowPyrLK(g0, g1, pts, None)
    ok = st.ravel() == 1
    if ok.sum() < 10: return 1.0
    A, B = pts[ok].reshape(-1, 2), p1[ok].reshape(-1, 2)
    M, inl = cv2.estimateAffinePartial2D(A, B, method=cv2.RANSAC, ransacReprojThreshold=2.0)
    if M is None or (inl is not None and inl.sum() < 8): return 1.0
    return float(np.hypot(M[0, 0], M[1, 0]))   # escala del movimiento (sin importar hacia dónde acerca)

def analiza(p):
    D = dur(p); C = cortes(p); F = cuadros(p)
    planos = [0.0] + C + [D]; largos = [round(planos[i + 1] - planos[i], 2) for i in range(len(planos) - 1) if planos[i + 1] - planos[i] > 0.05]
    mov = {}; zooms = []; textos = {'arriba': 0, 'centro': 0, 'abajo': 0}; entradas = []; prev_tx = None
    for k in range(1, len(F)):
        (t0, g0), (t1, g1) = F[k - 1], F[k]
        if any(t0 < c <= t1 for c in C): continue                                   # no medir a través de un corte
        dif = float(np.mean(cv2.absdiff(g0, g1))) / 255.0
        s = int(t1); mov[s] = max(mov.get(s, 0), dif)
        z = escala_entre(g0, g1)
        if abs(z - 1) > 0.004: zooms.append((t0, t1, z))
        # texto: bordes finos y de mucho contraste en franjas horizontales
        ed = cv2.Canny(g1, 120, 240); h = ed.shape[0]; fr = {'arriba': ed[:h // 3], 'centro': ed[h // 3:2 * h // 3], 'abajo': ed[2 * h // 3:]}
        tx = {n: float(x.mean()) / 255.0 for n, x in fr.items()}
        for n, v in tx.items():
            if v > 0.06: textos[n] += 1
        if prev_tx and max(tx[n] - prev_tx[n] for n in tx) > 0.035: entradas.append(round(t1, 2))
        prev_tx = tx
    # juntar zooms seguidos en movimientos
    movs = []
    for t0, t1, z in zooms:
        if movs and t0 - movs[-1]['hasta'] < 0.4 and (z > 1) == (movs[-1]['factor'] > 1):
            movs[-1]['hasta'] = round(t1, 2); movs[-1]['factor'] = round(movs[-1]['factor'] * z, 3)
        else: movs.append({'desde': round(t0, 2), 'hasta': round(t1, 2), 'factor': round(z, 3)})
    movs = [m for m in movs if abs(m['factor'] - 1) > 0.04]
    ent = []
    for t in entradas:
        if not ent or t - ent[-1] > 0.6: ent.append(t)
    tot = max(1, sum(textos.values()))
    activos = sorted(mov, key=lambda s: -mov[s])[:5]
    r = {'archivo': os.path.basename(p), 'duracion': round(D, 2), 'cortes': C,
         'planos': len(largos), 'plano_promedio': round(float(np.mean(largos)), 2) if largos else round(D, 2),
         'plano_mediana': round(float(np.median(largos)), 2) if largos else round(D, 2),
         'zooms': [dict(m, tipo='acerca' if m['factor'] > 1 else 'aleja', dura=round(m['hasta'] - m['desde'], 2)) for m in movs],
         'movimiento_promedio': round(float(np.mean(list(mov.values()))) * 10, 2) if mov else 0,
         'segundos_mas_activos': sorted(activos),
         'texto_zonas': {n: round(v / tot, 2) for n, v in textos.items()},
         'textos_nuevos': ent, 'texto_cada': round(D / max(1, len(ent)), 2) if ent else None}
    # hoja: un cuadro por plano (máximo 12), con su segundo
    ts = [round((planos[i] + planos[i + 1]) / 2, 2) for i in range(len(planos) - 1)][:12] or [D / 2]
    from PIL import Image, ImageDraw
    tiles = []
    for t in ts:
        f = os.path.join(a.salida, '_c.jpg')
        subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', p, '-frames:v', '1', '-vf', 'scale=240:-2', f])
        if os.path.exists(f):
            im = Image.open(f).convert('RGB'); d = ImageDraw.Draw(im); d.rectangle([0, 0, 64, 22], fill=(0, 0, 0)); d.text((5, 5), f'{t:.1f}s', fill=(255, 255, 255))
            tiles.append(im); os.remove(f)
    if tiles:
        w, h = tiles[0].size; col = min(6, len(tiles)); fil = (len(tiles) + col - 1) // col
        hoja = Image.new('RGB', (col * w, fil * h), (20, 20, 20))
        for i, im in enumerate(tiles): hoja.paste(im.resize((w, h)), ((i % col) * w, (i // col) * h))
        r['hoja'] = os.path.splitext(os.path.basename(p))[0] + '_hoja.jpg'; hoja.save(os.path.join(a.salida, r['hoja']), quality=80)
    return r

def frase(r):
    z = r['zooms']; za = [x for x in z if x['tipo'] == 'acerca']
    tz = max(r['texto_zonas'], key=r['texto_zonas'].get) if any(r['texto_zonas'].values()) else None
    L = [f"- **Ritmo:** corta cada {r['plano_mediana']} s en promedio ({r['planos']} planos en {r['duracion']} s)."]
    if z: L.append(f"- **Zooms:** {len(z)} ({len(za)} acercan, {len(z) - len(za)} alejan); duran ~{round(float(np.median([x['dura'] for x in z])), 2)} s y cambian ~{round(abs(float(np.median([x['factor'] for x in z])) - 1) * 100)} % el tamaño.")
    else: L.append('- **Zooms:** casi no usa; el movimiento viene de los cortes.')
    if r['texto_cada']: L.append(f"- **Textos:** entra uno nuevo cada ~{r['texto_cada']} s, sobre todo en la parte {tz} de la pantalla.")
    L.append(f"- **Energía:** {'alta' if r['movimiento_promedio'] > 0.6 else 'media' if r['movimiento_promedio'] > 0.3 else 'calmada'} ({r['movimiento_promedio']}); los momentos más movidos: {', '.join(str(s) + ' s' for s in r['segundos_mas_activos'])}.")
    return '\n'.join(L)

res = []
for p in vids:
    cache = os.path.join(a.salida, f'.{huella(p)}.json')
    r = load_json(cache, default=None) if os.path.exists(cache) else None
    if not r:
        print(f'Analizando {os.path.basename(p)}…', flush=True)
        r = analiza(p); save_json(cache, r)
    save_json(os.path.join(a.salida, os.path.splitext(os.path.basename(p))[0] + '.json'), r); res.append(r)
md = '# Lo que se puede tomar de tus referencias (solo técnica)\n\n' + '\n\n'.join(f"## {r['archivo']}\n{frase(r)}" + (f"\n- Hoja de cuadros: `{r['hoja']}`" if r.get('hoja') else '') for r in res) + '\n'
open(os.path.join(a.salida, 'resumen.md'), 'w', encoding='utf-8').write(md)
print(md)
