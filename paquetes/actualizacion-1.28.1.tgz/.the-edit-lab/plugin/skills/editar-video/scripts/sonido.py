"""Escucha el video para encontrar lo que la transcripción no ve: arranques repetidos y pausas escondidas.

Uso: python3 sonido.py <fuente.mp4|wav> <palabras.json> [--salida resultado.json]
  palabras.json: lista [{t, s, e}, ...] en segundos de ese mismo audio (las palabras del reel).
Escribe (o imprime) {"arranques": [índices de palabras], "pausas": [[desde, hasta], ...], "version": 1}

1. Arranques repetidos («cómo co- cómo cobrar»): en cada pausa corta (0.16–0.95 s) compara cómo SUENA el comienzo
   de lo que dijo antes de la pausa con el comienzo de lo que dice después (huella MFCC, que codifica lo que se dijo,
   no qué tan fuerte). Si la toma de después empieza igual, la de antes era un arranque en falso: sus palabras se marcan.
2. Pausas escondidas: silencios sostenidos de más de 0.7 s medidos en el sonido (la transcripción suele estirar una
   palabra encima de una pausa, o la pone antes de la primera palabra). Nunca cuenta como pausa un tramo que tiene una
   palabra de duración normal (una palabra suave que el medidor lee bajito sigue siendo palabra). De cada pausa se
   deja 0.12 s después de que se apaga la voz y 0.08 s antes de que vuelve, para que respire.
Solo numpy y ffmpeg. No gasta uso de Claude.
"""
import argparse, json, os, subprocess, sys
import numpy as np

SR = 16000
# arranques
DIP_MIN, DIP_MAX = 0.16, 0.95   # una pausa de arranque en falso es corta; más larga ya es cambio de frase
ATRAS = 1.6                     # hasta dónde puede llegar hacia atrás la toma abandonada
PREFIJO = 0.65                  # se compara solo el COMIENZO de cada toma
MIN_TOMA = 0.25                 # una toma más corta no se puede juzgar
SIMILAR = 0.80                  # parecido (coseno medio de la huella) a partir del cual es la misma frase otra vez
DESFASE = 0.10                  # se busca el mejor acomodo entre las dos tomas hasta este corrimiento
# pausas
MAX_QUIETO = 0.30   # sin pausas: cualquier silencio sostenido de más de 0.3 s se quita
DEJA_DESPUES, DEJA_ANTES = 0.06, 0.05
PALABRA_MAX = 0.80              # una palabra más larga que esto encima de un silencio fue estirada por la transcripción
BAJO_VOZ, SOBRE_PISO, CONTRASTE = 25.0, 6.0, 15.0
CUADRO = 0.010


def leer_audio(ruta):
    r = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-i', ruta, '-vn', '-ac', '1', '-ar', str(SR), '-f', 's16le', '-'],
                       capture_output=True)
    if r.returncode != 0 or not r.stdout:
        raise SystemExit('No pude leer el audio de ' + ruta)
    return np.frombuffer(r.stdout, dtype='<i2').astype(np.float32) / 32768.0


def db_cuadros(x):
    n = int(SR * CUADRO); m = len(x) // n
    e = (x[:m * n].reshape(m, n) ** 2).mean(1)
    return 10 * np.log10(e + 1e-10)


def _mel(nfft=512, nmel=26):
    f = np.linspace(0, SR / 2, nfft // 2 + 1)
    mel = lambda h: 2595 * np.log10(1 + h / 700); inv = lambda m: 700 * (10 ** (m / 2595) - 1)
    pts = inv(np.linspace(mel(80), mel(7600), nmel + 2))
    fb = np.zeros((nmel, len(f)), np.float32)
    for i in range(nmel):
        a, b, c = pts[i], pts[i + 1], pts[i + 2]
        fb[i] = np.clip(np.minimum((f - a) / (b - a), (c - f) / (c - b)), 0, None)
    return fb


FB = _mel()
DCT = np.cos(np.pi / 26 * (np.arange(26)[None, :] + 0.5) * np.arange(1, 14)[:, None]).astype(np.float32)


def huella(x):
    """MFCC 13 (sin c0), ventana 25 ms, paso 10 ms, con la media quitada: describe lo que se dijo, no el volumen."""
    w, h = 400, 160
    if len(x) < w:
        return np.zeros((0, 13), np.float32)
    n = 1 + (len(x) - w) // h
    idx = np.arange(w)[None, :] + h * np.arange(n)[:, None]
    fr = x[idx] * np.hanning(w).astype(np.float32)
    p = np.abs(np.fft.rfft(fr, 512)) ** 2
    m = np.log(p @ FB.T + 1e-8) @ DCT.T
    m -= m.mean(0)
    return m / (np.linalg.norm(m, axis=1, keepdims=True) + 1e-6)


def parecido(a, b):
    """Coseno medio entre dos huellas, con el mejor corrimiento hasta DESFASE."""
    n = min(len(a), len(b))
    if n < 8:
        return 0.0
    best = 0.0
    for lag in range(0, int(DESFASE / 0.01) + 1):
        for aa, bb in ((a[lag:], b), (a, b[lag:])):
            k = min(len(aa), len(bb), n)
            if k >= 8:
                best = max(best, float((aa[:k] * bb[:k]).sum(1).mean()))
    return best


def arranques(x, W):
    marcadas = set()
    V = [i for i, w in enumerate(W) if w.get('s') is not None]
    for j in range(1, len(V)):
        i0, i1 = V[j - 1], V[j]
        hueco = W[i1]['s'] - (W[i0].get('e') or W[i0]['s'])
        if not (DIP_MIN <= hueco <= DIP_MAX):
            continue
        # la toma de antes: desde la pausa anterior (o hasta ATRAS segundos) hasta esta pausa
        k = j - 1
        while k > 0 and W[V[k]]['s'] - (W[V[k - 1]].get('e') or W[V[k - 1]]['s']) < DIP_MIN and W[i0]['e'] - W[V[k - 1]]['s'] <= ATRAS:
            k -= 1
        t1a, t1b = W[V[k]]['s'], W[i0].get('e') or W[i0]['s']
        if t1b - t1a < MIN_TOMA or t1b - t1a > ATRAS + 0.3:
            continue
        L = min(PREFIJO, t1b - t1a)
        t2a = W[i1]['s']
        a = huella(x[int(t1a * SR):int((t1a + L) * SR)])
        b = huella(x[int(t2a * SR):int((t2a + L + DESFASE) * SR)])
        sim = parecido(a, b)
        # tiene que repetirse también en el texto o, si la transcripción se lo comió, sonar casi igual
        txt_a = [_n(W[V[q]]['t']) for q in range(k, j)]
        txt_b = [_n(W[V[q]]['t']) for q in range(j, min(len(V), j + len(txt_a)))]
        texto_igual = bool(txt_a) and txt_a[0] == (txt_b[0] if txt_b else None)
        if sim >= SIMILAR or (texto_igual and sim >= SIMILAR - 0.12):
            for q in range(k, j):
                marcadas.add(V[q])
    return sorted(marcadas)


def _n(t):
    import unicodedata
    t = unicodedata.normalize('NFD', str(t).lower())
    return ''.join(c for c in t if c.isalnum())


def pausas(x, W):
    db = db_cuadros(x)
    if len(db) < 50:
        return []
    out = []
    # se mide por tramos de ~20 s (el nivel de su voz cambia a lo largo de una grabación larga)
    paso = int(20 / CUADRO)
    for a0 in range(0, len(db), paso):
        seg = db[a0:a0 + paso + int(2 / CUADRO)]
        r = np.sort(seg)
        voz, piso = r[int(0.9 * (len(r) - 1))], r[int(0.1 * (len(r) - 1))]
        if voz - piso < CONTRASTE:
            continue
        linea = max(voz - BAJO_VOZ, piso + SOBRE_PISO)
        q = seg < linea
        i = 0
        while i < len(q):
            if q[i]:
                j = i
                while j < len(q) and q[j]:
                    j += 1
                s, e = (a0 + i) * CUADRO, (a0 + j) * CUADRO
                if e - s > MAX_QUIETO and s < (a0 + paso) * CUADRO:
                    ok = True
                    for w in W:
                        if w.get('s') is None:
                            continue
                        we = w.get('e') or w['s']
                        if we - w['s'] <= PALABRA_MAX and min(we, e) - max(w['s'], s) > 0.05:
                            ok = False; break
                    if ok:
                        out.append([round(s + DEJA_DESPUES, 3), round(e - DEJA_ANTES, 3)])
                i = j
            else:
                i += 1
    # sin repetidos, en orden
    out.sort(); res = []
    for p in out:
        if res and p[0] <= res[-1][1]:
            res[-1][1] = max(res[-1][1], p[1])
        elif p[1] - p[0] > 0.2:
            res.append(p)
    return res


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('audio'); ap.add_argument('palabras'); ap.add_argument('--salida')
    a = ap.parse_args()
    W = json.load(open(a.palabras, encoding='utf-8'))
    if isinstance(W, dict):
        W = W.get('palabras') or []
    x = leer_audio(a.audio)
    res = {'version': 1, 'arranques': arranques(x, W), 'pausas': pausas(x, W)}
    s = json.dumps(res, ensure_ascii=False)
    if a.salida:
        open(a.salida, 'w', encoding='utf-8').write(s)
    print(s)


if __name__ == '__main__':
    main()
