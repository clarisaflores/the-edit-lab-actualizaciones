"""Portada del Reel: elige los mejores cuadros de SU grabación y, con el que ella escoja, compone la portada con título.

Uso:
  python3 portada.py candidatos <proyecto> --modelo <face_detection_yunet_2023mar.onnx> [--n 6]
  python3 portada.py componer   <proyecto> --t <segundo> --titulo "texto" --estilo <estilo.json> --fuentes <carpeta> --salida <Portada.jpg>

candidatos: revisa trabajo/base.mp4 cada 0.4 s y puntúa cada cuadro: nitidez (que no esté movido), cara de frente y
  bien encuadrada, mirando a cámara, y no en mitad de un parpadeo o una palabra (preferimos cuadros donde la cara
  está quieta respecto al anterior). Guarda los mejores, separados entre sí al menos 2 s, en
  trabajo/portada/candidato_<n>.jpg (360 px) y portada.json [{n, t, puntos}].
componer: toma ese segundo en calidad completa (1080×1920) y escribe el título con su fuente de títulos y sus
  colores, en el tercio de arriba dentro de la zona segura (y 270–760), sin tocar su cara. Nunca inventa texto:
  el título es el que ella eligió (o su hook aprobado).
"""
import argparse, os, sys, glob, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, load_json, save_json

ap = argparse.ArgumentParser()
ap.add_argument('accion', choices=['candidatos', 'componer']); ap.add_argument('proyecto')
ap.add_argument('--modelo'); ap.add_argument('--n', type=int, default=6)
ap.add_argument('--t', type=float); ap.add_argument('--titulo', default=''); ap.add_argument('--estilo'); ap.add_argument('--fuentes'); ap.add_argument('--salida')
a = ap.parse_args()
P = os.path.abspath(a.proyecto); T = os.path.join(P, 'trabajo'); BASE = os.path.join(T, 'base.mp4'); D = os.path.join(T, 'portada')

if a.accion == 'candidatos':
    import cv2, numpy as np
    tmp = os.path.join(D, '_c'); shutil.rmtree(tmp, ignore_errors=True); os.makedirs(tmp)
    PASO = 0.4
    run(['ffmpeg', '-nostdin', '-v', 'error', '-i', BASE, '-vf', f'fps=1/{PASO},scale=540:960', '-q:v', '3', os.path.join(tmp, 'f%05d.jpg')])
    det = cv2.FaceDetectorYN.create(a.modelo, '', (540, 960), 0.7) if a.modelo and os.path.exists(a.modelo) else None
    fs = sorted(glob.glob(os.path.join(tmp, '*.jpg'))); res = []; prev = None
    for i, p in enumerate(fs):
        img = cv2.imread(p); g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        nit = cv2.Laplacian(g, cv2.CV_64F).var()
        pts = min(nit / 120.0, 1.5)              # nitidez
        cara = None
        if det is not None:
            _, f = det.detect(img)
            if f is not None and len(f): cara = max(f, key=lambda r: r[2] * r[3])
        if det is not None and cara is None: prev = None; continue   # sin cara no hay portada
        if cara is not None:
            x, y, w, h = cara[:4]; ojo_d, ojo_i, nariz = cara[4:6], cara[6:8], cara[8:10]; conf = cara[14]
            # de frente: la nariz a la mitad entre los ojos; mirando a cámara: ojos a la misma altura
            sep = abs(ojo_i[0] - ojo_d[0]) + 1e-3
            frente = 1 - min(1, abs(nariz[0] - (ojo_d[0] + ojo_i[0]) / 2) / (0.35 * sep))
            nivel = 1 - min(1, abs(ojo_i[1] - ojo_d[1]) / (0.25 * sep))
            tam = min(1, (w * h) / (0.06 * 540 * 960))               # cara de buen tamaño
            centro = 1 - min(1, abs((x + w / 2) - 270) / 270)
            quieto = 1.0
            if prev is not None: quieto = 1 - min(1, np.hypot(*(np.array(nariz) - prev)) / (0.2 * w))
            prev = np.array(nariz)
            # parpadeo: la zona de los ojos con poco detalle comparada con la cara (ojos cerrados = plano)
            r = int(max(6, sep * 0.22)); oj = 0
            for ex, ey in (ojo_d, ojo_i):
                z = g[max(0, int(ey) - r):int(ey) + r, max(0, int(ex) - r):int(ex) + r]
                if z.size: oj += z.std()
            abiertos = min(1, oj / 2 / 28.0)
            pts += 1.2 * frente + 0.8 * nivel + 0.6 * tam + 0.4 * centro + 0.5 * quieto + 1.0 * abiertos + 0.3 * float(conf)
        res.append({'t': round(i * PASO, 2), 'puntos': round(float(pts), 3), 'f': p})
    res.sort(key=lambda r: -r['puntos']); elegidos = []
    for r in res:
        if all(abs(r['t'] - e['t']) >= 2 for e in elegidos): elegidos.append(r)
        if len(elegidos) >= a.n: break
    elegidos.sort(key=lambda r: r['t']); out = []
    for n, r in enumerate(elegidos, 1):
        dst = os.path.join(D, f'candidato_{n}.jpg')
        run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', f"{r['t']:.2f}", '-i', BASE, '-frames:v', '1', '-vf', 'scale=360:640', '-q:v', '3', dst])
        out.append({'n': n, 't': r['t'], 'puntos': r['puntos'], 'archivo': dst})
    shutil.rmtree(tmp, ignore_errors=True); save_json(os.path.join(D, 'portada.json'), out)
    print(f'Portada: {len(out)} cuadros candidatos en trabajo/portada/ ' + ', '.join(f"{o['n']}={o['t']:.1f}s" for o in out))

else:
    from PIL import Image, ImageDraw, ImageFont
    os.makedirs(D, exist_ok=True); cuadro = os.path.join(D, '_cuadro.png')
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', f'{a.t:.3f}', '-i', BASE, '-frames:v', '1', '-vf', 'scale=1080:1920', cuadro])
    im = Image.open(cuadro).convert('RGB'); os.remove(cuadro)
    est = load_json(a.estilo, default={}) if a.estilo else {}
    fu = est.get('fuentes', {}) or {}; col = est.get('colores', {}) or {}
    cands = [fu.get('titulos'), fu.get('respaldo_titulos'), 'Inter-Bold.ttf']
    ruta = None
    for c in cands:
        if not c: continue
        for base in (a.fuentes or '', os.path.expanduser('~/.cvs-motor/fuentes')):
            if base and os.path.exists(os.path.join(base, c)): ruta = os.path.join(base, c); break
        if ruta: break
    cara = load_json(os.path.join(T, 'cara.json'), default={})
    techo = 270; piso = max(techo + 200, min(760, int(cara.get('top', 800)) - 30))
    txt = a.titulo.strip()
    if txt:
        palabras = txt.split(); d = ImageDraw.Draw(im)
        def renglones(size):
            f = ImageFont.truetype(ruta, size) if ruta else ImageFont.load_default()
            L, cur = [], ''
            for w in palabras:
                prueba = (cur + ' ' + w).strip()
                if f.getlength(prueba) <= 900 or not cur: cur = prueba
                else: L.append(cur); cur = w
            if cur: L.append(cur)
            return f, L
        size = 150
        while True:
            f, L = renglones(size); alto = len(L) * size * 1.05
            if (alto <= piso - techo and max(f.getlength(l) for l in L) <= 940) or size <= 56: break
            size -= 6
        y = techo + max(0, (piso - techo - alto) / 2)
        # color que SE LEA sobre ese pedazo de su video (sin sombras ni cajas): claro sobre oscuro, oscuro sobre claro
        def lum(h):
            h = h.lstrip('#'); r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4)); return 0.2126 * r + 0.7152 * g + 0.0722 * b
        from PIL import ImageStat
        fondo = ImageStat.Stat(im.crop((70, int(y), 1010, int(max(y + 1, y + alto)))).convert('L')).mean[0]
        opciones = [c for c in (col.get('texto'), col.get('caja_texto'), col.get('resaltado_texto'), '#FFFFFF', '#1E1A17') if c]
        color = max(opciones, key=lambda c: abs(lum(c) - fondo))
        for l in L:
            w = f.getlength(l); d.text(((1080 - w) / 2, y), l, font=f, fill=color); y += size * 1.05
    salida = a.salida or os.path.join(D, 'Portada.jpg'); os.makedirs(os.path.dirname(salida), exist_ok=True)
    im.save(salida, quality=92); print(f'Portada lista: {salida}')
