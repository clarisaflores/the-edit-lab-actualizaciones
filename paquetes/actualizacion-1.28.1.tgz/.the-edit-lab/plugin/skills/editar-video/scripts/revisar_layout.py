"""Revisión de acomodo antes de animar: ningún texto fuera de la pantalla ni encima de su cara.

Uso:
  python3 revisar_layout.py <proyecto> [--fuente <ttf>] [--solo-revisar]

Lee trabajo/cues.json y trabajo/cara.json (dónde está su cabeza en cada momento) y revisa cada título,
palabra, sticker o animación contra:
  - el marco seguro de Instagram: x 60–1020, y 270–1620 (arriba y abajo solo fondo; ahí van los botones);
  - su cara en ESE momento (los textos marcados "detras" sí pueden cruzarla: van detrás de su silueta).
Si algo choca lo arregla solo (lo achica si se sale de lado; lo sube arriba de su cabeza o lo baja bajo su
barbilla si la tapa) y guarda cues.json. Lo que no pudo arreglar lo dice en una línea AVISO: nunca detiene la
edición. Con --solo-revisar no cambia nada, solo reporta.
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_json, save_json

X0, X1, Y0, Y1 = 60, 1020, 270, 1620
ap = argparse.ArgumentParser(); ap.add_argument('proyecto'); ap.add_argument('--fuente'); ap.add_argument('--solo-revisar', action='store_true')
a = ap.parse_args()
T = os.path.join(os.path.abspath(a.proyecto), 'trabajo')
cues = load_json(os.path.join(T, 'cues.json')); cara = load_json(os.path.join(T, 'cara.json'), default={})
FT = a.fuente or os.path.expanduser('~/.cvs-motor/fuentes/Inter-Bold.ttf')
try:
    from PIL import ImageFont
    _f = {}
    def ancho(txt, size):
        size = int(max(8, size))
        if size not in _f: _f[size] = ImageFont.truetype(FT, size)
        return _f[size].getlength(txt)
except Exception:
    def ancho(txt, size): return len(txt) * size * 0.62

TR = cara.get('tramos') or []
def cabeza(t0, t1):
    """Caja de su cabeza mientras el texto está en pantalla (la unión de lo medido en ese rato)."""
    fs = [r for r in TR if t0 - 0.5 <= r[0] <= t1 + 0.5]
    if not fs:
        if not cara.get('vista'): return None
        return {'top': cara['top'], 'bottom': cara['bottom'], 'izq': cara.get('izq', cara['cx'] - 200), 'der': cara.get('der', cara['cx'] + 200)}
    return {'top': min(r[2] for r in fs), 'bottom': max(r[3] for r in fs), 'izq': min(r[4] for r in fs), 'der': max(r[5] for r in fs)}

def caja_lineas(o):
    cx = o.get('x', 540) if isinstance(o.get('x'), (int, float)) else 540
    cajas = []
    for l in o['lineas']:
        w = ancho(l['text'], l['size']); h = 0.78 * l['size']
        cajas.append([cx - w / 2, l['y'] - h / 2, cx + w / 2, l['y'] + h / 2])
    return cajas

def toca(c, b, m=12):
    return c[2] > b['izq'] - m and c[0] < b['der'] + m and c[3] > b['top'] - m and c[1] < b['bottom'] + m

arreglos, avisos = [], []
for o in cues.get('overlays', []):
    nom = (o.get('text') or o.get('file') or o.get('kind', '')).replace('\n', ' ')[:28]
    t0, t1 = o.get('t0', 0), o.get('t1', 0)
    if o.get('lineas'):
        cs = caja_lineas(o)
        # 1) de lado: si un renglón se sale, se achica todo el bloque lo justo
        anch = max(c[2] - c[0] for c in cs)
        if anch > X1 - X0:
            f = (X1 - X0) / anch * 0.97
            if not a.solo_revisar:
                for l in o['lineas']: l['size'] = round(l['size'] * f)
            arreglos.append(f'"{nom}" se salía de lado: lo achiqué {round((1 - f) * 100)} %'); cs = caja_lineas(o)
        # 2) arriba / abajo: dentro de 270–1620
        top, bot = min(c[1] for c in cs), max(c[3] for c in cs)
        dy = (Y0 - top) if top < Y0 else ((Y1 - bot) if bot > Y1 else 0)
        if dy:
            if bot - top <= Y1 - Y0:
                if not a.solo_revisar:
                    for l in o['lineas']: l['y'] = round(l['y'] + dy)
                arreglos.append(f'"{nom}" quedaba en la franja de los botones de Instagram: lo moví {abs(round(dy))} px'); cs = caja_lineas(o)
            else: avisos.append(f'"{nom}" es demasiado alto para la zona segura; acórtalo')
        # 3) su cara: solo si NO va detrás de su silueta
        b = cabeza(t0, t1)
        if b and not o.get('detras') and any(toca(c, b) for c in cs):
            top, bot = min(c[1] for c in cs), max(c[3] for c in cs); h = bot - top
            arriba = b['top'] - 30 - bot          # cuánto subirlo para que termine arriba de su cabeza
            abajo = b['bottom'] + 30 - top        # o bajarlo bajo su barbilla
            if top + arriba >= Y0: dy = arriba
            elif bot + abajo <= Y1: dy = abajo
            else: dy = None
            if dy is not None:
                if not a.solo_revisar:
                    for l in o['lineas']: l['y'] = round(l['y'] + dy)
                arreglos.append(f'"{nom}" ({t0:.1f} s) tapaba tu cara: lo pasé {"arriba de tu cabeza" if dy < 0 else "bajo tu barbilla"}')
            else:
                avisos.append(f'"{nom}" ({t0:.1f} s) toca tu cara y no hay lugar libre; quedó como estaba')
    elif all(k in o for k in ('x', 'y', 'tam')) and o.get('kind') in ('sticker', 'animacion', 'imagen', 'catalogo'):
        hw = o['tam'] / 2; c = [o['x'] - hw, o['y'] - hw, o['x'] + hw, o['y'] + hw]
        if o['tam'] < 1000 and (c[0] < X0 - 20 or c[2] > X1 + 20 or c[1] < Y0 - 40 or c[3] > Y1 + 40):
            nx = min(max(o['x'], X0 + hw), X1 - hw); ny = min(max(o['y'], Y0 + hw), Y1 - hw)
            if not a.solo_revisar: o['x'], o['y'] = round(nx), round(ny)
            arreglos.append(f'"{nom}" se salía de la pantalla: lo metí')
        b = cabeza(t0, t1)
        if b and o['tam'] < 1000 and toca([o['x'] - hw, o['y'] - hw, o['x'] + hw, o['y'] + hw], b, 0):
            avisos.append(f'"{nom}" ({t0:.1f} s) toca tu cara; si no te gusta, hazlo más chico o muévelo')

if arreglos and not a.solo_revisar: save_json(os.path.join(T, 'cues.json'), cues)
for x in arreglos: print(('REVISAR: ' if a.solo_revisar else 'ARREGLADO: ') + x)
for x in avisos: print('AVISO: ' + x)
if not arreglos and not avisos: print('Acomodo: todo dentro de la pantalla y lejos de tu cara.')
save_json(os.path.join(T, 'layout.json'), {'arreglos': arreglos, 'avisos': avisos})
