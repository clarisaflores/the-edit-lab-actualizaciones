"""Escucha el corte ya armado (como lo oirá la gente) y quita lo que quedó repetido. Corre después de linea_tiempo.py.

Uso: python3 escuchar_corte.py <carpeta_trabajo> [--modelo small] [--solo-revisar]

Por qué: la transcripción por bloques a veces se traga un reinicio («mi serie para que tus videos… mi serie para
hacer que tus videos se vean bien»), y entonces quedan las dos tomas pegadas. Aquí se arma el audio del corte con
timeline.json, se transcribe palabra por palabra y se buscan frases de 2 palabras o más que se repiten muy cerca
(menos de 8 s y menos de 14 palabras entre una y otra). Regla de la casa: gana la ÚLTIMA toma. Se quita desde el
inicio de la primera vez hasta el inicio de la segunda, con el corte puesto en el silencio real entre palabras.
Las repeticiones a propósito de una sola palabra («todo, todo, todo») no se tocan.
También agrega a timeline.json las palabras que se oyen y no estaban (para que los subtítulos digan TODO).
Escribe timeline.json (respaldo en timeline.antes_de_escuchar.json) y escucha.json con lo que hizo.
"""
import argparse, os, re, sys, shutil, unicodedata
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_wav, envelope, load_json, save_json, nfc, HOP
import numpy as np

ap = argparse.ArgumentParser(); ap.add_argument('trabajo'); ap.add_argument('--modelo', default='small'); ap.add_argument('--idioma', default='es')
ap.add_argument('--solo-revisar', action='store_true'); ap.add_argument('--vueltas', type=int, default=8)
a = ap.parse_args()
T = a.trabajo; TLp = os.path.join(T, 'timeline.json')
INVENTA = re.compile(r'gracias|suscr[ií]b|amara', re.I)
VACIAS = set('de la el y a en que lo los las un una o mi tu se me te le ya no es por con para al del'.split())


def norm(t):
    t = unicodedata.normalize('NFD', t.lower()); t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ]', '', t)


audios = {}
def audio(n):
    if n not in audios:
        p = os.path.join(T, f'a{n}.wav'); audios[n] = load_wav(p)
    return audios[n]


def armar(tl):
    """Audio del corte (16 kHz mono) pegando cada clip como hará el video."""
    partes = []; sr0 = None
    for c in tl['clips']:
        x, sr = audio(c['archivo']); sr0 = sr
        partes.append(x[int(c['in'] * sr):int(c['out'] * sr)])
    return (np.concatenate(partes) if partes else np.zeros(1, np.float32)), sr0


def igual(p1, p2, ultima_cruda):
    """Misma frase; la última palabra de la primera vez puede estar cortada («mi se…» → «mi serie»)."""
    if p1[:-1] != p2[:-1]: return False
    x, y = p1[-1], p2[-1]
    if x == y: return True
    # arranque en falso: la última palabra quedó a medias («mi se… mi serie»)
    return len(x) >= 2 and len(x) < len(y) and y.startswith(x)


def a_cut(tl, n, t_src):
    for c in tl['clips']:
        if c['archivo'] == n and c['in'] - 1e-3 <= t_src <= c['out'] + 1e-3: return c['t0'] + (t_src - c['in'])
    return None


def valle(x, sr, t, rad=0.18):
    """El punto más silencioso cerca de t (para cortar entre palabras, no dentro de una)."""
    E = envelope(x, sr); i0 = max(0, int((t - rad) / HOP)); i1 = min(len(E), int((t + rad) / HOP) + 1)
    if i1 <= i0: return t
    return (i0 + int(np.argmin(E[i0:i1]))) * HOP


def quitar(tl, A, B):
    """Quita del corte el tramo [A, B) (tiempo del corte) y recorre todo lo que sigue."""
    nuevos = []; d = B - A
    for c in tl['clips']:
        c0, c1 = c['t0'], c['t0'] + (c['out'] - c['in'])
        if c1 <= A or c0 >= B: nuevos.append(dict(c)); continue
        if c0 < A: nuevos.append(dict(c, out=round(c['in'] + (A - c0), 3)))
        if c1 > B: nuevos.append(dict(c, **{'in': round(c['in'] + (B - c0), 3)}))
    t = 0.0
    for c in nuevos:
        c['t0'] = round(t, 3); t += c['out'] - c['in']
    nuevos = [c for c in nuevos if c['out'] - c['in'] > 0.02]
    t = 0.0
    for c in nuevos: c['t0'] = round(t, 3); t += c['out'] - c['in']
    ws = []
    for w in tl.get('words', []):
        m = (w['s'] + w['e']) / 2
        if A <= m < B: continue
        if w['s'] >= B: w = dict(w, s=round(w['s'] - d, 3), e=round(w['e'] - d, 3))
        ws.append(w)
    tl['clips'] = nuevos; tl['words'] = ws; tl['duration'] = round(t, 3)


from faster_whisper import WhisperModel
model = WhisperModel(a.modelo, device='cpu', compute_type='int8', cpu_threads=(min(8, max(4, (os.cpu_count() or 4) - 2)) if os.environ.get('EDIT_LAB_LOCAL') else min(4, os.cpu_count() or 2)))


def oir(x, sr, tl):
    """Escucha el corte en trozos cortos (≤ 6 s, partidos en las uniones de clips): de corrido, el modelo se traga los
    reinicios; en trozos chicos oye cada palabra."""
    juntas = sorted({0.0} | {round(c['t0'], 3) for c in tl['clips']} | {len(x) / sr})
    cortes = [0.0]
    for t in juntas[1:]:
        if t - cortes[-1] >= 6 or t >= len(x) / sr - 1e-3:
            if t - cortes[-1] > 9:   # un clip muy largo: se parte en el silencio más hondo
                m = cortes[-1] + 6
                while t - m > 3: cortes.append(round(valle(x, sr, m, 0.6), 3)); m = cortes[-1] + 6
            cortes.append(t)
    out = []
    for s0, s1 in zip(cortes, cortes[1:]):
        if s1 - s0 < 0.2: continue
        segs, _ = model.transcribe(x[int(s0 * sr):int(s1 * sr)], language=a.idioma, beam_size=5, word_timestamps=True,
                                   condition_on_previous_text=False, vad_filter=False)
        for sg in segs:
            for w in sg.words:
                if w.word.strip(): out.append({'w': nfc(w.word.strip()), 's': round(w.start + s0, 3), 'e': round(w.end + s0, 3)})
    return [w for w in out if not INVENTA.search(w['w'])]


tl = load_json(TLp); orig = load_json(TLp); quitados = []; ultimo = None
for vuelta in range(a.vueltas):
    x, sr = armar(tl); H = oir(x, sr, tl); ultimo = (x, sr, H); n = [norm(w['w']) for w in H]; hallado = None
    for i in range(len(H)):
        for k in (6, 5, 4, 3, 2):
            if i + k > len(H): continue
            frase = n[i:i + k]
            if not all(frase) or all(f in VACIAS for f in frase): continue
            for j in range(i + k, min(len(H) - k + 1, i + k + 14)):
                if igual(frase, n[j:j + k], H[i + k - 1]['w']) and H[j]['s'] - H[i]['s'] < 8:
                    hallado = (i, j, k); break
            if hallado: break
        if hallado: break
    if not hallado: break
    i, j, k = hallado
    # cada corte en el silencio real ENTRE la palabra anterior y la siguiente (los tiempos del modelo se adelantan o
    # atrasan hasta 0.3 s: si se corta donde él dice, queda la cola de la toma vieja, como un «como» suelto)
    def entre(k):
        lo = (H[k - 1]['e'] - 0.08) if k > 0 else H[k]['s'] - 0.3
        hi = H[k]['s'] + 0.25
        if k > 0: lo = max(lo, H[k - 1]['s'] + 0.08)
        if hi - lo < 0.06: return H[k]['s'] - 0.03
        return valle(x, sr, (lo + hi) / 2, (hi - lo) / 2)
    A = entre(i); B = entre(j)
    if B - A < 0.25: break
    txt = ' '.join(w['w'] for w in H[i:j]); quitados.append({'desde': round(A, 2), 'hasta': round(B, 2), 'texto': txt, 'repite': ' '.join(w['w'] for w in H[j:j + k])})
    print(f"REPETIDO: «{txt}» ({A:.2f}–{B:.2f} s del corte) se repite en «{' '.join(w['w'] for w in H[j:j + k + 4])}…»: gana la última toma")
    if a.solo_revisar: break
    quitar(tl, A, B); ultimo = None

agregadas = 0
if not a.solo_revisar:
    # subtítulos completos: palabras que se oyen en el corte final y no están en la línea de tiempo
    x, sr, H = ultimo if ultimo else (lambda xs: (xs[0], xs[1], oir(xs[0], xs[1], tl)))(armar(tl)); W = tl.get('words', [])
    from difflib import SequenceMatcher
    hw = [norm(w['w']) for w in H]; tw = [norm(w['w']) for w in W]
    nuevas = []; fuera = set()
    def escena_en(t):
        for c in tl['clips']:
            if c['t0'] - 1e-3 <= t < c['t0'] + (c['out'] - c['in']): return c.get('escena', '')
        return (tl['clips'][-1].get('escena', '') if tl['clips'] else '')
    for t_, i1, i2, j1, j2 in SequenceMatcher(None, tw, hw, autojunk=False).get_opcodes():
        # donde lo que se oye no coincide con la línea de tiempo, mandan las palabras OÍDAS (texto y tiempos):
        # así los subtítulos dicen exactamente lo que queda en el video
        # solo se AGREGAN las que faltan (una palabra que sí está, aunque se oiga distinto, se queda con su corrección)
        if t_ == 'insert' and j2 > j1:
            prev_e = W[i1 - 1]['e'] if i1 > 0 else -1; next_s = W[i1]['s'] if i1 < len(W) else 1e9
            for w in H[j1:j2]:
                if not (prev_e - 0.05 <= w['s'] and w['e'] <= next_s + 0.05): continue
                if norm(w['w']): nuevas.append({'w': w['w'].rstrip('.…-') if w['w'].endswith(('...', '…')) else w['w'], 's': w['s'], 'e': w['e'], 'escena': escena_en(w['s']), 'oida': True})
    if nuevas:
        W = [w for k, w in enumerate(W) if k not in fuera]
        corr = (load_json(os.path.join(T, 'tomas.json'), default={}) or {}).get('correcciones', {}) or {}
        for w in nuevas:
            for mal, bien in corr.items():
                if norm(w['w']) == norm(mal): w['w'] = re.sub(re.escape(mal), bien, w['w'], flags=re.I)
        tl['words'] = sorted(W + nuevas, key=lambda w: w['s']); agregadas = len(nuevas)
        print(f"Subtítulos: ajusté {agregadas} palabra(s) a lo que de verdad se oye: " + ' '.join(w['w'] for w in nuevas[:20]))
    if quitados or agregadas:
        if not os.path.exists(os.path.join(T, 'timeline.antes_de_escuchar.json')): shutil.copy(TLp, os.path.join(T, 'timeline.antes_de_escuchar.json'))
        save_json(TLp, tl)
save_json(os.path.join(T, 'escucha.json'), {'quitados': quitados, 'agregadas': agregadas, 'antes': orig.get('duration'), 'despues': tl.get('duration')})
if not quitados: print('Escuché el corte: no quedó ninguna frase repetida.')
else: print(f"Escuché el corte: quité {len(quitados)} repetición(es); el Reel quedó de {tl.get('duration', 0):.1f} s.")
