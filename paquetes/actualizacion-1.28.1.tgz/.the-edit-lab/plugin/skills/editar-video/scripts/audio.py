"""Paso 9: deja la voz limpia y mezcla los efectos de sonido.

Uso: python3 audio.py <carpeta_trabajo> --rnnn <bd.rnnn> --sonidos <carpeta Efectos de sonido> [--sfx_db 0] [--limpiar si|no] [--lufs -14]
- Quita ruido de fondo (ruidos de casa, ventilador, calle) con arnndn + afftdn.
- Baja casi por completo lo que suena entre palabras (respiraciones fuertes, ruidos sueltos), sin tocar la voz.
- Pone cada sonido de cues.json en su segundo exacto, con volumen claro pero por debajo de la voz.
- Nivela todo a -14 LUFS (lo que usan Instagram y TikTok) con limitador para que nada truene.
Crea mezcla.wav.
"""
import argparse, os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import run, load_json, load_wav, save_wav, ruta_filtro
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('trabajo'); ap.add_argument('--rnnn', required=True); ap.add_argument('--sonidos', required=True)
ap.add_argument('--mis', help='carpeta Mis efectos (sonidos propios)')
ap.add_argument('--sfx_db', type=float, default=0.0, help='+3 = efectos más fuertes, -3 = más bajitos')
ap.add_argument('--limpiar', default='si'); ap.add_argument('--lufs', type=float, default=-14)
ap.add_argument('--musica', help='archivo de música de fondo (solo si la clienta lo pidió y es suyo o libre de derechos)')
ap.add_argument('--musica_db', type=float, default=-18, help='qué tan abajo de su voz va la música (medido)')
ap.add_argument('--respira', action='store_true', help='la música sube un poco en sus pausas largas')
ap.add_argument('--compuerta', type=float, default=0.06, help='volumen entre palabras (0.06 = casi silencio, 1 = sin tocar)')
a = ap.parse_args()
T = a.trabajo; SR = 48000
tl = load_json(os.path.join(T, 'timeline.json')); cues = load_json(os.path.join(T, 'cues.json'), default={'sfx': []})
D = tl.get('duration_real', tl['duration'])

# 1. limpieza
clean = os.path.join(T, '_voz_limpia.wav')
af = "highpass=f=80,lowpass=f=15000"
if a.limpiar == 'si':
    af += f",arnndn=m='{ruta_filtro(a.rnnn)}':mix=0.9,afftdn=nf=-30"
import subprocess
# voz pareja y profesional: compresión suave (2.5:1) y control de las «s» fuertes. Solo si su ffmpeg trae esos filtros.
try:
    _fl = subprocess.run(['ffmpeg', '-hide_banner', '-filters'], capture_output=True, text=True).stdout
except Exception:
    _fl = ''
if ' acompressor ' in _fl:
    af += ",acompressor=threshold=0.1:ratio=2.5:attack=8:release=120:knee=4:makeup=1.6"
if ' deesser ' in _fl:
    af += ",deesser=i=0.35:m=0.5:f=0.5"
run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', os.path.join(T, 'voz.wav'), '-af', af, '-ar', str(SR), '-ac', '1', clean])
x, _ = load_wav(clean)
n = int(round(D * SR)); x = np.pad(x, (0, max(0, n - len(x))))[:n]

# 2. compuerta guiada por las palabras: entre palabras baja a --compuerta, con rampas suaves
if a.compuerta < 1:
    g = np.full(n, a.compuerta, np.float32)
    for w in tl['words']:
        s, e = int(max(0, w['s'] - 0.10) * SR), int(min(D, w['e'] + 0.12) * SR); g[s:e] = 1
    k = int(0.03 * SR); g = np.convolve(g, np.ones(k) / k, mode='same')
    x = x * g

# 3. voz a nivel de referencia antes de mezclar (mide con ebur128 vía loudnorm)
import subprocess
def lufs_de(path):
    p = subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-i', path, '-af', 'loudnorm=print_format=json', '-f', 'null', '-'], capture_output=True, text=True)
    j = p.stderr[p.stderr.rindex('{'):p.stderr.rindex('}') + 1]; return json.loads(j)
tmp = os.path.join(T, '_voz_gate.wav'); save_wav(tmp, x, SR)
m = lufs_de(tmp); il = float(m['input_i']) if m['input_i'] not in ('-inf', 'inf') else -30
x = x * 10 ** ((-16 - il) / 20)

# 4. efectos de sonido
cache = {}
def carga(name):
    if name not in cache:
        p = os.path.join(a.sonidos, name)
        if not os.path.exists(p) and a.mis: p = os.path.join(a.mis, name)
        if not os.path.exists(p):
            print(f'AVISO: falta el sonido {name} en {a.sonidos}'); cache[name] = None; return None
        o = os.path.join(T, '_sfx.wav')
        run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', p, '-ac', '1', '-ar', str(SR), o])
        y, _ = load_wav(o); pk = np.abs(y).max() or 1
        cache[name] = y / pk * 10 ** ((-9 + a.sfx_db) / 20)  # pico a -9 dBFS: se oye claro, debajo de la voz
    return cache[name]
mix = x.copy()
for s in cues.get('sfx', []):
    y = carga(s['file'])
    if y is None: continue
    if s.get('dur'):  # teclas: dura lo que tarda en escribirse el texto
        L = int(min(len(y), s['dur'] * SR + 0.15 * SR)); y = y[:L].copy(); f = min(L, int(0.08 * SR)); y[-f:] *= np.linspace(1, 0, f)
    i = int(s['t'] * SR); j = min(n, i + len(y))
    if i < n: mix[i:j] += y[:j - i]

# 4b. música de fondo (opcional): UN nivel fijo, medido contra SU voz, sin entrada gradual y con una salida corta.
#     La voz se mide solo donde habla (sus cuadros fuertes); la música, solo donde suena (sin su silencio inicial).
#     Con --respira la música sube un poco en sus pausas largas (más de 0.6 s) y vuelve a bajar antes de que hable.
if a.musica:
    o = os.path.join(T, '_musica.wav')
    run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-stream_loop', '-1', '-i', a.musica, '-t', f'{D:.3f}', '-ac', '1', '-ar', str(SR), o])
    mu, _ = load_wav(o); mu = np.pad(mu, (0, max(0, n - len(mu))))[:n]; os.remove(o)
    def nivel(sig, rank):
        h = int(0.05 * SR); m = len(sig) // h
        if m < 4: return float(np.sqrt(np.mean(sig ** 2)) + 1e-6)
        r = np.sqrt((sig[:m * h].reshape(m, h) ** 2).mean(1)); r = np.sort(r[r > 1e-4]) if np.any(r > 1e-4) else r
        return float(r[int(rank * (len(r) - 1))] + 1e-6)
    rv = nivel(x, 0.7)        # su voz cuando habla
    rm = nivel(mu, 0.5)       # la música donde suena
    mu = mu * (rv * 10 ** (a.musica_db / 20) / rm)
    if a.respira:
        h = int(0.01 * SR); m = len(x) // h
        e = np.sqrt((x[:m * h].reshape(m, h) ** 2).mean(1)) if m else np.zeros(1)
        quieto = e < rv * 0.1; g = np.ones(m)
        i = 0
        while i < m:
            if quieto[i]:
                j = i
                while j < m and quieto[j]: j += 1
                if (j - i) * 0.01 > 0.6:
                    a0, a1 = i + 15, j - 20         # sube después de 150 ms y baja 200 ms antes de que vuelva a hablar
                    if a1 > a0: g[a0:a1] = 10 ** (4 / 20)
                i = j
            else: i += 1
        g = np.convolve(g, np.ones(15) / 15, mode='same')
        mu[:m * h] *= np.repeat(g, h)
    f = min(n, int(1.5 * SR)); mu[-f:] *= np.linspace(1, 0, f) ** 2
    mix += mu

# 5. nivel final -14 LUFS y limitador
pre = os.path.join(T, '_premezcla.wav'); save_wav(pre, np.clip(mix, -1, 1) * 0.7, SR)
m = lufs_de(pre)
ln = (f"loudnorm=I={a.lufs}:TP=-1.5:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}"
      f":measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true,alimiter=limit=0.89:level=false")
run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', pre, '-af', ln, '-ar', str(SR), '-ac', '2', os.path.join(T, 'mezcla.wav')])
for f in (clean, tmp, pre, os.path.join(T, '_sfx.wav')):
    if os.path.exists(f): os.remove(f)
print(f'Listo: trabajo/mezcla.wav ({D:.1f} s, {len(cues.get("sfx", []))} sonidos, {a.lufs} LUFS)')
