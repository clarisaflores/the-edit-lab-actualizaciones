"""Arma el campo `palabras` del Reel (lo que la página usa para mostrar y recortar los cortes) a partir del corte REAL.

Uso: python3 palabras_pagina.py <carpeta_trabajo> [--salida palabras_pagina.json]

Lee pedazos.json (todas las palabras, ya afinadas con el sonido) y timeline.json (los clips que de verdad quedan, después
de escuchar el corte). Cada palabra queda `auto: false` si su centro cae dentro de un clip del corte y `auto: true` si no
(se quitó). Así lo que ella ve en la página es exactamente lo que se va a editar: nunca una toma repetida que el corte
ya quitó. Los tiempos se pasan a la fuente ligera (si hay varios videos, se suma la duración de los anteriores).
Escribe <trabajo>/palabras_pagina.json: la lista lista para guardar en el reel.
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comun import load_json, save_json

ap = argparse.ArgumentParser(); ap.add_argument('trabajo'); ap.add_argument('--salida', default='palabras_pagina.json')
a = ap.parse_args(); T = a.trabajo
P = load_json(os.path.join(T, 'pedazos.json'))['pedazos']; tl = load_json(os.path.join(T, 'timeline.json'))
F = load_json(os.path.join(T, 'fuentes.json'), default=[])
off, acc = {}, 0.0
for f in sorted(F, key=lambda f: f['n']):
    off[f['n']] = acc; acc += float(f.get('duracion') or 0)
clips = {}
for c in tl['clips']: clips.setdefault(c['archivo'], []).append((c['in'], c['out']))
out = []; kept = 0
for p in P:
    n = p['archivo']; o = off.get(n, 0.0)
    for i, w in enumerate(p.get('palabras') or []):
        m = (w['s'] + w['e']) / 2
        dentro = any(i0 - 0.02 <= m <= i1 + 0.02 for i0, i1 in clips.get(n, []))
        d = {'t': w['w'], 'p': p['id'], 'i': i, 'auto': not dentro, 's': round(w['s'] + o, 2), 'e': round(w['e'] + o, 2)}
        if w.get('rep'): d['repetida'] = True
        out.append(d); kept += dentro
save_json(os.path.join(T, a.salida), out)
# los cortes EXACTOS del motor (ya escuchados y sin pausas), en el tiempo de la fuente ligera: la página los usa tal cual
segs = []
for c in tl['clips']:
    o = off.get(c['archivo'], 0.0); t1 = c['t0'] + (c['out'] - c['in'])
    tx = ' '.join(w['w'] for w in tl.get('words', []) if c['t0'] - 0.01 <= (w['s'] + w['e']) / 2 < t1)
    segs.append({'d': round(c['in'] + o, 3), 'h': round(c['out'] + o, 3), 'texto': tx})
save_json(os.path.join(T, 'segmentos_pagina.json'), segs)
print(f'cortes exactos para la página: {len(segs)} partes, {sum(x["h"] - x["d"] for x in segs):.1f} s → segmentos_pagina.json')
print(f'palabras para la página: {len(out)} ({kept} en el corte, {len(out) - kept} quitadas) → {a.salida}')
