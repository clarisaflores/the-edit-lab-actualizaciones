# Cómo escribir el hook en pantalla · The Edit Lab

El hook escrito es lo primero que se lee, y casi siempre se lee **sin sonido**. Su trabajo es uno solo: que quien
va pasando se quede los próximos 3 segundos. Estas reglas valen para todas las marcas y todos los formatos.

## Lo que hace un buen hook

1. **Dice de qué va el Reel en la primera lectura.** Quien lo lee sabe qué va a ganar si se queda: una respuesta,
   un resultado, un error que va a evitar, algo que va a ver. Si hay que adivinar el tema, no es hook.
2. **No repite lo que ella dice en voz.** La voz y el texto trabajan juntos: si ella abre con «hoy les quiero
   enseñar cómo…», el texto no lo copia; nombra el resultado o la tensión. (Excepción: cuando ella misma dice en
   voz alta lo que quiere ver escrito.)
3. **Es específico.** Un número real, un objeto, un tiempo, un nombre: «3 errores al grabar con el celular» se
   queda; «tips para tus videos» se pasa. Lo específico solo vale si es verdad y sale de lo que ella dice.
4. **Se lee en menos de 2 segundos.** Una línea, o dos como mucho (una chica arriba que da contexto y una grande
   abajo que es la idea). Entre 3 y 9 palabras es lo normal.
5. **Abre una pregunta que el video cierra.** Algo queda pendiente («lo que nadie te dice de…», «por qué ya no
   hago…»), y el Reel lo resuelve. Si el hook promete algo, el video lo cumple; nunca un gancho que el contenido no
   sostiene.
6. **Suena a ella.** Usa sus palabras y su tono (de sus instrucciones, su Brand Kit y la transcripción). Si ella
   dice «momentitos», el hook puede decir «momentitos»; nunca palabras de gurú que ella no usaría.

## Lo que nunca se hace

- Inventar cifras, resultados, logros o experiencias para que suene más fuerte.
- Abrir con «hoy te voy a enseñar…», «déjame mostrarte…» o «hola, soy…»: eso no dice nada nuevo.
- Hablar de las cifras de la creadora (seguidores, ventas) en la primera frase si ella no lo dice así.
- Signos o reglas que su marca prohíbe (por ejemplo, rayas largas si sus reglas dicen que no).
- Mayúsculas o minúsculas distintas a las de su estilo: el hook sigue sus reglas de texto.

## Formas que funcionan (elige la que pide el contenido, no siempre la misma)

- **Resultado:** lo que se logra, en concreto. («edité este reel en 10 minutos»)
- **Error:** lo que está haciendo mal quien mira. («si grabas así, tu video se ve gris»)
- **Contraste:** antes y ahora, o lo que todos hacen contra lo que ella hace.
- **Lista con número:** solo si el video de verdad trae esa cantidad de puntos.
- **Confesión:** una verdad personal que ella cuenta en el video; nombra la tensión y no la resuelve en el hook.
- **Etiqueta repetible:** una frase corta que ella misma dice en el video y que la gente puede repetir.

## Las 3 opciones que se le proponen

Cada una con una forma distinta (por ejemplo, una de resultado, una de error y una de contraste), todas
coherentes con lo que realmente dice. Se recomienda una, con una frase de por qué. Si ella ya escribió su hook,
ese va primero y no se cambia sin su permiso.
